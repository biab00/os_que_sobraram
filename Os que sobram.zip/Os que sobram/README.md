# 🔬 Mulheres na Ciência & Tecnologia

> Uma plataforma web moderna, inspiradora e interativa dedicada a celebrar e impulsionar a presença e o protagonismo de meninas e mulheres na ciência, tecnologia, engenharias e humanidades.

---

## 🌟 Visão Geral do Projeto

O projeto foi reformulado para proporcionar uma experiência completa e envolvente de descoberta e valorização científica:

1. **🔮 Quiz de Personalidade & Aptidão (Estilo 16Personalities / 64personality)**:
   - 10 perguntas profundas e balanceadas sobre método de resolução de problemas, reação a falhas, ferramentas indispensáveis, ambiente de trabalho ideal e legado.
   - Cálculo ponderado em tempo real que mapeia a afinidade com **11 grandes cientistas e pioneiras**.
   - Barra de progresso animada, navegação para frente/trás e tela de análise cognitiva.

2. **🏆 Resultado Completo com Biografia e Reconhecimento Histórico**:
   - Descrição dos feitos históricos que levaram cada cientista ao reconhecimento mundial.
   - Gráfico comparativo de traços cognitivos (Lógica & Algoritmos, Criatividade Teórica, Liderança Estratégica, Empatia & Impacto Humano).
   - Pontos fortes em destaque compartilhados com a cientista encontrada.

3. **📚 Estante Cultural: Livros, Biografias, Filmes & Documentários**:
   - Cada perfil conta com recomendações culturais curadas: livros clássicos e contemporâneos, biografias premiadas, documentários (BBC, National Geographic, TV Brasil, Fiocruz) e filmes de ficção e biopics.

4. **✨ Descontração: Personagens da Ficção & Cultura Pop (Caricaturas Estilizadas)**:
   - No final do resultado, cada personalidade científica é associada a **3 personagens icônicas de filmes, séries e animações** (ex: Shuri, Hermione Granger, Penelope Garcia, Velma Dinkley, Tenente Uhura, Dra. Cristina Yang, Ororo Munroe / Tempestade, Maeve Wiley, Katniss Everdeen, Lisa Simpson, Moana, etc.).
   - Ilustrações de caricatura estilizadas em arte vetorial SVG (vibrantes, responsivas e leves).
   - Frases divertidas e motivos pelos quais a energia intelectual das personagens combina com a participante.

5. **📖 Acervo & Galeria de Histórias (`/historias`)**:
   - Catálogo interativo com busca instantânea por texto e filtros por área (Computação, Exatas, Biologia/Saúde, Humanas, e destaque para **Cientistas Brasileiras**).

6. **🧠 Desafio de Conhecimentos Gerais (`/quiz_conhecimentos`)**:
   - Quiz interativo de fatos históricos com feedback imediato, explicações e placar final.

7. **✍️ Colaboração da Comunidade (`/formulario` e `/sugestoes`)**:
   - Formulário com preview dinâmico de foto para que a comunidade possa indicar professoras, pesquisadoras e cientistas inspiradoras.

---

## 👩‍🔬 As 11 Cientistas Catalogadas

| ID | Nome | Área de Atuação | Título do Arquétipo | Nacionalidade |
|---|---|---|---|---|
| `adl` | **Ada Lovelace** | Computação & Matemática | A Visionária dos Algoritmos | Reino Unido 🇬🇧 |
| `mcr` | **Marie Curie** | Física & Química Nuclear | A Desbravadora do Átomo | Polônia 🇵🇱 / França 🇫🇷 |
| `drv` | **Dorothy Vaughan** | Programação & Aeroespacial | A Estrategista do Código Espacial | Estados Unidos 🇺🇸 |
| `jge` | **Jaqueline Góes de Jesus** | Biomedicina & Genômica | A Sentinela Genômica | Brasil 🇧🇷 (BA) |
| `sgu` | **Sônia Guimarães** | Física Aplicada & Lasers | A Quebradora de Recordes do ITA | Brasil 🇧🇷 (SP) |
| `tht` | **Thaisa Storchi Bergmann** | Astrofísica & Cosmologia | A Exploradora dos Buracos Negros | Brasil 🇧🇷 (RS) |
| `mtp` | **Marie Tharp** | Geologia & Cartografia | A Cartógrafa dos Abismos | Estados Unidos 🇺🇸 |
| `dj` | **Djamila Ribeiro** | Filosofia Política & Epistemologia | A Filósofa da Mudança | Brasil 🇧🇷 (SP) |
| `jgl` | **Jane Goodall** | Primatologia & Conservação | A Guardiã da Vida Selvagem | Reino Unido 🇬🇧 |
| `tts` | **Tatiana Sampaio** | Neurobiologia & Medicina Regenerativa | A Arquiteta da Regeneração Neural | Brasil 🇧🇷 (RJ) |
| `glw` | **Gabrielle Weber** | Física Teórica & Divulgação | A Teórica Criativa da Inclusão | Brasil 🇧🇷 (SP) |

---

## 🚀 Como Executar o Projeto Localmente

### Pré-requisitos
- [Node.js](https://nodejs.org/) instalado no sistema (versão 16+ recomendada).

### Passo a Passo

1. Abra o terminal na pasta do projeto:
   ```bash
   cd "Os que sobram"
   ```

2. Caso necessário, certifique-se de que os pacotes estão instalados (as dependências já vêm inclusas no projeto):
   ```bash
   npm install
   ```

3. Inicie o servidor:
   ```bash
   npm start
   ```
   *(ou alternativamente: `node server.js`)*

4. Abra o seu navegador e acesse:
   ```
   http://localhost:3000
   ```

---

## 🧭 Rotas Disponíveis

- **`/`**: Página inicial com hero, estatísticas e cards de acesso rápido.
- **`/quiz_personalidade`**: Interface interativa do quiz de aptidão e personalidade.
- **`/resultado/:cientista`**: Página detalhada de resultado com biografia, traços, livros, filmes e caricaturas pop (ex: `/resultado/adl`, `/resultado/jge`, `/resultado/sgu`).
- **`/historias`**: Galeria interativa de cientistas com busca e filtros por área do conhecimento.
- **`/quiz_conhecimentos`**: Quiz com fatos históricos e curiosidades sobre descobertas científicas femininas.
- **`/formulario`**: Envio de sugestões e indicações de novas pesquisadoras.
- **`/sugestoes`**: Mural das sugestões enviadas pela comunidade.

---

## 🎨 Identidade Visual e Tecnologias
- **Backend**: Node.js com Express e EJS.
- **Frontend**: HTML5 semântico, CSS3 moderno com Grid, Flexbox e Glassmorphism, JavaScript Vanilla otimizado.
- **Arte Vetorial**: Ilustrações de caricatura inline SVG no estilo 16Personalities para máxima performance e resolução nítida em qualquer dispositivo.
- **Tipografia**: Google Fonts (*Plus Jakarta Sans* e *Poppins*).
