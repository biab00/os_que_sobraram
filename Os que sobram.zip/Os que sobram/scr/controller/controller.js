const { personalidades } = require("../data/personalidades");
const { questoes } = require("../data/questoes");
const { perguntasConhecimento } = require("../data/conhecimentos");
const { getCaricaturaSvg } = require("../data/caricaturas");

// Armazenamento em memória de contribuições enviadas pela comunidade
const sugestoesComunidade = [
    {
        nome: "Katemari Rosa",
        area: "Física e Ensino de Ciências",
        resumo: "Física brasileira e professora da UFBA, referência no estudo das relações étnico-raciais e de gênero no ensino de ciências.",
        autor: "Comunidade Mulheres na Ciência",
        data: "2026-10-25"
    },
    {
        nome: "Zélia Ludwig",
        area: "Física dos Materiais",
        resumo: "Professora da UFJF, atua em física da matéria condensada e é uma das maiores ativistas pelo acolhimento de meninas negras nas ciências exatas.",
        autor: "Comunidade Mulheres na Ciência",
        data: "2026-10-26"
    }
];

// Página Inicial
const index = (req, res) => {
    res.render("pages/index", {
        personalidades,
        totalCientistas: Object.keys(personalidades).length
    });
};

// Quiz de Personalidade (Interface Fluida e Moderna)
const quizPersonalidade = (req, res) => {
    res.render("pages/quiz", {
        questoes,
        personalidades
    });
};

// Rota de Compatibilidade para a URL anterior (/quiz_personalidade/:cont/:value)
const quizLegado = (req, res) => {
    const cont = parseInt(req.params.cont, 10);
    // Se for cont >= 6, redireciona para a primeira cientista como demonstração
    if (cont >= 6) {
        return res.redirect("/resultado/adl");
    }
    // Caso contrário, redireciona para o novo quiz interativo
    res.redirect("/quiz_personalidade");
};

// Rota de Processamento do Quiz (API / Cálculo Ponderado)
const processarQuiz = (req, res) => {
    try {
        const { respostas } = req.body; // Array de índices de respostas [0, 2, 1, 3, ...]
        
        // Inicializa pontuação de todas as personalidades
        const pontuacoes = {};
        Object.keys(personalidades).forEach(id => {
            pontuacoes[id] = 0;
        });

        if (Array.isArray(respostas)) {
            respostas.forEach((opcaoIdx, questaoIdx) => {
                if (questoes[questaoIdx] && questoes[questaoIdx].respostas[opcaoIdx]) {
                    const pesos = questoes[questaoIdx].respostas[opcaoIdx].pesos;
                    for (const [id, pontos] of Object.entries(pesos)) {
                        if (pontuacoes[id] !== undefined) {
                            pontuacoes[id] += pontos;
                        }
                    }
                }
            });
        }

        // Ordena por maior pontuação
        const ranking = Object.keys(pontuacoes).sort((a, b) => pontuacoes[b] - pontuacoes[a]);
        const vencedoraId = ranking[0] || "adl";

        return res.json({
            sucesso: true,
            vencedoraId,
            ranking,
            pontuacoes,
            urlResultado: `/resultado/${vencedoraId}`
        });
    } catch (err) {
        console.error("Erro ao processar quiz:", err);
        return res.status(500).json({ sucesso: false, erro: "Falha ao processar o resultado" });
    }
};

// Página de Resultado Detalhado
const resultado = (req, res) => {
    const cientistaId = req.params.cientista || "adl";
    const cientista = personalidades[cientistaId] || personalidades["adl"];

    // Calcula afinidades secundárias (recomenda outras cientistas relacionadas)
    const todasIds = Object.keys(personalidades).filter(id => id !== cientista.id);
    const afinidadesSecundarias = todasIds.slice(0, 3).map(id => personalidades[id]);

    res.render("pages/resultado", {
        cientista,
        afinidadesSecundarias,
        personalidades,
        getCaricaturaSvg
    });
};

// Galeria de Histórias
const historias = (req, res) => {
    res.render("pages/historias", {
        personalidades,
        listaPersonalidades: Object.values(personalidades)
    });
};

// Quiz de Conhecimentos Gerais
const quizConhecimentos = (req, res) => {
    res.render("pages/quiz_geral", {
        perguntas: perguntasConhecimento
    });
};

// Formulário de Submissão de Cientistas
const formulario = (req, res) => {
    const status = req.query.status || null;
    res.render("pages/formulario", { status });
};

// Processamento do Formulário
const formularioPost = (req, res) => {
    const { nome, area, resumo, autor, obras } = req.body;

    if (nome && resumo) {
        sugestoesComunidade.unshift({
            nome: nome.trim(),
            area: area ? area.trim() : "Ciência & Tecnologia",
            resumo: resumo.trim(),
            autor: autor ? autor.trim() : "Anônimo(a)",
            obras: obras ? obras.trim() : "",
            data: new Date().toISOString().split("T")[0]
        });
        return res.redirect("/sugestoes?sucesso=true");
    }

    return res.redirect("/formulario?status=erro");
};

// Página de Sugestões da Comunidade
const sugestoes = (req, res) => {
    const sucesso = req.query.sucesso === "true";
    res.render("pages/sugestoes", {
        sugestoes: sugestoesComunidade,
        sucesso
    });
};

module.exports = {
    index,
    quizPersonalidade,
    quizLegado,
    processarQuiz,
    resultado,
    historias,
    quizConhecimentos,
    formulario,
    formularioPost,
    sugestoes
};
