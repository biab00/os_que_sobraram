const express = require("express");
const rota = express.Router();
const controller = require("../controller/controller");

// Página Principal
rota.get("/", controller.index);

// Quiz de Personalidade (Novo e Fluido)
rota.get("/quiz_personalidade", controller.quizPersonalidade);

// Compatibilidade com links antigos do quiz
rota.get("/quiz_personalidade/:cont/:value", controller.quizLegado);

// Endpoint API para cálculo ponderado do resultado
rota.post("/api/calcular_quiz", controller.processarQuiz);

// Página de Resultado Detalhada da Cientista (com Livros, Filmes e Caricaturas)
rota.get("/resultado", (req, res) => res.redirect("/resultado/adl"));
rota.get("/resultado/:cientista", controller.resultado);

// Galeria de Histórias e Inspirações
rota.get("/historias", controller.historias);

// Quiz de Conhecimentos Gerais
rota.get("/quiz_conhecimentos", controller.quizConhecimentos);

// Formulário para Envio de Novas Personalidades
rota.get("/formulario", controller.formulario);
rota.post("/formulario", controller.formularioPost);

// Sugestões da Comunidade
rota.get("/sugestoes", controller.sugestoes);

module.exports = rota;
