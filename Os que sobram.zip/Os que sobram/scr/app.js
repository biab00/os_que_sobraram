const express = require('express');
const method_override = require('method-override');
const favicon = require('serve-favicon');
const path = require('path');
const fs = require('fs');

const app = express();

// Middlewares essenciais
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(method_override('_method'));

// Favicon seguro (verifica existência antes)
const faviconPath = path.join(__dirname, 'public', 'img', 'favicon.ico');
if (fs.existsSync(faviconPath)) {
    app.use(favicon(faviconPath));
}

// Arquivos Estáticos (CSS, Imagens, JS do cliente)
app.use(express.static(path.join(__dirname, 'public')));

// Configuração do motor de visualização EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Rotas da aplicação
const rota = require('./routes/router');
app.use('/', rota);

// Tratamento de Rota 404
app.use((req, res) => {
    res.status(404).render('pages/index', {
        personalidades: require('./data/personalidades').personalidades,
        totalCientistas: 11
    });
});

module.exports = app;
