const { personalidades } = require("../../data/personalidades");

const historias = Object.values(personalidades).map(p => ({
    nome: p.nome,
    imagem: p.imagem,
    realizacoes: p.feitos,
    titulo: p.titulo,
    area: p.area,
    pais: p.pais,
    livros: p.livros,
    filmes: p.filmes_documentarios,
    pop_culture: p.pop_culture
}));

const quiz_personalidade = {
    dj: 0,
    mcr: 0, 
    mtp: 0,
    sgu: 0,
    tts: 0,
    tht: 0,
    glw: 0,
    drv: 0,
    jgl: 0,
    adl: 0,
    jge: 0
};

module.exports = { historias, quiz_personalidade };
