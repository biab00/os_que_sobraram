const { questoes } = require("../../data/questoes");

module.exports = { questoes };
