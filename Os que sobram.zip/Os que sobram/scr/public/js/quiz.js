/**
 * Gerenciador Interativo do Quiz de Personalidade Científica
 * Suporta transições suaves, barra de progresso em tempo real,
 * armazenamento de respostas, navegação para frente/trás e cálculo ponderado.
 */

document.addEventListener('DOMContentLoaded', () => {
    if (typeof QUESTOES_DATA === 'undefined' || !QUESTOES_DATA.length) {
        console.error("Dados de questões não encontrados.");
        return;
    }

    const state = {
        currentIndex: 0,
        totalQuestions: QUESTOES_DATA.length,
        respostas: new Array(QUESTOES_DATA.length).fill(null),
        isTransitioning: false
    };

    // Elementos do DOM
    const currentStepEl = document.getElementById('currentStep');
    const totalStepsEl = document.getElementById('totalSteps');
    const progressFillEl = document.getElementById('progressFill');
    const categoryTagEl = document.getElementById('categoryTag');
    const questionTitleEl = document.getElementById('questionTitle');
    const optionsContainerEl = document.getElementById('optionsContainer');
    const btnPrevEl = document.getElementById('btnPrev');
    const questionBoxEl = document.getElementById('questionBox');
    const loadingOverlayEl = document.getElementById('loadingOverlay');
    const loadingStatusTextEl = document.getElementById('loadingStatusText');
    const loadingBarFillEl = document.getElementById('loadingBarFill');

    totalStepsEl.textContent = state.totalQuestions;

    // Função de renderização de uma questão
    function renderQuestion(index) {
        const q = QUESTOES_DATA[index];
        if (!q) return;

        // Atualiza contadores e barra de progresso
        currentStepEl.textContent = index + 1;
        categoryTagEl.textContent = q.categoria || `Fase ${index + 1}`;
        const pct = Math.round(((index + 1) / state.totalQuestions) * 100);
        progressFillEl.style.width = `${pct}%`;

        // Habilita/desabilita botão Anterior
        btnPrevEl.disabled = index === 0;

        // Animação suave de entrada
        questionBoxEl.classList.remove('fade-enter');
        void questionBoxEl.offsetWidth; // Força reflow
        questionBoxEl.classList.add('fade-enter');

        // Atualiza título da pergunta
        questionTitleEl.textContent = q.pergunta;

        // Limpa opções antigas
        optionsContainerEl.innerHTML = '';

        const letras = ['A', 'B', 'C', 'D'];

        q.respostas.forEach((resp, optIdx) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'quiz-option-btn';
            
            // Marca se já foi selecionada previamente
            if (state.respostas[index] === optIdx) {
                btn.classList.add('selected');
            }

            btn.innerHTML = `
                <div class="option-letter-badge">${letras[optIdx]}</div>
                <div class="option-text">${resp.texto}</div>
            `;

            btn.addEventListener('click', () => handleSelectOption(optIdx));
            optionsContainerEl.appendChild(btn);
        });
    }

    // Ao selecionar uma alternativa
    function handleSelectOption(optIdx) {
        if (state.isTransitioning) return;
        state.isTransitioning = true;

        state.respostas[state.currentIndex] = optIdx;

        // Feedback visual imediato no botão clicado
        const buttons = optionsContainerEl.querySelectorAll('.quiz-option-btn');
        buttons.forEach((btn, i) => {
            if (i === optIdx) {
                btn.classList.add('selected');
                btn.classList.add('pulse-select');
            } else {
                btn.classList.remove('selected');
            }
        });

        // Aguarda 350ms para o usuário ver a seleção e avança suavemente
        setTimeout(() => {
            if (state.currentIndex < state.totalQuestions - 1) {
                state.currentIndex++;
                renderQuestion(state.currentIndex);
                state.isTransitioning = false;
            } else {
                // Chegou ao fim do quiz! Inicia o cálculo e a tela de resultado
                concluirQuiz();
            }
        }, 360);
    }

    // Botão Voltar
    btnPrevEl.addEventListener('click', () => {
        if (state.isTransitioning || state.currentIndex === 0) return;
        state.currentIndex--;
        renderQuestion(state.currentIndex);
    });

    // Conclusão e Cálculo Ponderado
    function concluirQuiz() {
        // Exibe overlay com animação
        loadingOverlayEl.style.display = 'flex';
        loadingBarFillEl.style.width = '30%';

        const pontuacoes = {};
        if (Array.isArray(PERSONALIDADES_CHAVES)) {
            PERSONALIDADES_CHAVES.forEach(k => { pontuacoes[k] = 0; });
        }

        // Soma os pesos de todas as opções escolhidas
        state.respostas.forEach((opcaoIdx, qIdx) => {
            if (opcaoIdx !== null && QUESTOES_DATA[qIdx] && QUESTOES_DATA[qIdx].respostas[opcaoIdx]) {
                const pesos = QUESTOES_DATA[qIdx].respostas[opcaoIdx].pesos;
                for (const [id, pts] of Object.entries(pesos)) {
                    pontuacoes[id] = (pontuacoes[id] || 0) + pts;
                }
            }
        });

        // Descobre a cientista com mais pontos
        const ranking = Object.keys(pontuacoes).sort((a, b) => pontuacoes[b] - pontuacoes[a]);
        const vencedoraId = ranking[0] || 'adl';

        // Efeito narrativo de carregamento com mensagens dinâmicas
        setTimeout(() => {
            loadingStatusTextEl.textContent = "Cruzando com personalidades e livros biográficos...";
            loadingBarFillEl.style.width = '70%';
        }, 700);

        setTimeout(() => {
            loadingStatusTextEl.textContent = "Mapeando sua afinidade e personagens da cultura pop...";
            loadingBarFillEl.style.width = '95%';
        }, 1400);

        setTimeout(() => {
            // Salva dados no sessionStorage para estatísticas na página de resultado
            sessionStorage.setItem('quiz_resultado_id', vencedoraId);
            sessionStorage.setItem('quiz_ranking', JSON.stringify(ranking));
            sessionStorage.setItem('quiz_pontuacoes', JSON.stringify(pontuacoes));

            // Redireciona para a página de resultado da cientista encontrada
            window.location.href = `/resultado/${vencedoraId}`;
        }, 2100);
    }

    // Inicialização da primeira pergunta
    renderQuestion(0);
});
