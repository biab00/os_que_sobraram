/**
 * Caricaturas em Arte Vetorial SVG de Alta Qualidade e Reconhecimento Imediato
 * Inspiradas na linguagem visual lúdica e estilizada do 16Personalities e 64personality.
 * Cada avatar possui traços faciais expressivos, cortes de cabelo característicos,
 * vestimentas icônicas e adereços inconfundíveis para que qualquer pessoa identifique na hora!
 */

function getCaricaturaSvg(tipo, size = 120) {
    const s = size;
    const defs = `
        <defs>
            <filter id="shadow-soft" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity="0.25"/>
            </filter>
            <linearGradient id="grad-gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#FDE047"/><stop offset="100%" stop-color="#D97706"/></linearGradient>
            <linearGradient id="grad-silver" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#F8FAFC"/><stop offset="100%" stop-color="#94A3B8"/></linearGradient>
            <linearGradient id="bg-shuri" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#3B0764"/><stop offset="100%" stop-color="#7C3AED"/></linearGradient>
            <linearGradient id="bg-hermione" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#7F1D1D"/><stop offset="100%" stop-color="#B91C1C"/></linearGradient>
            <linearGradient id="bg-velma" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#C2410C"/><stop offset="100%" stop-color="#F97316"/></linearGradient>
            <linearGradient id="bg-penelope" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#9D174D"/><stop offset="100%" stop-color="#F43F5E"/></linearGradient>
            <linearGradient id="bg-uhura" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#991B1B"/><stop offset="100%" stop-color="#EF4444"/></linearGradient>
            <linearGradient id="bg-yang" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#075985"/><stop offset="100%" stop-color="#0284C7"/></linearGradient>
            <linearGradient id="bg-storm" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1E1B4B"/><stop offset="100%" stop-color="#4F46E5"/></linearGradient>
            <linearGradient id="bg-katniss" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#451A03"/><stop offset="100%" stop-color="#9A3412"/></linearGradient>
            <linearGradient id="bg-maeve" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#831843"/><stop offset="100%" stop-color="#EC4899"/></linearGradient>
            <linearGradient id="bg-lisa" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#B45309"/><stop offset="100%" stop-color="#F59E0B"/></linearGradient>
            <linearGradient id="bg-moana" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0E7490"/><stop offset="100%" stop-color="#06B6D4"/></linearGradient>
            <linearGradient id="bg-audrey" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#0369A1"/><stop offset="100%" stop-color="#38BDF8"/></linearGradient>
            <linearGradient id="bg-milo" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#78350F"/><stop offset="100%" stop-color="#D97706"/></linearGradient>
            <linearGradient id="bg-san" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#064E3B"/><stop offset="100%" stop-color="#10B981"/></linearGradient>
            <linearGradient id="bg-scully" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1E3A8A"/><stop offset="100%" stop-color="#3B82F6"/></linearGradient>
            <linearGradient id="bg-leia" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#1E40AF"/><stop offset="100%" stop-color="#60A5FA"/></linearGradient>
            <linearGradient id="bg-robin" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#581C87"/><stop offset="100%" stop-color="#8B5CF6"/></linearGradient>
            <linearGradient id="bg-annalise" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#4C1D95"/><stop offset="100%" stop-color="#A855F7"/></linearGradient>
            <linearGradient id="bg-murph" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#312E81"/><stop offset="100%" stop-color="#6366F1"/></linearGradient>
        </defs>
    `;

    const caricaturas = {
        // HERMIONE GRANGER - Cabelo castanho volumoso frisado, cachecol Grifinória, varinha acesa, livro
        hermione: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-hermione)"/>
            <!-- Cabelo volumoso frisado castanho -->
            <path d="M26 50 C20 18, 100 18, 94 50 C102 76, 88 88, 88 88 L32 88 C32 88, 18 76, 26 50 Z" fill="#5A2E0F"/>
            <!-- Rosto expressivo com queixo meigo -->
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Cachos frontais característicos -->
            <path d="M34 46 Q32 68 40 74 Q42 58 40 48 Z" fill="#78350F"/>
            <path d="M86 46 Q88 68 80 74 Q78 58 80 48 Z" fill="#78350F"/>
            <!-- Olhos brilhantes inteligentes -->
            <ellipse cx="51" cy="53" rx="3.5" ry="3.5" fill="#451A03"/><circle cx="52" cy="51.5" r="1.3" fill="#FFF"/>
            <ellipse cx="69" cy="53" rx="3.5" ry="3.5" fill="#451A03"/><circle cx="70" cy="51.5" r="1.3" fill="#FFF"/>
            <path d="M46 47 Q51 44 56 46" stroke="#451A03" stroke-width="2.2" fill="none"/>
            <path d="M64 46 Q69 44 74 47" stroke="#451A03" stroke-width="2.2" fill="none"/>
            <path d="M53 66 Q60 72 67 66" stroke="#9A3412" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Túnica de Hogwarts e Cachecol Vermelho e Dourado da Grifinória -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#18181B"/>
            <!-- Cachecol listrado -->
            <rect x="44" y="74" width="32" height="13" rx="3" fill="#991B1B"/>
            <rect x="49" y="74" width="6" height="13" fill="#FBBF24"/>
            <rect x="65" y="74" width="6" height="13" fill="#FBBF24"/>
            <polygon points="60,78 54,92 66,92" fill="#F8FAFC"/>
            <!-- Varinha de videira acesa com centelha mágica dourada -->
            <line x1="84" y1="74" x2="104" y2="44" stroke="#78350F" stroke-width="3.5" stroke-linecap="round"/>
            <polygon points="104,44 105,38 109,43 106,48" fill="#FDE047"/>
            <circle cx="106" cy="43" r="4" fill="#FACC15" opacity="0.6"/>
        `,

        // SHURI - Tranças afrofuturistas com contas, pintura facial, manoplas vibranium de pantera roxa
        shuri: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-shuri)"/>
            <!-- Tranças Afrofuturistas e Coque Alto -->
            <circle cx="60" cy="40" r="32" fill="#18181B"/>
            <circle cx="40" cy="22" r="10" fill="#262626"/><circle cx="80" cy="22" r="10" fill="#262626"/>
            <path d="M28 42 Q22 62 30 76 Q36 56 38 46 Z" fill="#262626"/>
            <path d="M92 42 Q98 62 90 76 Q84 56 82 46 Z" fill="#262626"/>
            <!-- Contas metálicas douradas nas tranças -->
            <rect x="26" y="58" width="5" height="4" rx="1" fill="#FCD34D"/>
            <rect x="89" y="58" width="5" height="4" rx="1" fill="#FCD34D"/>
            <!-- Rosto e Pele Negra Realce -->
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#6B4423"/>
            <!-- Pintura facial cerimonial branca/roxa -->
            <circle cx="48" cy="60" r="1.8" fill="#DDD6FE"/><circle cx="72" cy="60" r="1.8" fill="#DDD6FE"/>
            <circle cx="50" cy="64" r="1.4" fill="#DDD6FE"/><circle cx="70" cy="64" r="1.4" fill="#DDD6FE"/>
            <!-- Olhos brilhantes desafiadores -->
            <circle cx="52" cy="53" r="3.2" fill="#18181B"/><circle cx="53" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="68" cy="53" r="3.2" fill="#18181B"/><circle cx="69" cy="52" r="1.2" fill="#FFF"/>
            <path d="M54 66 Q60 72 66 66" stroke="#451A03" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Traje com gola alta e Manoplas de Pantera Vibranium -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#2E1065"/>
            <!-- Colar de garras de prata -->
            <polygon points="56,76 60,82 64,76" fill="#F8FAFC"/>
            <polygon points="50,75 53,80 56,75" fill="#F8FAFC"/>
            <polygon points="64,75 67,80 70,75" fill="#F8FAFC"/>
            <!-- Manopla de Pantera Roxa reluzente no peito -->
            <rect x="46" y="86" width="28" height="20" rx="6" fill="#7C3AED" stroke="#C084FC" stroke-width="2"/>
            <circle cx="52" cy="94" r="2.5" fill="#FDE047"/><circle cx="68" cy="94" r="2.5" fill="#FDE047"/>
            <polygon points="60,94 57,98 63,98" fill="#FFF"/>
        `,

        // VELMA DINKLEY - Cabelo chanel castanho com franja reta, óculos quadrados grossos, suéter gola alta laranja, lupa
        velma: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-velma)"/>
            <!-- Cabelo Castanho Bob / Chanel com Franja Reta -->
            <path d="M30 52 C28 26, 92 26, 90 52 C90 68, 84 76, 84 76 L36 76 C36 76, 30 68, 30 52 Z" fill="#78350F"/>
            <ellipse cx="60" cy="56" rx="20" ry="21" fill="#FDBA74"/>
            <!-- Franja reta e pontas chanel -->
            <rect x="36" y="40" width="48" height="8" rx="2" fill="#92400E"/>
            <!-- Sardinhas fofas nas bochechas -->
            <circle cx="46" cy="61" r="1.1" fill="#B45309"/><circle cx="49" cy="63" r="1.1" fill="#B45309"/>
            <circle cx="71" cy="63" r="1.1" fill="#B45309"/><circle cx="74" cy="61" r="1.1" fill="#B45309"/>
            <!-- Grandes Óculos Quadrados Pretos com Reflexo de Luz -->
            <rect x="40" y="47" width="17" height="14" rx="3" stroke="#0F172A" stroke-width="3.5" fill="#FFF" fill-opacity="0.3"/>
            <rect x="63" y="47" width="17" height="14" rx="3" stroke="#0F172A" stroke-width="3.5" fill="#FFF" fill-opacity="0.3"/>
            <line x1="57" y1="54" x2="63" y2="54" stroke="#0F172A" stroke-width="3.5"/>
            <!-- Reflexo branco nos óculos -->
            <line x1="43" y1="49" x2="49" y2="49" stroke="#FFF" stroke-width="2"/>
            <line x1="66" y1="49" x2="72" y2="49" stroke="#FFF" stroke-width="2"/>
            <circle cx="48" cy="54" r="2.8" fill="#0F172A"/>
            <circle cx="71" cy="54" r="2.8" fill="#0F172A"/>
            <path d="M54 68 Q60 73 66 68" stroke="#78350F" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Suéter Gola Alta Laranja Quente -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#EA580C"/>
            <rect x="48" y="72" width="24" height="12" rx="4" fill="#C2410C"/>
            <!-- Lupa clássica de detetive -->
            <circle cx="30" cy="88" r="9" stroke="#64748B" stroke-width="3" fill="#E2E8F0" fill-opacity="0.5"/>
            <line x1="24" y1="95" x2="16" y2="106" stroke="#78350F" stroke-width="4" stroke-linecap="round"/>
        `,

        // PENELOPE GARCIA - Cabelo loiro retrô com flor, óculos gatinho rosa neon, headset de hacker, batom pink
        penelope: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-penelope)"/>
            <!-- Cabelo Loiro Platinado volumoso com Franja -->
            <circle cx="60" cy="44" r="34" fill="#FDE047"/>
            <ellipse cx="60" cy="56" rx="22" ry="22" fill="#FED7AA"/>
            <!-- Flor amarela e rosa gigante no cabelo -->
            <circle cx="82" cy="28" r="11" fill="#F43F5E"/>
            <circle cx="82" cy="28" r="4.5" fill="#FEF08A"/>
            <!-- Óculos Gatinho Rosa Choque Marcantes -->
            <path d="M38 48 L42 45 L57 48 L57 58 L42 58 Z" stroke="#DB2777" stroke-width="3.5" fill="#FFF" fill-opacity="0.25"/>
            <path d="M82 48 L78 45 L63 48 L63 58 L78 58 Z" stroke="#DB2777" stroke-width="3.5" fill="#FFF" fill-opacity="0.25"/>
            <line x1="57" y1="52" x2="63" y2="52" stroke="#DB2777" stroke-width="3.5"/>
            <circle cx="49" cy="53" r="2.8" fill="#1E293B"/><circle cx="50" cy="52" r="1" fill="#FFF"/>
            <circle cx="71" cy="53" r="2.8" fill="#1E293B"/><circle cx="72" cy="52" r="1" fill="#FFF"/>
            <!-- Batom Pink vibrante sorridente -->
            <path d="M52 68 Q60 76 68 68" stroke="#BE185D" stroke-width="4" stroke-linecap="round" fill="none"/>
            <!-- Headset preto com haste curva e microfone -->
            <path d="M34 52 Q34 26 60 26 Q86 26 86 52" stroke="#0F172A" stroke-width="3.5" fill="none"/>
            <rect x="30" y="48" width="7" height="12" rx="3" fill="#0F172A"/>
            <path d="M34 56 Q34 72 48 72" stroke="#0F172A" stroke-width="2.5" fill="none"/>
            <circle cx="49" cy="72" r="3" fill="#F43F5E"/>
            <!-- Blusa colorida cheia de estilo -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#10B981"/>
            <circle cx="60" cy="88" r="6" fill="#FDE047"/>
        `,

        // TENENTE UHURA - Penteado anos 60 estelar, fone auricular prateado da Enterprise, uniforme vermelho com delta dourado
        uhura: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-uhura)"/>
            <!-- Penteado Afro / Bouffant anos 60 volumoso -->
            <ellipse cx="60" cy="40" rx="30" ry="26" fill="#18181B"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#78350F"/>
            <!-- Olhos imponentes e expressivos -->
            <ellipse cx="51" cy="53" rx="3.5" ry="3" fill="#18181B"/><circle cx="52" cy="52" r="1.2" fill="#FFF"/>
            <ellipse cx="69" cy="53" rx="3.5" ry="3" fill="#18181B"/><circle cx="70" cy="52" r="1.2" fill="#FFF"/>
            <path d="M53 67 Q60 74 67 67" stroke="#451A03" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Fone auricular de comunicação prateado estelar da Enterprise -->
            <circle cx="36" cy="54" r="5.5" fill="#E2E8F0" stroke="#0F172A" stroke-width="1.8"/>
            <line x1="36" y1="54" x2="48" y2="66" stroke="#CBD5E1" stroke-width="2.5"/>
            <!-- Uniforme Vermelho da Frota Estelar com Insígnia Dourada -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#DC2626"/>
            <polygon points="50,78 60,86 70,78" fill="#18181B"/>
            <!-- Delta Dourado de Comunicações da Starfleet -->
            <polygon points="54,88 56,83 58,88 56,86" fill="#FCD34D" stroke="#78350F" stroke-width="0.8"/>
        `,

        // DRA. CRISTINA YANG - Cabelo preto cirúrgico, estetoscópio Littmann no pescoço, jaleco/scrubs Seattle Grace com crachá
        yang: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-yang)"/>
            <!-- Cabelo Preto Ondulado preso com toca/rabo de cavalo -->
            <circle cx="60" cy="44" r="30" fill="#09090B"/>
            <ellipse cx="60" cy="56" rx="19" ry="22" fill="#FCD34D"/>
            <!-- Franja lateral rebelde -->
            <path d="M40 44 Q50 38 72 44" stroke="#09090B" stroke-width="4" stroke-linecap="round" fill="none"/>
            <!-- Olhos focados e atentos -->
            <ellipse cx="51" cy="53" rx="3.2" ry="2.5" fill="#09090B"/><circle cx="52" cy="52" r="1" fill="#FFF"/>
            <ellipse cx="69" cy="53" rx="3.2" ry="2.5" fill="#09090B"/><circle cx="70" cy="52" r="1" fill="#FFF"/>
            <path d="M53 66 Q60 70 67 66" stroke="#78350F" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <!-- Scrubs Azul Cirúrgico e Estetoscópio Littmann -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#0284C7"/>
            <!-- Tubo do estetoscópio contornando o pescoço -->
            <path d="M46 75 Q42 96 60 100 Q78 96 74 75" stroke="#1E293B" stroke-width="3.5" fill="none"/>
            <circle cx="60" cy="102" r="5" fill="#E2E8F0" stroke="#475569" stroke-width="2"/>
            <!-- Crachá médico de cirurgiã -->
            <rect x="68" y="84" width="12" height="15" rx="2" fill="#FFF" stroke="#CBD5E1" stroke-width="1"/>
            <rect x="71" y="86" width="6" height="3" fill="#0284C7"/>
        `,

        // TEMPESTADE (ORORO MUNROE) - Cabelo prateado flutuante, olhos brilhando raio elétrico, tiara preta com rubi
        storm: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-storm)"/>
            <!-- Cabelo Branco/Prateado Flutuante Tempestuoso -->
            <path d="M22 42 C16 12, 104 12, 98 42 C106 68, 92 84, 92 84 L28 84 C28 84, 14 68, 22 42 Z" fill="#F8FAFC" filter="url(#shadow-soft)"/>
            <ellipse cx="60" cy="56" rx="19" ry="22" fill="#582C10"/>
            <!-- Tiara Negra em V com Rubi no centro -->
            <polygon points="60,38 48,46 72,46" fill="#18181B"/>
            <circle cx="60" cy="42" r="2.5" fill="#E11D48"/>
            <!-- Olhos Brancos Reluzentes com Raio Cósmico -->
            <ellipse cx="51" cy="53" rx="4" ry="4" fill="#E0E7FF"/><circle cx="51" cy="53" r="2.5" fill="#FFF"/>
            <ellipse cx="69" cy="53" rx="4" ry="4" fill="#E0E7FF"/><circle cx="69" cy="53" r="2.5" fill="#FFF"/>
            <!-- Faíscas elétricas nos olhos -->
            <path d="M44 51 L47 54 L45 57" stroke="#60A5FA" stroke-width="1.8" fill="none"/>
            <path d="M76 51 L73 54 L75 57" stroke="#60A5FA" stroke-width="1.8" fill="none"/>
            <path d="M53 67 Q60 72 67 67" stroke="#3E1A00" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Traje dos X-Men com Capa e Broches Dourados com o 'X' -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#18181B"/>
            <circle cx="44" cy="80" r="4.5" fill="#FCD34D"/><circle cx="76" cy="80" r="4.5" fill="#FCD34D"/>
        `,

        // KATNISS EVERDEEN - Trança lateral no ombro, broche do Tordo Dourado na lapela, jaqueta de caça de couro, arco
        katniss: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-katniss)"/>
            <!-- Cabelo castanho com Trança Lateral clássica caindo no ombro -->
            <ellipse cx="60" cy="48" rx="28" ry="26" fill="#451A03"/>
            <path d="M78 52 Q88 68 82 86 Q76 102 78 112" stroke="#3E1A00" stroke-width="9" stroke-linecap="round" fill="none"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Olhos atentos cinzentos de caçadora -->
            <circle cx="51" cy="53" r="3.2" fill="#475569"/><circle cx="52" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="69" cy="53" r="3.2" fill="#475569"/><circle cx="70" cy="52" r="1.2" fill="#FFF"/>
            <path d="M54 67 Q60 71 66 67" stroke="#7C2D12" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <!-- Jaqueta de caça de couro marrom escuro -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#292524"/>
            <!-- Broche do Tordo Dourado (Mockingjay Pin) na lapela -->
            <circle cx="48" cy="88" r="6" fill="#F59E0B" stroke="#B45309" stroke-width="1.5"/>
            <polygon points="48,84 52,88 46,90 47,85" fill="#78350F"/>
            <!-- Arco e aljava de flechas nas costas -->
            <line x1="28" y1="65" x2="22" y2="105" stroke="#78350F" stroke-width="4" stroke-linecap="round"/>
        `,

        // MAEVE WILEY - Cabelo com mechas rosa choque, jaqueta biker de couro preto com zíperes, delineador gatinho
        maeve: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-maeve)"/>
            <!-- Cabelo Loiro com Pontas Pintadas de Rosa Choque -->
            <path d="M32 50 C30 28, 88 28, 86 50 C86 76, 76 80, 76 80 L44 80 C44 80, 32 76, 32 50 Z" fill="#FEF08A"/>
            <path d="M32 62 Q30 82 38 86" stroke="#EC4899" stroke-width="6" stroke-linecap="round"/>
            <path d="M86 62 Q88 82 80 86" stroke="#EC4899" stroke-width="6" stroke-linecap="round"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Delineador gatinho preto grosso característico -->
            <path d="M46 51 L56 51 L60 48" stroke="#09090B" stroke-width="2.8" fill="none"/>
            <path d="M64 51 L74 51 L78 48" stroke="#09090B" stroke-width="2.8" fill="none"/>
            <circle cx="52" cy="54" r="2.8" fill="#09090B"/>
            <circle cx="68" cy="54" r="2.8" fill="#09090B"/>
            <!-- Piercing de argolinha prateada no nariz e sorriso rebelde -->
            <circle cx="57" cy="61" r="1.5" fill="#E2E8F0"/>
            <path d="M54 67 Q60 70 66 67" stroke="#9A3412" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <!-- Jaqueta Biker de Couro Preto com Lapelas e Colar Choker -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#18181B"/>
            <rect x="52" y="74" width="16" height="3" fill="#09090B"/> <!-- Choker -->
            <line x1="48" y1="84" x2="60" y2="96" stroke="#94A3B8" stroke-width="2"/> <!-- Zíper -->
        `,

        // LISA SIMPSON - Cabelo estelar amarelo icônico pontiagudo, colar de pérolas brancas, vestido laranja, saxofone
        lisa: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-lisa)"/>
            <!-- Cabelo Estelar Amarelo em 8 Pontas Inconfundível -->
            <polygon points="60,18 67,26 77,22 80,32 90,34 86,44 94,50 84,56 60,60 36,56 26,50 34,44 30,34 40,32 43,22 53,26" fill="#FACC15"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FACC15"/>
            <!-- Grandes Olhos Cartoon com Cílios e Pupila -->
            <circle cx="49" cy="52" r="8" fill="#FFF" stroke="#1E293B" stroke-width="2"/>
            <circle cx="51" cy="52" r="2.8" fill="#1E293B"/>
            <circle cx="69" cy="52" r="8" fill="#FFF" stroke="#1E293B" stroke-width="2"/>
            <circle cx="71" cy="52" r="2.8" fill="#1E293B"/>
            <path d="M54 67 Q60 73 66 67" stroke="#A16207" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Colar de Pérolas Brancas Redondas -->
            <circle cx="46" cy="76" r="4" fill="#FFF" stroke="#CBD5E1" stroke-width="1"/>
            <circle cx="55" cy="79" r="4" fill="#FFF" stroke="#CBD5E1" stroke-width="1"/>
            <circle cx="65" cy="79" r="4" fill="#FFF" stroke="#CBD5E1" stroke-width="1"/>
            <circle cx="74" cy="76" r="4" fill="#FFF" stroke="#CBD5E1" stroke-width="1"/>
            <!-- Vestido Vermelho/Laranja e Saxofone Dourado -->
            <path d="M40 82 Q60 86 80 82 L86 114 L34 114 Z" fill="#EA580C"/>
            <!-- Saxofone barítono dourado -->
            <path d="M72 82 Q82 92 76 104 Q70 110 66 104 L68 96" stroke="#FBBF24" stroke-width="4" fill="none"/>
            <circle cx="78" cy="84" r="3" fill="#D97706"/>
        `,

        // MOANA - Cabelo ondulado longo com flor de hibisco vermelha, colar com Pedra do Coração de Te Fiti
        moana: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-moana)"/>
            <!-- Cabelo Ondulado Longo com Flor de Hibisco Vermelha -->
            <ellipse cx="60" cy="48" rx="32" ry="28" fill="#292524"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#92400E"/>
            <!-- Flor de hibisco no cabelo -->
            <circle cx="40" cy="34" r="9" fill="#EF4444"/>
            <circle cx="40" cy="34" r="3.5" fill="#FDE047"/>
            <!-- Olhos castanhos corajosos -->
            <circle cx="52" cy="53" r="3.5" fill="#1C1917"/><circle cx="53" cy="52" r="1.3" fill="#FFF"/>
            <circle cx="68" cy="53" r="3.5" fill="#1C1917"/><circle cx="69" cy="52" r="1.3" fill="#FFF"/>
            <path d="M53 67 Q60 74 67 67" stroke="#451A03" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Colar de corda com a Pedra do Coração de Te Fiti Verde Esmeralda -->
            <path d="M40 78 Q60 84 80 78 L86 114 L34 114 Z" fill="#DC2626"/>
            <circle cx="60" cy="85" r="5.5" fill="#10B981" stroke="#F8FAFC" stroke-width="2"/>
            <circle cx="60" cy="85" r="2.5" fill="#047857"/>
        `,

        // AUDREY RAMIREZ - Boné vermelho de lado, mancha de óleo na bochecha, chave inglesa na mão
        audrey: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-audrey)"/>
            <!-- Cabelo Preto Volumoso e Boné de Maquinista Vermelho Virado -->
            <ellipse cx="60" cy="46" rx="30" ry="24" fill="#09090B"/>
            <polygon points="34,38 20,43 36,49" fill="#DC2626"/> <!-- Aba do boné virada -->
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#A16207"/>
            <!-- Mancha charmosa de graxa/óleo na bochecha -->
            <ellipse cx="48" cy="62" rx="3.5" ry="1.8" fill="#1C1917" opacity="0.6"/>
            <!-- Olhos desafiadores e sorriso confiante -->
            <circle cx="52" cy="53" r="3.2" fill="#18181B"/><circle cx="53" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="68" cy="53" r="3.2" fill="#18181B"/><circle cx="69" cy="52" r="1.2" fill="#FFF"/>
            <path d="M53 67 Q60 72 67 67" stroke="#451A03" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Macacão de mecânica azul e chave de boca prateada -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#0284C7"/>
            <!-- Chave de boca de aço -->
            <rect x="76" y="68" width="5" height="22" rx="1.5" fill="#CBD5E1" stroke="#475569" stroke-width="1" transform="rotate(25 76 68)"/>
            <circle cx="75" cy="66" r="6" fill="#CBD5E1" stroke="#475569" stroke-width="1.5"/>
            <circle cx="75" cy="66" r="2.5" fill="#0369A1"/>
        `,

        // MILO THATCH - Óculos redondos enormes, mapa enrolado com bússola, casaco de tweed
        milo: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-milo)"/>
            <!-- Cabelo Castanho Desalinhado -->
            <path d="M36 46 C34 28, 86 28, 84 46 L82 58 L38 58 Z" fill="#92400E"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Óculos Redondos Enormes Icônicos -->
            <circle cx="47" cy="53" r="10" stroke="#1E293B" stroke-width="3" fill="#FFF" fill-opacity="0.25"/>
            <circle cx="73" cy="53" r="10" stroke="#1E293B" stroke-width="3" fill="#FFF" fill-opacity="0.25"/>
            <line x1="57" y1="53" x2="63" y2="53" stroke="#1E293B" stroke-width="3"/>
            <circle cx="47" cy="53" r="2.8" fill="#1E293B"/>
            <circle cx="73" cy="53" r="2.8" fill="#1E293B"/>
            <path d="M54 68 Q60 72 66 68" stroke="#9A3412" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <!-- Casaco marrom e mapa enrolado de pergaminho -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#B45309"/>
            <rect x="74" y="78" width="10" height="24" rx="3" fill="#FEF3C7" stroke="#B45309" stroke-width="1.5" transform="rotate(15 74 78)"/>
        `,

        // PRINCESA MONONOKE (SAN) - Capa de lobo branco, pintura facial vermelha guerreira, colar de presas
        san: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-san)"/>
            <!-- Capa e orelhas de Lobo Branco -->
            <circle cx="60" cy="44" r="32" fill="#F8FAFC"/>
            <polygon points="40,24 46,38 34,36" fill="#F8FAFC"/>
            <polygon points="80,24 86,36 74,38" fill="#F8FAFC"/>
            <ellipse cx="60" cy="56" rx="20" ry="21" fill="#FED7AA"/>
            <!-- Pintura facial guerreira vermelha (triângulos nas bochechas e testa) -->
            <polygon points="60,44 56,51 64,51" fill="#DC2626"/>
            <polygon points="43,56 39,65 47,65" fill="#DC2626"/>
            <polygon points="77,56 73,65 81,65" fill="#DC2626"/>
            <circle cx="52" cy="54" r="3.2" fill="#1C1917"/><circle cx="53" cy="53" r="1.2" fill="#FFF"/>
            <circle cx="68" cy="54" r="3.2" fill="#1C1917"/><circle cx="69" cy="53" r="1.2" fill="#FFF"/>
            <path d="M54 67 Q60 70 66 67" stroke="#7C2D12" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <path d="M40 78 Q60 84 80 78 L86 114 L34 114 Z" fill="#164E63"/>
        `,

        // DRA. DANA SCULLY - Cabelo ruivo bob anos 90, crachá do FBI dourado, olhar cético inteligente
        scully: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-scully)"/>
            <!-- Cabelo Ruivo Clássico Anos 90 -->
            <path d="M32 50 C30 28, 88 28, 86 50 C86 72, 78 76, 78 76 L42 76 C42 76, 32 72, 32 50 Z" fill="#C2410C"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Olhos azuis céticos e inteligentes -->
            <circle cx="51" cy="53" r="3.2" fill="#0284C7"/><circle cx="52" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="69" cy="53" r="3.2" fill="#0284C7"/><circle cx="70" cy="52" r="1.2" fill="#FFF"/>
            <path d="M46 47 Q51 44 56 47" stroke="#7C2D12" stroke-width="2.2" fill="none"/>
            <path d="M64 47 Q69 44 74 47" stroke="#7C2D12" stroke-width="2.2" fill="none"/>
            <path d="M54 67 Q60 70 66 67" stroke="#9A3412" stroke-width="2" stroke-linecap="round" fill="none"/>
            <!-- Terninho preto do FBI com crachá dourado -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#1E293B"/>
            <polygon points="60,78 52,94 68,94" fill="#F8FAFC"/>
            <!-- Crachá FBI com distintivo dourado -->
            <rect x="70" y="86" width="13" height="17" rx="2" fill="#E2E8F0" stroke="#475569" stroke-width="1"/>
            <circle cx="76.5" cy="94" r="3" fill="#F59E0B"/>
        `,

        // GENERAL LEIA ORGANA - Coques duplos laterais inconfundíveis, túnica branca da Aliança Rebelde
        leia: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-leia)"/>
            <!-- Coques laterais lendários da Princesa Leia -->
            <circle cx="28" cy="50" r="15" fill="#3E1A00" stroke="#1C1917" stroke-width="1.5"/>
            <circle cx="92" cy="50" r="15" fill="#3E1A00" stroke="#1C1917" stroke-width="1.5"/>
            <ellipse cx="60" cy="48" rx="26" ry="24" fill="#451A03"/>
            <ellipse cx="60" cy="56" rx="19" ry="21" fill="#FED7AA"/>
            <!-- Olhos nobres heróicos -->
            <circle cx="52" cy="53" r="3.2" fill="#1C1917"/><circle cx="53" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="68" cy="53" r="3.2" fill="#1C1917"/><circle cx="69" cy="52" r="1.2" fill="#FFF"/>
            <path d="M53 66 Q60 71 67 66" stroke="#9A3412" stroke-width="2.2" stroke-linecap="round" fill="none"/>
            <!-- Túnica Branca de Senadora e Cinto Prateado -->
            <path d="M38 77 Q60 83 82 77 L88 114 L32 114 Z" fill="#F8FAFC"/>
            <rect x="52" y="74" width="16" height="8" rx="2" fill="#E2E8F0"/>
            <rect x="42" y="96" width="36" height="6" fill="#CBD5E1" stroke="#94A3B8" stroke-width="1"/>
        `,

        // ROBIN BUCKLEY - Chapéu de marinheiro Scoops Ahoy, gravata borboleta vermelha, sorriso sagaz
        robin: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-robin)"/>
            <!-- Cabelo Loiro Curto Ondulado e Chapéu de Marinheiro 'AHOY' -->
            <ellipse cx="60" cy="50" rx="30" ry="26" fill="#FDE047"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <rect x="40" y="28" width="40" height="15" rx="4" fill="#F8FAFC" stroke="#1E3A8A" stroke-width="2.5"/>
            <text x="60" y="39" font-size="7.5" font-weight="900" fill="#1E3A8A" text-anchor="middle" letter-spacing="1">AHOY</text>
            <circle cx="51" cy="53" r="3.2" fill="#1E293B"/><circle cx="52" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="69" cy="53" r="3.2" fill="#1E293B"/><circle cx="70" cy="52" r="1.2" fill="#FFF"/>
            <path d="M53 66 Q60 72 67 66" stroke="#9A3412" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Uniforme da Sorveteria Scoops Ahoy e Gravata Borboleta Vermelha -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#1D4ED8"/>
            <polygon points="60,78 54,88 66,88" fill="#EF4444"/>
        `,

        // ANNALISE KEATING - Corte Chanel elegante escuro, blazer de alfaiataria bordô, postura de rainha do tribunal
        annalise: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-annalise)"/>
            <!-- Cabelo Curto e Elegante de Alfaiataria -->
            <path d="M36 50 C34 30, 86 30, 84 50 C84 64, 78 70, 78 70 L42 70 C42 70, 36 64, 36 50 Z" fill="#171717"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#5A3A22"/>
            <circle cx="52" cy="54" r="3.5" fill="#171717"/><circle cx="53" cy="53" r="1.2" fill="#FFF"/>
            <circle cx="68" cy="54" r="3.5" fill="#171717"/><circle cx="69" cy="53" r="1.2" fill="#FFF"/>
            <path d="M47 47 Q52 43 56 46" stroke="#171717" stroke-width="2.5" fill="none"/>
            <path d="M64 46 Q68 43 73 47" stroke="#171717" stroke-width="2.5" fill="none"/>
            <path d="M52 68 Q60 74 68 68" stroke="#451A03" stroke-width="3" stroke-linecap="round" fill="none"/>
            <!-- Blazer bordô e colar dourado de liderança -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#831843"/>
            <circle cx="60" cy="80" r="5" fill="#FCD34D"/>
        `,

        // MURPH COOPER - Rabo de cavalo castanho, jaqueta da NASA, relógio de pulso que transmite o código Morse
        murph: `
            <circle cx="60" cy="60" r="54" fill="url(#bg-murph)"/>
            <ellipse cx="60" cy="48" rx="28" ry="26" fill="#78350F"/>
            <circle cx="82" cy="44" r="8" fill="#5A2E0F"/>
            <ellipse cx="60" cy="56" rx="20" ry="22" fill="#FED7AA"/>
            <!-- Olhos focados e reflexivos -->
            <circle cx="51" cy="53" r="3.2" fill="#1C1917"/><circle cx="52" cy="52" r="1.2" fill="#FFF"/>
            <circle cx="69" cy="53" r="3.2" fill="#1C1917"/><circle cx="70" cy="52" r="1.2" fill="#FFF"/>
            <path d="M53 66 Q60 72 67 66" stroke="#9A3412" stroke-width="2.5" stroke-linecap="round" fill="none"/>
            <!-- Jaqueta prática de cientista da NASA e relógio de código Morse -->
            <path d="M38 78 Q60 84 82 78 L88 114 L32 114 Z" fill="#312E81"/>
            <rect x="28" y="86" width="12" height="15" rx="3" fill="#94A3B8" stroke="#1E293B" stroke-width="1.5"/>
            <circle cx="34" cy="93.5" r="3.5" fill="#1E293B"/>
        `
    };

    // Caso o tipo não seja encontrado, utiliza a caricatura padrão estilizada com fallback seguro
    const innerSvg = caricaturas[tipo] || caricaturas.hermione;

    return `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="${s}" height="${s}" class="caricatura-svg">
            ${defs}
            ${innerSvg}
        </svg>
    `.trim();
}

module.exports = { getCaricaturaSvg };
