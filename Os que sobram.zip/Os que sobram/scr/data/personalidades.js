/**
 * Base de Dados Completa e Expandida: Mulheres Protagonistas na Ciência, Tecnologia e Humanidades
 * Inclui: Biografias, Feitos Históricos, Livros com Capas, Filmes/Documentários com Trailers no YouTube
 * e Personagens da Cultura Pop com Caricaturas Estilizadas (Estilo 16Personalities / 64personality).
 */

const personalidades = {
    // 1. Ada Lovelace
    adl: {
        id: "adl",
        nome: "Ada Lovelace",
        nomeCompleto: "Augusta Ada King, Condessa de Lovelace",
        titulo: "A Visionária dos Algoritmos",
        subtitulo: "Primeira Programadora da História da Humanidade",
        area: "Ciência da Computação & Matemática",
        categoria: "tecnologia",
        epoca: "1815 – 1852",
        pais: "Reino Unido 🇬🇧",
        imagem: "Ada_Lovelace.jpg",
        citacao: "A imaginação é a faculdade de descobrir, acima de tudo. É ela que penetra nos mundos invisíveis ao nosso redor.",
        resumo: "Mente lógica primorosa combinada com imaginação poética. Você enxerga padrões invisíveis, une tecnologia com arte e projeta o futuro com décadas de antecedência.",
        feitos: "Escreveu em 1843 o primeiro algoritmo para ser executado por uma máquina mecânica (a Máquina Analítica de Babbage). Foi a primeira a prever que computadores manipulariam qualquer símbolo, antecipando softwares, música digital e IA há quase dois séculos.",
        caracteristicas: ["Pensamento Algorítmico", "Imaginação Poética", "Visão de Futuro", "Quebra de Paradigmas"],
        pontosFortes: [
            { titulo: "Conexão Interdisciplinar", desc: "Une matemática exata com poesia e humanidades." },
            { titulo: "Pioneirismo Conceitual", desc: "Projeta softwares para máquinas que ainda nem existiam." },
            { titulo: "Raciocínio Algorítmico", desc: "Clareza para estruturar problemas em passos lógicos." }
        ],
        tracos: { logica: 96, criatividade: 94, estrategia: 86, empatia: 76 },
        livros: [
            {
                titulo: "Ada Lovelace: A Condessa do Sonho Cósmico",
                autor: "Benjamin Woolley",
                ano: "2002",
                descricao: "Biografia fascinante sobre a formação matemática de Ada com Mary Somerville e sua colaboração histórica com Charles Babbage.",
                corCapa: "#7C3AED",
                badgeCapa: "Biografia Clássica"
            },
            {
                titulo: "Os Inovadores: Uma biografia da revolução digital",
                autor: "Walter Isaacson",
                ano: "2014",
                descricao: "Abre a história da computação destacando Ada Lovelace como a mente fundadora da programação mundial.",
                corCapa: "#4C1D95",
                badgeCapa: "Best-Seller"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Calculating Ada: The Countess of Computing",
                tipo: "Documentário BBC",
                ano: "2015",
                plataforma_ou_descricao: "Apresentado pela matemática Dra. Hannah Fry, investiga os cadernos de anotações originais e algoritmos de Ada.",
                trailerId: "FRlUJrEUn0Y"
            },
            {
                titulo: "Doctor Who: Spyfall",
                tipo: "Série Especial BBC",
                ano: "2020",
                plataforma_ou_descricao: "Ada Lovelace aparece como heroína ao lado da Doutora decifrando invasões cibernéticas.",
                trailerId: "pXqM6fMtz8U"
            }
        ],
        pop_culture: [
            {
                nome: "Shuri",
                obra: "Pantera Negra (Marvel)",
                papel: "Gênio da Tecnologia de Wakanda",
                motivo: "Cérebro por trás das maiores inovações de ponta, combinando código, criatividade e visão de vanguarda.",
                frase: "Só porque algo funciona, não significa que não possa ser melhorado com tecnologia!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            },
            {
                nome: "Penelope Garcia",
                obra: "Criminal Minds",
                papel: "Hacker & Analista Genial",
                motivo: "Domínio absoluto de redes e algoritmos, mantendo um coração caloroso, cores vibrantes e intuição humana.",
                frase: "Dê-me um terminal e eu te entrego o universo decodificado!",
                caricaturaTipo: "penelope",
                corBadge: "#EC4899"
            },
            {
                nome: "Velma Dinkley",
                obra: "Scooby-Doo",
                papel: "O Cérebro Lógico da Turma",
                motivo: "Não aceita superstições: resolve mistérios com evidências palpáveis, lógica dedutiva e checagem metódica.",
                frase: "Jinkies! Encontrei o padrão exato que desvenda todo o mistério!",
                caricaturaTipo: "velma",
                corBadge: "#EA580C"
            }
        ]
    },

    // 2. Marie Curie
    mcr: {
        id: "mcr",
        nome: "Marie Curie",
        nomeCompleto: "Marie Salomea Skłodowska Curie",
        titulo: "A Desbravadora do Átomo",
        subtitulo: "A Única Pessoa Laureada com Dois Prêmios Nobel em Ciências Distintas",
        area: "Física & Química Nuclear",
        categoria: "exatas",
        epoca: "1867 – 1934",
        pais: "Polônia 🇵🇱 / França 🇫🇷",
        imagem: "Marie_Curie.jpg",
        citacao: "Nada na vida deve ser temido, apenas compreendido. Agora é a hora de compreender mais, para que possamos temer menos.",
        resumo: "Determinação inabalável, rigor metódico e coragem absoluta. Quando você se propõe a desvendar um enigma, nenhuma adversidade é grande demais.",
        feitos: "Descobriu os elementos químicos Polônio e Rádio, cunhou o termo 'radioatividade' e foi a única pessoa da história a conquistar dois Prêmios Nobel em ciências diferentes (Física 1903 e Química 1911). Na 1ª Guerra Mundial, desenvolveu ambulâncias radiológicas móveis que salvaram mais de um milhão de soldados feridos.",
        caracteristicas: ["Rigor Experimental", "Resiliência Inabalável", "Curiosidade Destemida", "Altruísmo Científico"],
        pontosFortes: [
            { titulo: "Foco Obsessivo", desc: "Disciplina de ferro em investigações laboratoriais exaustivas." },
            { titulo: "Coragem Moral", desc: "Enfrentou perseguições e preconceitos mantendo a integridade da pesquisa." },
            { titulo: "Altruísmo Tecnológico", desc: "Não patenteou o isolamento do rádio para que a medicina pudesse usá-lo livremente." }
        ],
        tracos: { logica: 98, criatividade: 82, estrategia: 90, empatia: 84 },
        livros: [
            {
                titulo: "Madame Curie: Uma Biografia",
                autor: "Ève Curie",
                ano: "1937",
                descricao: "Escrita comovente de sua filha que revela a vida íntima, a genialidade no laboratório e a paixão inesgotável pela ciência.",
                corCapa: "#1E3A8A",
                badgeCapa: "Clássico Histórico"
            },
            {
                titulo: "Radioativo: Marie & Pierre Curie",
                autor: "Lauren Redniss",
                ano: "2010",
                descricao: "Biografia visual ilustrada com arte luminescente indicada ao National Book Award.",
                corCapa: "#065F46",
                badgeCapa: "Arte & Ciência"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Radioactive",
                tipo: "Filme / Cinebiografia",
                ano: "2019",
                plataforma_ou_descricao: "Estrelado por Rosamund Pike e dirigido por Marjane Satrapi, dramatiza seus triunfos e dilemas atômicos.",
                trailerId: "aVw-Z5t_G0E"
            },
            {
                titulo: "Marie Curie: A Coragem do Conhecimento",
                tipo: "Filme Europeu",
                ano: "2016",
                plataforma_ou_descricao: "Retrata os anos cruciais entre a conquista do primeiro e do segundo Nobel e sua luta contra o machismo acadêmico.",
                trailerId: "e9J8oXpM30k"
            }
        ],
        pop_culture: [
            {
                nome: "Hermione Granger",
                obra: "Harry Potter",
                papel: "A Mente Mais Brilhante de Hogwarts",
                motivo: "Estudo metódico incansável, valorização da lógica e coragem sem limites em prol do bem comum.",
                frase: "Quando estiver em dúvida, vá para a biblioteca e descubra a verdade empírica!",
                caricaturaTipo: "hermione",
                corBadge: "#DC2626"
            },
            {
                nome: "Dra. Dana Scully",
                obra: "Arquivo X (The X-Files)",
                papel: "Médica & Cientista Forense",
                motivo: "Defensora do método científico, exige evidências e fatos para decifrar qualquer fenômeno.",
                frase: "A ciência tem respostas para o desconhecido, desde que façamos as perguntas certas.",
                caricaturaTipo: "scully",
                corBadge: "#2563EB"
            },
            {
                nome: "Amy Farrah Fowler",
                obra: "The Big Bang Theory",
                papel: "Neurobiologista Laureada com o Nobel",
                motivo: "Paixão pura pelo método de bancada, inteligência afiada e orgulho de ser cientista.",
                frase: "O cérebro é o único órgão capaz de pesquisar a si mesmo!",
                caricaturaTipo: "amy",
                corBadge: "#059669"
            }
        ]
    },

    // 3. Grace Hopper
    gho: {
        id: "gho",
        nome: "Grace Hopper",
        nomeCompleto: "Contra-Almirante Grace Brewster Murray Hopper",
        titulo: "A Rainha do Código",
        subtitulo: "Pioneira do Primeiro Compilador e da Linguagem COBOL",
        area: "Ciência da Computação & Engenharia de Software",
        categoria: "tecnologia",
        epoca: "1906 – 1992",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "A frase mais perigosa na linguagem humana é: 'Sempre fizemos assim'.",
        resumo: "Pioneira rebelde, pragmática e destemida. Você questiona dogmas, ensina máquinas a falarem nossa linguagem e quebra barreiras militares e tecnológicas.",
        feitos: "Criou o primeiro compilador da história da computação (o A-0), transformando código em linguagem legível para humanos. Liderou a criação do COBOL (linguagem que até hoje processa transações bancárias no mundo inteiro) e popularizou o termo 'bug' após encontrar uma mariposa real dentro dos circuitos do computador Mark II.",
        caracteristicas: ["Pioneirismo em Compiladores", "Inovação Linguística", "Liderança Militar Tecnológica", "Inconformismo Positivo"],
        pontosFortes: [
            { titulo: "Acessibilidade do Software", desc: "Criou ferramentas para que humanos pudessem programar sem falar apenas em zeros e uns binários." },
            { titulo: "Didática e Liderança", desc: "Ensinou e inspirou gerações inteiras de engenheiros na Marinha americana e na indústria." },
            { titulo: "Desafio a Dogmas", desc: "Desmontava rotinas ultrapassadas com humor perspicaz e lógica impecável." }
        ],
        tracos: { logica: 97, criatividade: 93, estrategia: 95, empatia: 85 },
        livros: [
            {
                titulo: "Grace Hopper: Queen of Computer Code",
                autor: "Laurie Wallmark",
                ano: "2017",
                descricao: "Biografia premiada que retrata a infância curiosa e as conquistas monumentais da mulher que ensinou computadores a falarem.",
                corCapa: "#1E40AF",
                badgeCapa: "Pioneirismo"
            },
            {
                titulo: "Broad Band: As Pioneiras Invisíveis da Internet",
                autor: "Claire L. Evans",
                ano: "2018",
                descricao: "Destaque para a trajetória da Contra-Almirante Hopper na revolução da computação eletrônica.",
                corCapa: "#9333EA",
                badgeCapa: "História Tecnológica"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "The Queen of Code",
                tipo: "Documentário ESPN / 538",
                ano: "2015",
                plataforma_ou_descricao: "Dirigido por Gillian Jacobs, documentário ágil sobre a vida e o humor afiado de Grace Hopper.",
                trailerId: "1kbcoC4kS9Y"
            }
        ],
        pop_culture: [
            {
                nome: "Tenente Uhura",
                obra: "Star Trek",
                papel: "Mestra das Comunicações Interestelares",
                motivo: "Comanda a tecnologia de tradução e protocolos de dados com serenidade e maestria militar.",
                frase: "Frequências abertas em todos os canais da galáxia!",
                caricaturaTipo: "uhura",
                corBadge: "#D97706"
            },
            {
                nome: "Audrey Ramirez",
                obra: "Atlantis: O Reino Perdido",
                papel: "Engenheira & Mecânica Chefe",
                motivo: "Faz qualquer máquina gigante funcionar com precisão e não aceita desculpas de quem diz que é impossível.",
                frase: "Se está quebrado, a gente conserta e faz rodar melhor ainda!",
                caricaturaTipo: "audrey",
                corBadge: "#0284C7"
            },
            {
                nome: "Entrapta",
                obra: "She-Ra e as Princesas do Poder",
                papel: "Cientista Tecnológica Entusiasta",
                motivo: "Ama circuitos, programação e máquinas com entusiasmo contagiante e paixão por entender cada detalhe.",
                frase: "Erros são maravilhosos! Eles nos mostram como reprogramar o sistema!",
                caricaturaTipo: "entrapta",
                corBadge: "#EC4899"
            }
        ]
    },

    // 4. Margaret Hamilton
    mha: {
        id: "mha",
        nome: "Margaret Hamilton",
        nomeCompleto: "Margaret Heafield Hamilton",
        titulo: "A Arquiteta do Código Lunar",
        subtitulo: "Diretora de Engenharia de Software da Missão Apollo da NASA",
        area: "Engenharia de Software & Ciência Aeroespacial",
        categoria: "tecnologia",
        epoca: "1936 – Presente",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Não havia uma segunda chance. O software tinha que funcionar perfeitamente na primeira tentativa.",
        resumo: "Padrão de rigor absoluto, criatividade arquitetural e serenidade sob pressão extrema. Seu código salvou o primeiro pouso humano na Lua.",
        feitos: "Diretora da Divisão de Engenharia de Software do Laboratório Draper do MIT, responsável por desenvolver o software embarcado de navegação e controle de voo do Projeto Apollo. Minutos antes do pouso da Apollo 11 na Lua, o computador foi sobrecarregado por dados falsos de radar, mas a arquitetura de prioridade assíncrona criada por Hamilton priorizou os comandos vitais de descida, evitando um aborto catastrófico da missão.",
        caracteristicas: ["Rigor Arquitetural Máximo", "Engenharia Assíncrona", "Previsão de Falhas", "Pioneirismo no Termo Software"],
        pontosFortes: [
            { titulo: "Arquitetura à Prova de Falhas", desc: "Criou sistemas projetados para detectar e recuperar-se de erros humanos e de sensores em tempo real." },
            { titulo: "Criação de Disciplina", desc: "Cunhou o termo 'Software Engineering' quando a programação ainda não era considerada uma engenharia formal." },
            { titulo: "Foco Sob Pressão Histórica", desc: "Permitiu que a humanidade pisasse na Lua com segurança total de sistemas." }
        ],
        tracos: { logica: 99, criatividade: 90, estrategia: 97, empatia: 82 },
        livros: [
            {
                titulo: "Margaret and the Moon",
                autor: "Dean Robbins",
                ano: "2017",
                descricao: "Livro aclamado sobre a mente pioneira de Margaret e o software fundamental que levou os astronautas à superfície lunar.",
                corCapa: "#0369A1",
                badgeCapa: "Infanto-Juvenil & Histórico"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Margaret Hamilton: The Apollo Software Engineer Who Saved the Moon Landing",
                tipo: "Documentário / Makers",
                ano: "2019",
                plataforma_ou_descricao: "Depoimentos históricos e bastidores técnicos da NASA sobre como o código de Margaret salvou a missão Apollo 11.",
                trailerId: "Bff2X-y1xVU"
            }
        ],
        pop_culture: [
            {
                nome: "Murph Cooper",
                obra: "Interestelar",
                papel: "Astrofísica da NASA",
                motivo: "Decifra os dados da gravidade com códigos precisos para garantir a viagem e sobrevivência espacial.",
                frase: "Eu sabia que o código revelaria o caminho para as estrelas!",
                caricaturaTipo: "murph",
                corBadge: "#6366F1"
            },
            {
                nome: "Shuri",
                obra: "Pantera Negra",
                papel: "Engenheira de Sistemas de Wakanda",
                motivo: "Projeta softwares e naves com camadas redundantes de proteção que nunca falham.",
                frase: "Minha arquitetura de dados não cai nem com o universo tremendo!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            },
            {
                nome: "Dra. Samantha Carter",
                obra: "Stargate SG-1",
                papel: "Astrofísica & Engenheira de Software",
                motivo: "Escreve algoritmos de controle de navegação e portais interdimensionais com frieza milimétrica.",
                frase: "O software é o único mapa seguro para atravessar o desconhecido!",
                caricaturaTipo: "carter",
                corBadge: "#3B82F6"
            }
        ]
    },

    // 5. Katherine Johnson
    kjh: {
        id: "kjh",
        nome: "Katherine Johnson",
        nomeCompleto: "Creola Katherine Johnson",
        titulo: "A Mente dos Cálculos Orbitais",
        subtitulo: "A Matemática que Calculou as Trajetórias da NASA para a Lua",
        area: "Matemática Aplicada & Mecânica Celeste",
        categoria: "exatas",
        epoca: "1918 – 2020",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Goste do que faz, e então você fará o seu melhor.",
        resumo: "Precisão geométrica transcendental, calma olímpica e autoridade intelectual irrefutável. Até os computadores eletrônicos precisavam da confirmação dela.",
        feitos: "Calculou manualmente as trajetórias de voo, janelas de lançamento e rotas de retorno da missão de Alan Shepard (primeiro americano no espaço) e da Apollo 11 à Lua. O astronauta John Glenn exigiu pessoalmente que Katherine checasse à mão os cálculos do computador IBM antes de embarcar na cápsula da missão Friendship 7: 'Se ela disser que os números estão certos, estou pronto para voar'.",
        caracteristicas: ["Geometria Espacial Perfeita", "Precisão Absoluta", "Resiliência Histórica", "Autoridade Científica"],
        pontosFortes: [
            { titulo: "Cálculo Orbital Manual", desc: "Capacidade sem precedentes de calcular mecânica celeste e trajetórias parabólicas complexas." },
            { titulo: "Quebra da Segregação", desc: "Superou o racismo institucional e o machismo com uma competência que ninguém ousava questionar." },
            { titulo: "Confiança dos Astronautas", desc: "Era a última palavra de segurança para lançamentos tripulados da NASA." }
        ],
        tracos: { logica: 99, criatividade: 88, estrategia: 94, empatia: 92 },
        livros: [
            {
                titulo: "Estrelas Além do Tempo",
                autor: "Margot Lee Shetterly",
                ano: "2016",
                descricao: "História arrebatadora de Katherine Johnson, Dorothy Vaughan e Mary Jackson e seu papel monumental na corrida espacial.",
                corCapa: "#B45309",
                badgeCapa: "Best-Seller Mundial"
            },
            {
                titulo: "Minha Trajetória: Memórias de uma Pioneira da NASA",
                autor: "Katherine Johnson",
                ano: "2021",
                descricao: "Autobiografia emocionante de Katherine contando sua infância em Virgínia Ocidental até a Medalha Presidencial da Liberdade.",
                corCapa: "#1E3A8A",
                badgeCapa: "Autobiografia Oficial"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Estrelas Além do Tempo (Hidden Figures)",
                tipo: "Filme / 3 Indicações ao Oscar",
                ano: "2016",
                plataforma_ou_descricao: "Taraji P. Henson brilha como Katherine Johnson, demonstrando sua genialidade matemática inabalável.",
                trailerId: "5wfrDhgUMGI"
            }
        ],
        pop_culture: [
            {
                nome: "Hermione Granger",
                obra: "Harry Potter",
                papel: "A Mente Mais Precisa",
                motivo: "Seus cálculos e conhecimentos nunca falham: todos recorrem a ela quando a vida está em risco.",
                frase: "Os números não mentem quando o método é exato!",
                caricaturaTipo: "hermione",
                corBadge: "#DC2626"
            },
            {
                nome: "General Leia Organa",
                obra: "Star Wars",
                papel: "Líder Heroica e Estrategista",
                motivo: "Mantém a serenidade imperturbável mesmo quando a galáxia inteira depende de suas decisões.",
                frase: "A esperança e a matemática andam juntas quando sabemos o rumo a tomar!",
                caricaturaTipo: "leia",
                corBadge: "#2563EB"
            },
            {
                nome: "Milo Thatch",
                obra: "Atlantis",
                papel: "O Mestre dos Cálculos e Coordenadas",
                motivo: "Paciência e precisão milimétrica para calcular caminhos impossíveis que outros desacreditavam.",
                frase: "As coordenadas estão verificadas e corretas até o último decimal!",
                caricaturaTipo: "milo",
                corBadge: "#D97706"
            }
        ]
    },

    // 6. Hedy Lamarr
    hla: {
        id: "hla",
        nome: "Hedy Lamarr",
        nomeCompleto: "Hedwig Eva Maria Kiesler",
        titulo: "A Inventora do Salto de Frequência",
        subtitulo: "A Mente Visionária por Trás do Wi-Fi, Bluetooth e GPS",
        area: "Engenharia de Telecomunicações & Invenção",
        categoria: "tecnologia",
        epoca: "1914 – 2000",
        pais: "Áustria 🇦🇹 / Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "A esperança e a curiosidade sobre o futuro me pareciam muito melhores do que olhar para trás.",
        resumo: "Mente brilhante por trás de uma estrela do cinema. Você desconstrói preconceitos de aparências e cria inovações de comunicação que conectam o mundo moderno.",
        feitos: "Além de estrela do cinema clássico de Hollywood, patenteou em 1942, com o compositor George Antheil, um sistema secreto de comunicações baseado em 'espalhamento espectral por salto de frequência' para impedir que torpedos aliados fossem interceptados por rádios nazistas. Sua invenção revolucionária é o alicerce fundamental de todas as tecnologias sem fio modernas, como o Wi-Fi, o Bluetooth e a telefonia celular CDMA/5G.",
        caracteristicas: ["Engenhosidade de Telecomunicações", "Criatividade Interdisciplinar", "Superação de Estereótipos", "Pioneirismo Sem Fio"],
        pontosFortes: [
            { titulo: "Engenhosidade Criptográfica", desc: "Criou o salto de frequências sincronizado por rolos de pianola para proteger sinais." },
            { titulo: "Quebra da Dupla Vida", desc: "Atuava nos estúdios de dia e projetava invenções tecnológicas em sua oficina à noite." },
            { titulo: "Conexão Tecnológica Global", desc: "Suas patentes sustentam toda a comunicação sem fio da humanidade contemporânea." }
        ],
        tracos: { logica: 95, criatividade: 98, estrategia: 91, empatia: 86 },
        livros: [
            {
                titulo: "Hedy's Folly: The Life and Breakthrough Inventions of Hedy Lamarr",
                autor: "Richard Rhodes (Vencedor do Prêmio Pulitzer)",
                ano: "2011",
                descricao: "Relato aprofundado sobre o gênio inventivo de Hedy Lamarr e a invenção do salto de frequência para torpedos.",
                corCapa: "#831843",
                badgeCapa: "Pulitzer Prize Author"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Bombshell: The Hedy Lamarr Story",
                tipo: "Documentário Premiado",
                ano: "2017",
                plataforma_ou_descricao: "Produzido por Susan Sarandon, revela gravações inéditas em áudio de Hedy falando sobre suas patentes secretas.",
                trailerId: "Bmm7c3Wz6oM"
            }
        ],
        pop_culture: [
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "A Mente Brilhante que Ninguém Esperava",
                motivo: "Beleza e inteligência afiada juntas: desfaz qualquer julgamento preconceituoso em segundos com argumentos e ideias.",
                frase: "Nunca me julgue pela casca: meu cérebro é muito mais rápido do que você imagina!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "Robin Buckley",
                obra: "Stranger Things",
                papel: "Mestra dos Códigos e Frequências",
                motivo: "Decodifica transmissões de rádio secretas com facilidade e inventividade descontraída.",
                frase: "Sintonizei a frequência certa! Os segredos estão todos aqui abertos!",
                caricaturaTipo: "robin",
                corBadge: "#8B5CF6"
            },
            {
                nome: "Shuri",
                obra: "Pantera Negra",
                papel: "Inventora de Comunicações Holográficas",
                motivo: "Cria ferramentas sem fio que conectam o reino e surpreendem o mundo com elegância.",
                frase: "Minhas frequências são indetectáveis por qualquer radar comum!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            }
        ]
    },

    // 7. Rosalind Franklin
    rfr: {
        id: "rfr",
        nome: "Rosalind Franklin",
        nomeCompleto: "Rosalind Elsie Franklin",
        titulo: "A Reveladora da Hélice da Vida",
        subtitulo: "A Cristalógrafa Fundamental na Descoberta da Estrutura do DNA",
        area: "Biofísica, Cristalografia de Raios-X & Química",
        categoria: "biologicas",
        epoca: "1920 – 1958",
        pais: "Reino Unido 🇬🇧",
        imagem: "sem_foto.png",
        citacao: "A ciência e a vida cotidiana não podem nem devem ser separadas.",
        resumo: "Rigor técnico incomparável, perfeccionismo laboratorial e justiça histórica. Sua famosa 'Foto 51' revelou o segredo da genética mundial.",
        feitos: "Especialista em difração de raios-X, produziu a icônica 'Foto 51' no King's College London, que forneceu a prova física e geométrica fundamental de que o DNA possuía estrutura em dupla hélice. Conduziu também estudos pioneiros fundamentais sobre a estrutura do vírus do mosaico do tabaco e do vírus da poliomielite antes de seu falecimento precoce aos 37 anos.",
        caracteristicas: ["Precisão Cristalográfica", "Perfeccionismo Metodológico", "Integridade Científica", "Biofísica Viral"],
        pontosFortes: [
            { titulo: "A Imagem Mais Famosa da Biologia", desc: "Obteve a Foto 51 através de meses de aperfeiçoamento da câmera de raios-X e controle de hidratação." },
            { titulo: "Pioneirismo em Virologia", desc: "Mapeou o arranjo helicoidal de proteínas em vírus patogênicos de forma pioneira." },
            { titulo: "Dedicação Científica Integral", desc: "Manteve o trabalho ativo em pesquisas vitais até seus últimos dias." }
        ],
        tracos: { logica: 97, criatividade: 86, estrategia: 89, empatia: 88 },
        livros: [
            {
                titulo: "Rosalind Franklin: The Dark Lady of DNA",
                autor: "Brenda Maddox",
                ano: "2002",
                descricao: "Biografia definitiva e premiada que fez justiça histórica ao resgatar o protagonismo de Franklin na genética moderna.",
                corCapa: "#047857",
                badgeCapa: "Biografia Definitiva"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Rosalind Franklin: DNA's Dark Lady",
                tipo: "Documentário PBS / NOVA",
                ano: "2003",
                plataforma_ou_descricao: "Investiga os bastidores do laboratório do King's College e o papel decisivo da Foto 51.",
                trailerId: "0tmNf6ec2kU"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Dana Scully",
                obra: "Arquivo X",
                papel: "Patologista & Médica Forense",
                motivo: "Não descansa enquanto as imagens microscópicas e evidências não provarem a verdade com certeza absoluta.",
                frase: "A verdade biológica está gravada no DNA e nas evidências sob a luz!",
                caricaturaTipo: "scully",
                corBadge: "#2563EB"
            },
            {
                nome: "Gemma Simmons",
                obra: "Agents of S.H.I.E.L.D.",
                papel: "Bioquímica Genial",
                motivo: "Capaz de decodificar estruturas macromoleculares e vírus perigosos em tempo recorde.",
                frase: "A estrutura de uma molécula conta a história inteira de um organismo!",
                caricaturaTipo: "simmons",
                corBadge: "#10B981"
            },
            {
                nome: "Dra. Helen Cho",
                obra: "Vingadores: Era de Ultron",
                papel: "Geneticista & Bióloga Molecular",
                motivo: "Manipula hélices genéticas com perfeição para recriar e decodificar a vida celular.",
                frase: "As hélices da vida guardam os maiores segredos da regeneração!",
                caricaturaTipo: "helen_cho",
                corBadge: "#0284C7"
            }
        ]
    },

    // 8. Nise da Silveira
    nsi: {
        id: "nsi",
        nome: "Nise da Silveira",
        nomeCompleto: "Dra. Nise da Silveira",
        titulo: "A Revolucionária da Psique e do Afeto",
        subtitulo: "Médica Psiquiatra que Transformou a Saúde Mental através da Arte",
        area: "Psiquiatria, Terapia Ocupacional & Psicologia Analítica",
        categoria: "saude",
        epoca: "1905 – 1999",
        pais: "Brasil 🇧🇷 (Maceió, AL / Rio de Janeiro, RJ)",
        imagem: "sem_foto.png",
        citacao: "Não se curem além da conta. Gente curada demais é gente chata. Todo mundo tem um pouco de loucura e muita beleza.",
        resumo: "Coragem rebelde humanista, empatia profunda e respeito sagrado pela sensibilidade humana. Você recusa métodos violentos e cura através do afeto e da arte.",
        feitos: "Recusou-se radicalmente a aplicar eletrochoques, lobotomias e camisas de força nos pacientes psiquiátricos do Hospital de Engenho de Dentro no Rio de Janeiro. Criou a Seção de Terapêutica Ocupacional, onde os internos expressavam suas dores através de pinturas e esculturas que revelavam o inconsciente, ganhando admiração direta de Carl Gustav Jung. Fundou o Museu de Imagens do Inconsciente e a Casa das Palmeiras, além de ser pioneira mundial no uso de cães e gatos como coterapeutas afetivos.",
        caracteristicas: ["Humanização da Medicina", "Pioneirismo Terapêutico", "Coragem Antimanicomial", "Conexão com Animais"],
        pontosFortes: [
            { titulo: "Revolução Humanitária", desc: "Substituiu a violência psiquiátrica tradicional pela dignidade da expressão artística." },
            { titulo: "Reconhecimento de Jung", desc: "Manteve correspondência e estudos diretos com Carl Jung sobre os arquétipos universais na arte dos pacientes." },
            { titulo: "Coterapia com Animais", desc: "Primeira pesquisadora a introduzir animais de afeto como suporte terapêutico no Brasil." }
        ],
        tracos: { logica: 88, criatividade: 99, estrategia: 92, empatia: 100 },
        livros: [
            {
                titulo: "Imagens do Inconsciente",
                autor: "Nise da Silveira",
                ano: "1981",
                descricao: "Obra-prima mundial da psiquiatria e psicologia analítica, analisando as pinturas e símbolos criados pelos seus pacientes.",
                corCapa: "#B91C1C",
                badgeCapa: "Obra-Prima Brasileira"
            },
            {
                titulo: "Gatos: A Emoção de Lidar",
                autor: "Nise da Silveira",
                ano: "1998",
                descricao: "Livro afetuoso e filosófico sobre os animais como companheiros de cura e harmonia psíquica.",
                corCapa: "#0D9488",
                badgeCapa: "Afeto & Coterapia"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Nise: O Coração da Loucura",
                tipo: "Filme / Longa-Metragem Premiado",
                ano: "2015",
                plataforma_ou_descricao: "Glória Pires interpreta Dra. Nise em atuação monumental premiada internacionalmente no Festival de Tóquio.",
                trailerId: "g8yX5z7rZgA"
            },
            {
                titulo: "Olhar de Nise",
                tipo: "Documentário Nacional",
                ano: "2016",
                plataforma_ou_descricao: "Registros históricos e entrevistas originais sobre a revolução do afeto iniciada no Engenho de Dentro.",
                trailerId: "w_i8JbK7G8M"
            }
        ],
        pop_culture: [
            {
                nome: "Katara",
                obra: "Avatar: A Lenda de Aang",
                papel: "Mestra Curadora das Emoções",
                motivo: "Rejeita a violência, enxerga a dor mais íntima das pessoas e cura feridas da alma com acolhimento e amor.",
                frase: "A cura verdadeira começa pelo respeito à dor e pela esperança!",
                caricaturaTipo: "katara",
                corBadge: "#2563EB"
            },
            {
                nome: "Princesa Mononoke (San)",
                obra: "Studio Ghibli",
                papel: "Protetora da Sensibilidade e dos Animais",
                motivo: "Amor puro pelos animais e determinação inquebrável em proteger os seres incompreendidos pelo mundo.",
                frase: "Os animais e os seres sensíveis merecem paz, dignidade e respeito!",
                caricaturaTipo: "san",
                corBadge: "#059669"
            },
            {
                nome: "Alegria & Empatia",
                obra: "Divertida Mente",
                papel: "Guardiã dos Sentimentos",
                motivo: "Compreende que todas as emoções — inclusive a tristeza — têm beleza e precisam de espaço para curar o ser.",
                frase: "Ouvir com carinho é o melhor remédio para qualquer tempestade da mente!",
                caricaturaTipo: "alegria",
                corBadge: "#EAB308"
            }
        ]
    },

    // 9. Radia Perlman
    rpe: {
        id: "rpe",
        nome: "Radia Perlman",
        nomeCompleto: "Dra. Radia Joy Perlman",
        titulo: "A Mãe da Internet",
        subtitulo: "Criadora do Protocolo Spanning Tree (STP) que Permitiu as Redes Globais",
        area: "Redes de Computadores & Criptografia",
        categoria: "tecnologia",
        epoca: "1951 – Presente",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Comece com o problema real, e a simplicidade será a sua melhor resposta.",
        resumo: "Simplicidade genial, elegância algorítmica e humor modesto. Você cria os alicerces invisíveis das telecomunicações que conectam bilhões de pessoas.",
        feitos: "Engenheira de software com PhD pelo MIT, inventou o algoritmo Spanning Tree Protocol (STP), que transformou a tecnologia Ethernet em algo robusto e expansível para criar a Internet moderna sem travamentos de tráfego por loops. Autora de manuais clássicos de interconexão de redes e dona de mais de 100 patentes, foi incluída no National Inventors Hall of Fame e na Internet Hall of Fame.",
        caracteristicas: ["Elegância Algorítmica", "Conexão de Redes", "Criptografia Prática", "Didática Descomplicada"],
        pontosFortes: [
            { titulo: "A Base da Ethernet", desc: "Criou o algoritmo que permitiu que switches de rede conversassem sem congestionar os pacotes de dados." },
            { titulo: "Poesia dos Algoritmos", desc: "Resumiu seu famoso algoritmo em um poema 'Algorhyme' que encantou o mundo da computação." },
            { titulo: "Pioneirismo Educacional", desc: "Desenvolveu o sistema TORTIS no MIT para ensinar programação a crianças de até 3 anos." }
        ],
        tracos: { logica: 98, criatividade: 94, estrategia: 91, empatia: 86 },
        livros: [
            {
                titulo: "Interconnections: Bridges, Routers, Switches, and Internetworking Protocols",
                autor: "Radia Perlman",
                ano: "1999",
                descricao: "A bíblia mundial sobre o funcionamento das conexões da internet, referência definitiva para engenheiros em todo o globo.",
                corCapa: "#1E1B4B",
                badgeCapa: "Livro-Texto Canônico"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Radia Perlman: Mother of the Internet",
                tipo: "Documentário / Inventors Hall of Fame",
                ano: "2016",
                plataforma_ou_descricao: "Apresenta a carreira de Radia e a demonstração de como seu algoritmo de árvore salvou a internet de colapsos.",
                trailerId: "I739w2fV7eI"
            }
        ],
        pop_culture: [
            {
                nome: "Shuri",
                obra: "Pantera Negra",
                papel: "Arquiteta da Malha de Conexão",
                motivo: "Desenha a rede invisível de vibranium que mantém tudo interligado em perfeita harmonia.",
                frase: "Uma rede bem construída nunca se perde em loops!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            },
            {
                nome: "Penelope Garcia",
                obra: "Criminal Minds",
                papel: "Guardiã das Rotas de Dados",
                motivo: "Comanda o tráfego de servidores mais complexo do mundo com alegria e competência técnica.",
                frase: "Nenhum pacote de dados se perde na minha rota!",
                caricaturaTipo: "penelope",
                corBadge: "#EC4899"
            },
            {
                nome: "Velma Dinkley",
                obra: "Scooby-Doo",
                papel: "Mapeadora dos Caminhos Lógicos",
                motivo: "Encontra a rota mais curta e segura para escapar de qualquer labirinto ou armadilha.",
                frase: "O caminho mais simples é sempre o que conecta a solução!",
                caricaturaTipo: "velma",
                corBadge: "#F59E0B"
            }
        ]
    },

    // 10. Sueli Carneiro
    sca: {
        id: "sca",
        nome: "Sueli Carneiro",
        nomeCompleto: "Dra. Aparecida Sueli Carneiro Jacoel",
        titulo: "A Filósofa da Justiça e da Igualdade",
        subtitulo: "Fundadora do Geledés e Doutora Honoris Causa pela UnB",
        area: "Filosofia, Direitos Humanos & Ativismo Antirracista",
        categoria: "humanas",
        epoca: "1950 – Presente",
        pais: "Brasil 🇧🇷 (São Paulo, SP)",
        imagem: "sem_foto.png",
        citacao: "Enquanto houver racismo, não haverá democracia.",
        resumo: "Pensamento crítico monumental, autoridade moral e compromisso incansável com a igualdade racial e de gênero no Brasil.",
        feitos: "Filósofa, escritora e uma das maiores intelectuais negras do Brasil. Fundou em 1988 o Geledés - Instituto da Mulher Negra, que formulou políticas pioneiras de cotas raciais, saúde da população negra e combate à violência de gênero. Criou o conceito de 'enegrecer o feminismo', demonstrando a urgência de considerar a realidade de mulheres negras nas pautas sociais, sendo laureada com o Prêmio Itaú Cultural e o Prêmio Jabuti.",
        caracteristicas: ["Pensamento Antirracista Estrutural", "Fundação de Movimentos", "Autoridade Filosófica", "Democracia Real"],
        pontosFortes: [
            { titulo: "Enegrecer o Feminismo", desc: "Tese filosófica fundamental que reestruturou o debate dos direitos civis na América Latina." },
            { titulo: "Construção de Políticas Públicas", desc: "Atuação decisiva na aprovação das cotas nas universidades públicas brasileiras." },
            { titulo: "Mentoria de Novas Gerações", desc: "Formou lideranças intelectuais que ocupam hoje o cenário acadêmico e judiciário." }
        ],
        tracos: { logica: 94, criatividade: 91, estrategia: 98, empatia: 97 },
        livros: [
            {
                titulo: "Dispositivo de Racialidade: A Construção do Outro como Não-Ser",
                autor: "Sueli Carneiro",
                ano: "2023",
                descricao: "Tese monumental de doutorado pela USP analisando como as instituições perpetuam o racismo estrutural.",
                corCapa: "#78350F",
                badgeCapa: "Tese Filosófica"
            },
            {
                titulo: "Escritos de uma Vida",
                autor: "Sueli Carneiro",
                ano: "2019",
                descricao: "Coletânea essencial reunindo artigos, debates e manifestos históricos produzidos ao longo de quatro décadas.",
                corCapa: "#831843",
                badgeCapa: "Clássico Contemporâneo"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Sueli Carneiro: A Força da Palavra",
                tipo: "Documentário / Itaú Cultural",
                ano: "2021",
                plataforma_ou_descricao: "Registra a trajetória, os bastidores de fundação do Geledés e a potência de suas ideias para o Brasil.",
                trailerId: "Q2oK-x7P89M"
            }
        ],
        pop_culture: [
            {
                nome: "Ororo Munroe (Tempestade)",
                obra: "X-Men",
                papel: "Líder e Defensora Soberana",
                motivo: "Nobreza inabalável, sabedoria régia e coragem para lutar pela dignidade de todos os que foram oprimidos.",
                frase: "Minha voz ecoa pela liberdade e pela justiça que ninguém pode calar!",
                caricaturaTipo: "storm",
                corBadge: "#4F46E5"
            },
            {
                nome: "Okoye",
                obra: "Pantera Negra",
                papel: "Comandante das Dora Milaje",
                motivo: "Firmeza moral, lealdade à verdade e determinação feroz em proteger seu povo e sua cultura.",
                frase: "Com disciplina e honra, nenhum preconceito permanece de pé!",
                caricaturaTipo: "okoye",
                corBadge: "#EA580C"
            },
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "O Símbolo da Resistência",
                motivo: "Ergue a bandeira dos silenciados contra os sistemas injustos sem dar um passo atrás.",
                frase: "A justiça não se pede com favor: se conquista com verdade e coragem!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            }
        ]
    },

    // 11. Lélia Gonzalez
    lgo: {
        id: "lgo",
        nome: "Lélia Gonzalez",
        nomeCompleto: "Lélia de Almeida Gonzalez",
        titulo: "A Pioneira do Amefricanismo",
        subtitulo: "Antropóloga, Filósofa e Intelectual Fundadora do Pensamento Negro Brasileiro",
        area: "Antropologia, Linguística, Filosofia & Sociologia",
        categoria: "humanas",
        epoca: "1935 – 1994",
        pais: "Brasil 🇧🇷 (Belo Horizonte, MG / Rio de Janeiro, RJ)",
        imagem: "sem_foto.png",
        citacao: "A gente não nasce negro, a gente se torna negro. É uma conquista dura, diária e linda.",
        resumo: "Eloquência arrebatadora, criatividade teórica e humor desconcertante. Você desmascara opressões usando a linguagem real do povo.",
        feitos: "Formada em História, Geografia e Filosofia com mestrado em Comunicação e doutorado em Antropologia Política, foi pioneira mundial ao cunhar o conceito de 'Améfrica Ladina' e theorizar o 'Pretuguês' (a marca africana que estrutura o modo como os brasileiros falam e pensam). Cofundadora do Movimento Negro Unificado (MNU) e membra do Conselho Nacional dos Direitos da Mulher.",
        caracteristicas: ["Criação do Conceito de Améfrica", "Teoria do Pretuguês", "Interseccionalidade Pioneira", "Eloquência Popular"],
        pontosFortes: [
            { titulo: "Amefricanidade", desc: "Redefiniu a identidade das Américas reconhecendo a matriz cultural e intelectual afro-indígena." },
            { titulo: "O Pretuguês como Ciência", desc: "Demonstrou linguisticamente como o português brasileiro é enriquecido pelas línguas bantas e iorubás." },
            { titulo: "Pioneirismo Global", desc: "Antecipou os debates internacionais de interseccionalidade muito antes de serem formalizados nos EUA." }
        ],
        tracos: { logica: 93, criatividade: 97, estrategia: 95, empatia: 98 },
        livros: [
            {
                titulo: "Por um Feminismo Afro-Latino-Americano",
                autor: "Lélia Gonzalez",
                ano: "2020",
                descricao: "Coletânea histórica de ensaios fundamentais organizada por Flavia Rios e Márcia Lima sobre a potência de seu pensamento.",
                corCapa: "#991B1B",
                badgeCapa: "Coletânea Essencial"
            },
            {
                titulo: "Lugar de Negro",
                autor: "Lélia Gonzalez e Carlos Hasenbalg",
                ano: "1982",
                descricao: "Estudo sociológico clássico pioneiro que escancarou a desigualdade racial e de classes no mercado de trabalho brasileiro.",
                corCapa: "#1E293B",
                badgeCapa: "Clássico das Ciências Sociais"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Em Busca de Lélia",
                tipo: "Documentário Premiado",
                ano: "2017",
                plataforma_ou_descricao: "Dirigido por Beatriz Vieira, resgata a voz estrondosa, as palestras e o legado internacional de Lélia Gonzalez.",
                trailerId: "t7w0X7P_k3g"
            }
        ],
        pop_culture: [
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "A Crítica Eloquente",
                motivo: "Usa o sarcasmo e a literatura como escudo e lança contra qualquer hipocrisia social.",
                frase: "Falo com as palavras de quem conhece a vida como ela é!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Voz do Intelecto Rebelde",
                motivo: "Não tem medo de incomodar as autoridades com perguntas inteligentes e fatos históricos.",
                frase: "A verdade histórica é muito mais rica do que contam nos manuais tradicionais!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            },
            {
                nome: "Annalise Keating",
                obra: "How to Get Away with Murder",
                papel: "Mestra dos Argumentos e do Direito",
                motivo: "Comanda o tribunal com oratória impecável e protege os seus com inteligência implacável.",
                frase: "Quem domina a linguagem domina a verdade e a libertação!",
                caricaturaTipo: "annalise",
                corBadge: "#7C3AED"
            }
        ]
    },

    // 12. Mayana Zatz
    mza: {
        id: "mza",
        nome: "Mayana Zatz",
        nomeCompleto: "Dra. Mayana Zatz",
        titulo: "A Sentinela Genômica das Células-Tronco",
        subtitulo: "Referência Internacional em Doenças Neuromusculares e Genética Humana",
        area: "Genética Humana, Células-Tronco & Doenças Neuromusculares",
        categoria: "saude",
        epoca: "1947 – Presente",
        pais: "Brasil 🇧🇷 (São Paulo, SP)",
        imagem: "sem_foto.png",
        citacao: "A ciência brasileira precisa ser valorizada porque salva vidas todos os dias e dá respostas onde outros desistem.",
        resumo: "Pioneira na pesquisa de DNA e células-tronco, defensora incansável da ciência pública e da esperança médica para famílias com distrofias musculares.",
        feitos: "Professora titular da USP e diretora do Centro de Estudos do Genoma Humano e Células-Tronco (CEGH-CEL). Reconhecida internacionalmente como uma das maiores autoridades na identificação de genes causadores de distrofias musculares e esclerose lateral amiotrófica (ELA). Teve papel histórico decisivo na aprovação da Lei de Biossegurança no Supremo Tribunal Federal (STF), garantindo o direito à pesquisa com células-tronco embrionárias no Brasil.",
        caracteristicas: ["Pioneirismo em Genética", "Defesa das Células-Tronco", "Altruísmo Médico", "Liderança na USP"],
        pontosFortes: [
            { titulo: "Acolhimento de Milhares de Famílias", desc: "Criou o maior centro público de diagnóstico genético gratuito para doenças raras na América Latina." },
            { titulo: "Luta no STF", desc: "Defendeu cientificamente a aprovação das pesquisas com células-tronco em sessão histórica no tribunal." },
            { titulo: "Publicações Internacionais", desc: "Mais de 350 artigos científicos de alto impacto e membra da Academia Brasileira de Ciências." }
        ],
        tracos: { logica: 97, criatividade: 91, estrategia: 95, empatia: 98 },
        livros: [
            {
                titulo: "GenÉTICA: A Escolha É Nossa",
                autor: "Mayana Zatz",
                ano: "2011",
                descricao: "Aborda os dilemas éticos fascinantes trazidos pela era do sequenciamento de DNA e da terapia gênica.",
                corCapa: "#0284C7",
                badgeCapa: "Bioética & Genética"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Mayana Zatz: Genética e Esperança",
                tipo: "Documentário / Roda Viva",
                ano: "2021",
                plataforma_ou_descricao: "Sabatina especial sobre a revolução do tratamento genético, o envelhecimento e o futuro das células-tronco.",
                trailerId: "K4wL2-W4f0s"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Helen Cho",
                obra: "Vingadores",
                papel: "Geneticista & Bioengenheira",
                motivo: "Comanda pesquisas de regeneração celular avançada com precisão incomparável.",
                frase: "O DNA carrega o mapa da cura se soubermos decifrá-lo!",
                caricaturaTipo: "helen_cho",
                corBadge: "#0284C7"
            },
            {
                nome: "Dra. Cristina Yang",
                obra: "Grey's Anatomy",
                papel: "Cirurgiã de Elite",
                motivo: "Foco absoluto no paciente e paixão incondicional pela excelência da medicina.",
                frase: "Não aceito limites biológicos quando podemos salvar vidas!",
                caricaturaTipo: "yang",
                corBadge: "#0284C7"
            },
            {
                nome: "Katara",
                obra: "Avatar",
                papel: "Mestra da Cura",
                motivo: "Dedica sua vida para confortar e encontrar esperança para famílias que mais precisam.",
                frase: "Nunca deixarei de buscar a resposta para a saúde de quem sofre!",
                caricaturaTipo: "katara",
                corBadge: "#2563EB"
            }
        ]
    },

    // 13. Hipátia de Alexandria
    hpa: {
        id: "hpa",
        nome: "Hipátia de Alexandria",
        nomeCompleto: "Hipátia (Ὑπατία)",
        titulo: "A Luz da Antiguidade Clássica",
        subtitulo: "A Primeira Grande Filósofa, Astrônoma e Matemática Registrada na História",
        area: "Astronomia, Matemática & Filosofia Neoplatônica",
        categoria: "exatas",
        epoca: "c. 360 – 415 d.C.",
        pais: "Egito Helenístico 🇪🇬 / Grécia Antiga 🇬🇷",
        imagem: "sem_foto.png",
        citacao: "Defenda o seu direito de pensar, pois até pensar errado é muito melhor do que não pensar.",
        resumo: "Mente brilhante da antiguidade, mestre das equações celestes e defensora apaixonada da razão livre contra o obscurantismo e o fanatismo.",
        feitos: "Diretora da prestigiada Escola Neoplatônica de Alexandria, lecionava geometria, astronomia e filosofia para discípulos vindos de todo o Mediterrâneo. Desenvolveu aperfeiçoamentos no astrolábio (instrumento astronômico de cálculo de posição estelar) e inventou o densímetro para medir a densidade de líquidos. Editou e preservou os tratados matemáticos fundamentais de Apolônio de Pérgamo (sobre seções cônicas) e Diofanto.",
        caracteristicas: ["Razão Livre Sem Dogmas", "Geometria Cônica", "Astronomia Instrumental", "Coragem Filosófica"],
        pontosFortes: [
            { titulo: "Astrofísica da Antiguidade", desc: "Aperfeiçoou o astrolábio plano para mapear as constelações no céu noturno." },
            { titulo: "Defesa do Livre Pensamento", desc: "Manteve as portas da academia abertas para cristãos, judeus e pagãos dialogarem pacificamente." },
            { titulo: "Preservação da Matemática", desc: "Seus comentários garantiram que os teoremas cônicos e aritméticos sobrevivessem ao tempo." }
        ],
        tracos: { logica: 98, criatividade: 92, estrategia: 88, empatia: 90 },
        livros: [
            {
                titulo: "Hipátia de Alexandria: Matemática, Filósofa e Mártir",
                autor: "Maria Dzielska",
                ano: "1995",
                descricao: "Obra historiográfica rigorosa da Universidade de Harvard que resgatou os fatos reais sobre a vida e as descobertas de Hipátia.",
                corCapa: "#B45309",
                badgeCapa: "Harvard University Press"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Alexandria (Agora)",
                tipo: "Superprodução Cinematográfica",
                ano: "2009",
                plataforma_ou_descricao: "Dirigido por Alejandro Amenábar e estrelado por Rachel Weisz, retrata Hipátia desvendando as órbitas celestes e defendendo a Biblioteca.",
                trailerId: "RbuEhwselE0"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Ellie Arroway",
                obra: "Contato (Carl Sagan)",
                papel: "Astrônoma Obstinada pela Verdade",
                motivo: "Aponta seus instrumentos para as estrelas e defende o método racional contra qualquer dogma imposto.",
                frase: "O cosmos nos ensina a pensar livremente sem medo da verdade!",
                caricaturaTipo: "arroway",
                corBadge: "#818CF8"
            },
            {
                nome: "Hermione Granger",
                obra: "Harry Potter",
                papel: "A Defensora da Razão e dos Livros",
                motivo: "Amor absoluto pelo conhecimento dos livros antigos e capacidade de decifrar qualquer enigma astronômico.",
                frase: "Pensar por si mesma é a maior força que alguém pode cultivar!",
                caricaturaTipo: "hermione",
                corBadge: "#DC2626"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Filósofa Incompreendida",
                motivo: "Mantém seus princípios éticos e amor pelos telescópios e ciências mesmo quando ninguém ao redor compreende.",
                frase: "Defenderei o direito de pensar até o fim!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            }
        ]
    },

    // 14. Hannah Arendt
    har: {
        id: "har",
        nome: "Hannah Arendt",
        nomeCompleto: "Johanna Arendt",
        titulo: "A Teórica da Liberdade e da Ação",
        subtitulo: "Uma das Mais Influentes Filósofas Políticas do Século XX",
        area: "Filosofia Política & Teoria da Ação",
        categoria: "humanas",
        epoca: "1906 – 1975",
        pais: "Alemanha 🇩🇪 / Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "O pensamento em si mesmo é perigoso para todos os dogmas e convenções estabelecidas.",
        resumo: "Pensamento afiado e independente, coragem de enfrentar controvérsias e compromisso com o espaço público democrático e o juízo crítico.",
        feitos: "Sobrevivente do nazismo, desenvolveu análises sociológicas e políticas sem precedentes sobre as raízes do autoritarismo em 'As Origens do Totalitarismo'. Cunhou o célebre conceito da 'banalidade do mal' durante a cobertura do julgamento de Adolf Eichmann em Jerusalém, demonstrando como a falta de reflexão crítica individual pode transformar burocratas comuns em agentes do horror.",
        caracteristicas: ["Juízo Crítico Inabalável", "Desconstrução do Totalitarismo", "Conceito de Banalidade do Mal", "Defesa da Esfera Pública"],
        pontosFortes: [
            { titulo: "A Banalidade do Mal", desc: "Provou que os piores crimes históricos acontecem quando as pessoas abrem mão de pensar criticamente." },
            { titulo: "A Condição Humana", desc: "Teorizou as dimensões do Trabalho, da Obra e da Ação como fundamentos da liberdade." },
            { titulo: "Independência Radical", desc: "Sustentou suas conclusões mesmo sob pesadas críticas internacionais, priorizando a verdade dos fatos." }
        ],
        tracos: { logica: 96, criatividade: 89, estrategia: 93, empatia: 91 },
        livros: [
            {
                titulo: "As Origens do Totalitarismo",
                autor: "Hannah Arendt",
                ano: "1951",
                descricao: "Obra seminal sobre o antissemitismo, o imperialismo e a ascensão dos regimes totalitários na Europa.",
                corCapa: "#1E1B4B",
                badgeCapa: "Clássico da Filosofia"
            },
            {
                titulo: "Eichmann em Jerusalém: Um Relato sobre a Banalidade do Mal",
                autor: "Hannah Arendt",
                ano: "1963",
                descricao: "Crônica filosófica fundamental sobre o julgamento do criminoso de guerra nazista e os perigos da obediência cega.",
                corCapa: "#374151",
                badgeCapa: "Marco do Pensamento"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Hannah Arendt: A Coragem de Pensar",
                tipo: "Filme / Longa-Metragem Premiado",
                ano: "2012",
                plataforma_ou_descricao: "Dirigido por Margarethe von Trotta e estrelado por Barbara Sukowa, foca na polêmica e na bravura de sua cobertura em Jerusalém.",
                trailerId: "4TeqWk4i44g"
            }
        ],
        pop_culture: [
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "A Crítica Sem Concessões",
                motivo: "Não abaixa a cabeça para o consenso fácil e analisa as atitudes humanas com frieza e profundidade.",
                frase: "Pensar por si própria não é uma opção: é um dever com a verdade!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "Dra. Dana Scully",
                obra: "Arquivo X",
                papel: "Investigadora da Verdade",
                motivo: "Questiona relatórios oficiais e busca o que realmente aconteceu por trás das cortinas de fumaça burocráticas.",
                frase: "A verdade histórica precisa de olhos atentos que não aceitam dogmas prontos.",
                caricaturaTipo: "scully",
                corBadge: "#2563EB"
            },
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "Desafiadora do Totalitarismo",
                motivo: "Enxerga através da propaganda do governo e recusa ser mera peça em um tabuleiro de controle social.",
                frase: "O poder do tirano acaba quando o povo decide pensar por conta própria!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            }
        ]
    },

    // 15. Malala Yousafzai
    mal: {
        id: "mal",
        nome: "Malala Yousafzai",
        nomeCompleto: "Malala Yousafzai (ملاله یوسفزۍ)",
        titulo: "A Campeã Global da Educação de Meninas",
        subtitulo: "A Mais Jovem Laureada com o Prêmio Nobel da Paz na História",
        area: "Educação, Direitos das Crianças & Paz Mundial",
        categoria: "humanas",
        epoca: "1997 – Presente",
        pais: "Paquistão 🇵🇰",
        imagem: "sem_foto.png",
        citacao: "Uma criança, um professor, um livro e uma caneta podem mudar o mundo.",
        resumo: "Coragem heroica, serenidade inspiradora e determinação inquebrável para garantir que cada menina do planeta tenha o direito de estudar.",
        feitos: "Aos 11 anos, começou a escrever sob pseudônimo para a BBC denunciando a proibição das meninas frequentarem escolas no Vale do Swat pelo Talibã. Sobreviveu a um atentado a tiros em 2012 e transformou sua recuperação em um movimento global pela educação através do Malala Fund. Aos 17 anos, tornou-se a pessoa mais jovem a receber o Prêmio Nobel da Paz.",
        caracteristicas: ["Coragem Diante do Terror", "Eloquência Pacifista", "Ativismo Educacional Global", "Esperança Inabalável"],
        pontosFortes: [
            { titulo: "A Força da Palavra", desc: "Seu discurso na ONU comoveu o planeta e colocou a educação feminina no topo das metas da humanidade." },
            { titulo: "Malala Fund", desc: "Instituição internacional que financia escolas e bolsas para meninas em zonas de guerra e vulnerabilidade." },
            { titulo: "Voz da Juventude", desc: "Mostrou que a idade não é barreira para transformar a história do mundo." }
        ],
        tracos: { logica: 88, criatividade: 90, estrategia: 94, empatia: 100 },
        livros: [
            {
                titulo: "Eu Sou Malala: A História da Garota que Defendeu a Educação e Foi Baleada pelo Talibã",
                autor: "Malala Yousafzai e Christina Lamb",
                ano: "2013",
                descricao: "Best-seller mundial emocionante que narra sua infância no Swat, o amor pelos livros e sua sobrevivência miraculosa.",
                corCapa: "#BE185D",
                badgeCapa: "Best-Seller Global"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "He Named Me Malala",
                tipo: "Documentário / Indicado ao Oscar",
                ano: "2015",
                plataforma_ou_descricao: "Dirigido por Davis Guggenheim, retrata o dia a dia, o bom humor em família e a luta incansável de Malala.",
                trailerId: "vFEg3v9eH_Y"
            }
        ],
        pop_culture: [
            {
                nome: "Moana",
                obra: "Disney",
                papel: "A Coragem que Transcende o Medo",
                motivo: "Cruza fronteiras aparentemente impossíveis para salvar sua comunidade e abrir caminhos para o futuro.",
                frase: "Eu sei de onde venho e sei que a educação é a bússola que salva o mundo!",
                caricaturaTipo: "moana",
                corBadge: "#06B6D4"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "Defensora Fervorosa dos Livros",
                motivo: "Acredita piamente no poder da escola, da leitura e da educação para mudar qualquer sociedade.",
                frase: "Os livros são a arma mais poderosa que existe contra a ignorância!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            },
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "Símbolo de Dignidade",
                motivo: "Enfrenta os perigos mais extremos para proteger as crianças e garantir que o futuro não seja apagado.",
                frase: "Nenhum medo nos calará quando estamos lutando pelo direito de viver e aprender!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            }
        ]
    },

    // 16. Bell Hooks
    bhk: {
        id: "bhk",
        nome: "Bell Hooks",
        nomeCompleto: "Gloria Jean Watkins",
        titulo: "A Teórica da Pedagogia e do Amor Crítico",
        subtitulo: "Autora Revolucionária de Ensinando a Transgredir e Tudo Sobre o Amor",
        area: "Pedagogia Crítica, Teoria Feminista & Estudos Culturais",
        categoria: "humanas",
        epoca: "1952 – 2021",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "A sala de aula, com todas as suas limitações, continua sendo um lugar de possibilidade. Ali temos a chance de praticar a liberdade.",
        resumo: "Calor intelectual, generosidade pedagógica e poder de escrita que cura. Você acredita na educação como prática de liberdade e no amor como força política.",
        feitos: "Adotou o pseudônimo 'bell hooks' em minúsculas para homenagear sua bisavó Bell Blair Hooks e enfatizar a substância dos livros mais do que sua pessoa. Escreveu mais de 30 livros revolucionários cruzando raça, classe social e gênero, transformando a educação com a ideia da 'pedagogia engajada' e redefinindo o amor como uma ação diária de cuidado, respeito e compromisso com o crescimento do outro.",
        caracteristicas: ["Educação como Prática da Liberdade", "Teoria do Amor Crítico", "Linguagem Descolonizada", "Acolhimento Pedagógico"],
        pontosFortes: [
            { titulo: "Ensinando a Transgredir", desc: "Livro de cabeceira de professores em todo o mundo, transformando a sala de aula em espaço vivo de diálogo." },
            { titulo: "Tudo Sobre o Amor", desc: "Redefiniu o amor como força ética capaz de sarar traumas comunitários e construir justiça." },
            { titulo: "Acessibilidade Teórica", desc: "Escrevia com profundidade ímpar sem hermetismos elitistas, para que qualquer pessoa compreendesse." }
        ],
        tracos: { logica: 92, criatividade: 96, estrategia: 92, empatia: 100 },
        livros: [
            {
                titulo: "Ensinando a Transgredir: A Educação como Prática da Liberdade",
                autor: "bell hooks",
                ano: "1994",
                descricao: "Marco absoluto da pedagogia contemporânea inspirado nas ideias de Paulo Freire e no feminismo comunitário.",
                corCapa: "#D97706",
                badgeCapa: "Clássico da Educação"
            },
            {
                titulo: "Tudo Sobre o Amor: Novas Perspectivas",
                autor: "bell hooks",
                ano: "2000",
                descricao: "Ensaio apaixonante sobre a necessidade de resgatar o amor como ato consciente de justiça e descolonização.",
                corCapa: "#DC2626",
                badgeCapa: "Fenômeno Mundial"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Bell Hooks: Cultural Criticism and Transformation",
                tipo: "Documentário / MEF",
                ano: "1997",
                plataforma_ou_descricao: "Entrevista e conferência clássica sobre a representação midiática, poder e a pedagogia do amor.",
                trailerId: "z1m0M67w-0Y"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Miranda Bailey",
                obra: "Grey's Anatomy",
                papel: "A Educadora e Mentora Firme e Amorosa",
                motivo: "Exige o máximo dos alunos porque acredita visceralmente no potencial transformador deles.",
                frase: "Educar é abrir espaço para que cada um se torne quem veio para ser com respeito e método!",
                caricaturaTipo: "bailey",
                corBadge: "#9333EA"
            },
            {
                nome: "Katara",
                obra: "Avatar",
                papel: "Mestra Curadora",
                motivo: "Acredita na ternura e na acolhida como as maiores forças capazes de derrotar o ódio.",
                frase: "O amor e a educação curam as feridas mais profundas do mundo!",
                caricaturaTipo: "katara",
                corBadge: "#2563EB"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Estudante Apaixonada",
                motivo: "Enxerga na sala de aula e nos debates honestos o berço de uma sociedade livre e igualitária.",
                frase: "Ensinar e aprender juntos é a maior alegria que a mente pode experimentar!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            }
        ]
    },

    // 17. Simone de Beauvoir
    sdb: {
        id: "sdb",
        nome: "Simone de Beauvoir",
        nomeCompleto: "Simone Lucie Ernestine Marie Bertrand de Beauvoir",
        titulo: "A Filósofa da Existência e da Liberdade",
        subtitulo: "Autora de 'O Segundo Sexo' e Cume do Existencialismo",
        area: "Filosofia Existencialista, Literatura & Teoria Social",
        categoria: "humanas",
        epoca: "1908 – 1986",
        pais: "França 🇫🇷",
        imagem: "sem_foto.png",
        citacao: "Não se nasce mulher: torna-se mulher. A liberdade se define pelo que você escolhe fazer com o que fizeram de você.",
        resumo: "Rigor filosófico existencialista, independência radical e coragem de desconstruir o papel histórico imposto às mulheres pela sociedade.",
        feitos: "Formada em Filosofia na Sorbonne (onde foi a pessoa mais jovem a ser aprovada no difícil concurso de agregação), publicou em 1949 sua obra-prima 'O Segundo Sexo', que inaugurou o pensamento feminista moderno ao demonstrar que a feminilidade não é um destino biológico natural, mas uma construção histórica e cultural. Laureada com o Prêmio Goncourt de literatura.",
        caracteristicas: ["Existencialismo Puro", "Desconstrução de Mitos", "Autonomia Radical", "Engajamento Político"],
        pontosFortes: [
            { titulo: "O Segundo Sexo", desc: "A mais influente obra filosófica sobre a condição da mulher escrita no século XX." },
            { titulo: "A Ética da Ambiguidade", desc: "Formulou uma ética existencialista baseada na responsabilidade incontornável da liberdade." },
            { titulo: "Literatura Engajada", desc: "Traduziu dilemas éticos densos em romances arrebatadores como 'Os Mandarins'." }
        ],
        tracos: { logica: 96, criatividade: 95, estrategia: 92, empatia: 91 },
        livros: [
            {
                titulo: "O Segundo Sexo (Volumes 1 e 2)",
                autor: "Simone de Beauvoir",
                ano: "1949",
                descricao: "A bíblia fundadora da reflexão de gênero, dissecando biologia, história, mitos e a experiência vivida das mulheres.",
                corCapa: "#991B1B",
                badgeCapa: "Marco da Filosofia"
            },
            {
                titulo: "Memórias de uma Moça Bem-Comportada",
                autor: "Simone de Beauvoir",
                ano: "1958",
                descricao: "Autobiografia fascinante sobre sua libertação das convenções burguesas para abraçar a vida intelectual livre.",
                corCapa: "#1E3A8A",
                badgeCapa: "Autobiografia"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Simone de Beauvoir: Não se nasce mulher",
                tipo: "Documentário / ARTE France",
                ano: "2018",
                plataforma_ou_descricao: "Registros históricos e depoimentos originais da filósofa sobre a liberdade e a responsabilidade existencial.",
                trailerId: "z8_O8qE2Z3U"
            }
        ],
        pop_culture: [
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "A Existencialista Independente",
                motivo: "Devoradora dos livros de Beauvoir, forja seu próprio destino e recusa rótulos impostos.",
                frase: "Eu defino quem sou pelas minhas próprias escolhas e pela minha mente livre!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "Annalise Keating",
                obra: "How to Get Away with Murder",
                papel: "A Mulher que Recusa Submissões",
                motivo: "Construiu seu poder sem pedir permissão e domina o cenário intelectual por mérito próprio.",
                frase: "Ninguém define os limites da minha liberdade a não ser eu mesma!",
                caricaturaTipo: "annalise",
                corBadge: "#7C3AED"
            },
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "A Conquistadora da Autonomia",
                motivo: "Rejeita os papéis teatrais forçados pelo sistema da Capital e assume as rédeas de sua existência.",
                frase: "Minha vida e minhas escolhas pertencem a mim e a quem eu amo!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            }
        ]
    },

    // 18. Dorothy Vaughan (já existente, enriquecida com trailer)
    drv: {
        id: "drv",
        nome: "Dorothy Vaughan",
        nomeCompleto: "Dorothy Johnson Vaughan",
        titulo: "A Estrategista do Código Espacial",
        subtitulo: "Pioneira da Computação na NASA e Liderança de Equipes",
        area: "Matemática, Programação & Engenharia Aeroespacial",
        categoria: "tecnologia",
        epoca: "1910 – 2008",
        pais: "Estados Unidos 🇺🇸",
        imagem: "Dorothy_Vaughan.jpg",
        citacao: "Eu mudei o que pude, e o que não pude, preparei as outras mulheres para superar.",
        resumo: "Estrategista de mão-cheia, líder solidária e pragmática. Quando as regras mudam, você se reinventa, aprende o novo antes de todos e puxa seu time junto para o topo.",
        feitos: "Primeira supervisora negra da história da NACA/NASA. Ao prever que os computadores mecânicos IBM substituiriam o cálculo manual, aprendeu a linguagem FORTRAN de forma autodidata e treinou clandestinamente toda a sua equipe de mulheres negras, tornando-se chefe da Seção de Computação e garantindo que sua equipe liderasse os lançamentos da corrida espacial.",
        caracteristicas: ["Liderança Estratégica", "Capacidade Rápida de Adaptação", "Visão Pragmática de Tendências", "Espírito Comunitário"],
        pontosFortes: [
            { titulo: "Inteligência Operacional", desc: "Identifica com clareza quais habilidades técnicas serão essenciais no futuro próximo." },
            { titulo: "Empoderamento Coletivo", desc: "Nunca avança sozinha: capacita e protege quem caminha ao seu lado." },
            { titulo: "Resiliência Sob Pressão", desc: "Mantém a cabeça fria e os códigos perfeitos mesmo nos momentos mais tensos." }
        ],
        tracos: { logica: 90, criatividade: 84, estrategia: 98, empatia: 94 },
        livros: [
            {
                titulo: "Estrelas Além do Tempo",
                autor: "Margot Lee Shetterly",
                ano: "2016",
                descricao: "Best-seller mundial que resgata a trajetória crucial de Dorothy Vaughan, Katherine Johnson e Mary Jackson na NASA.",
                corCapa: "#B45309",
                badgeCapa: "Best-Seller Histórico"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Estrelas Além do Tempo (Hidden Figures)",
                tipo: "Filme / Longa-Metragem Indicado ao Oscar",
                ano: "2016",
                plataforma_ou_descricao: "Octavia Spencer interpreta Dorothy Vaughan com liderança exemplar, aprendendo FORTRAN e comandando a transição digital.",
                trailerId: "5wfrDhgUMGI"
            }
        ],
        pop_culture: [
            {
                nome: "Tenente Nyota Uhura",
                obra: "Star Trek",
                papel: "Chefe de Comunicações da Enterprise",
                motivo: "Pioneira estelar indispensável, domina códigos alienígenas mantendo a frota unida sob pressão.",
                frase: "Frequências de comunicação abertas em todos os canais da galáxia!",
                caricaturaTipo: "uhura",
                corBadge: "#D97706"
            },
            {
                nome: "Annalise Keating",
                obra: "How to Get Away with Murder",
                papel: "Professora & Estrategista Magistral",
                motivo: "Estrategista nata: antecipa 10 passos à frente de qualquer um e não mede esforços para blindar e preparar seu time.",
                frase: "Nunca subestime quem conhece as regras melhor do que quem as escreveu.",
                caricaturaTipo: "annalise",
                corBadge: "#7C3AED"
            },
            {
                nome: "General Leia Organa",
                obra: "Star Wars",
                papel: "Comandante da Resistência",
                motivo: "Liderança firme, pragmatismo heroico e fé inabalável no potencial coletivo das pessoas.",
                frase: "A liderança se prova quando as coisas ficam difíceis e alguém precisa apontar o caminho.",
                caricaturaTipo: "leia",
                corBadge: "#2563EB"
            }
        ]
    },

    // 19. Jaqueline Góes de Jesus
    jge: {
        id: "jge",
        nome: "Jaqueline Góes de Jesus",
        nomeCompleto: "Dra. Jaqueline Góes de Jesus",
        titulo: "A Sentinela Genômica",
        subtitulo: "Líder do Sequenciamento Recorde do SARS-CoV-2 na América Latina",
        area: "Biomedicina, Virologia & Genômica",
        categoria: "biologicas",
        epoca: "1989 – Presente",
        pais: "Brasil 🇧🇷 (Salvador, Bahia)",
        imagem: "Jaqueline_Goes.jpg",
        citacao: "A ciência brasileira é potente, veloz e diversa. Mulheres negras salvam vidas na linha de frente dos laboratórios todos os dias.",
        resumo: "Velocidade impressionante de raciocínio, precisão técnica milimétrica e vocação para salvar vidas em cenários de emergência coletiva.",
        feitos: "Liderou no Instituto Adolfo Lutz e na USP a equipe que sequenciou o genoma do vírus SARS-CoV-2 em apenas 48 horas após a confirmação do primeiro caso no Brasil e na América Latina (a média mundial era de 15 dias), acelerando diagnósticos e vacinas. Atuou também na vigilância genômica do Zika e Dengue, tornando-se homenageada pela Mattel com a boneca Barbie Cientista.",
        caracteristicas: ["Agilidade em Crises", "Rigor Biomédico", "Compromisso Social", "Orgulho da Ciência Nacional"],
        pontosFortes: [
            { titulo: "Resposta Rápida a Crises", desc: "Entrega resultados cruciais no momento em que a sociedade mais precisa." },
            { titulo: "Liderança em Laboratório", desc: "Coordena redes multidisciplinares de pesquisadores para metas de saúde pública." },
            { titulo: "Representatividade", desc: "Inspira milhares de meninas a ingressarem na carreira de pesquisadoras biomédicas." }
        ],
        tracos: { logica: 94, criatividade: 86, estrategia: 92, empatia: 95 },
        livros: [
            {
                titulo: "Meninas Negras na Ciência",
                autor: "Várias Autoras / FAPESP",
                ano: "2021",
                descricao: "Destaque para a trajetória de Jaqueline Góes como expoente da biomedicina brasileira moderna.",
                corCapa: "#0284C7",
                badgeCapa: "Inspiração Nacional"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Cientistas Brasileiras: O Desafio do Vírus",
                tipo: "Documentário TV Brasil",
                ano: "2021",
                plataforma_ou_descricao: "Acompanha os bastidores da equipe de Jaqueline e Ester Sabino durante a pandemia.",
                trailerId: "p4k8R6G6-2k"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Cristina Yang",
                obra: "Grey's Anatomy",
                papel: "Cirurgiã Cardíaca de Elite",
                motivo: "Foco absoluto, técnica impecável e agilidade impressionante para resolver qualquer crise médica com perfeição.",
                frase: "Não me diga que não dá tempo: prepare o equipamento e deixe o método agir!",
                caricaturaTipo: "yang",
                corBadge: "#0284C7"
            },
            {
                nome: "Dra. Beverly Crusher",
                obra: "Star Trek: TNG",
                papel: "Diretora Médica da Frota Estelar",
                motivo: "Capaz de isolar patógenos desconhecidos e formular vacinas em tempo recorde para salvar populações inteiras.",
                frase: "A biologia e a genética são a nossa primeira linha de defesa pela vida.",
                caricaturaTipo: "crusher",
                corBadge: "#0D9488"
            },
            {
                nome: "Alegria & Sabedoria",
                obra: "Divertida Mente",
                papel: "Líder das Respostas Positivas",
                motivo: "Energia vibrante, resiliência otimista e disposição incansável para mobilizar soluções em equipe.",
                frase: "Com inteligência e coração, a gente dá a volta por cima em qualquer tempestade!",
                caricaturaTipo: "alegria",
                corBadge: "#EAB308"
            }
        ]
    },

    // 20. Sônia Guimarães
    sgu: {
        id: "sgu",
        nome: "Sônia Guimarães",
        nomeCompleto: "Dra. Sônia Guimarães",
        titulo: "A Quebradora de Recordes do ITA",
        subtitulo: "Primeira Mulher Negra Doutora em Física no Brasil e Professora do ITA",
        area: "Física Aplicada, Semicondutores & Lasers",
        categoria: "tecnologia",
        epoca: "1957 – Presente",
        pais: "Brasil 🇧🇷 (São Paulo, SP)",
        imagem: "Sonia_Guimaraes.jpg",
        citacao: "Disseram que aquele lugar não era para mim. Então eu entrei, me formei doutora e me tornei professora dos que duvidavam.",
        resumo: "Coragem imbatível, firmeza pedagógica e compromisso visceral com o futuro. Você abre portas onde só existiam muros e inspira quem te cerca com excelência.",
        feitos: "Primeira mulher negra brasileira a obter um título de Doutorado em Física (pela Universidade de Manchester, Inglaterra, em 1989) e primeira mulher negra a lecionar no renomado Instituto Tecnológico de Aeronáutica (ITA), onde atua há mais de 30 anos lecionando física experimental e tecnologia de semicondutores.",
        caracteristicas: ["Pioneirismo Histórico", "Excelência Técnica no ITA", "Mentoria Empoderadora", "Ativismo Educacional"],
        pontosFortes: [
            { titulo: "Superação de Barreiras", desc: "Venceu o racismo e o machismo institucional através de competência científica inegociável." },
            { titulo: "Excelência Didática", desc: "Forma gerações de engenheiros de ponta em física de materiais e semicondutores." },
            { titulo: "Incentivo a Meninas", desc: "Percorre o Brasil incentivando estudantes da rede pública a ocuparem as ciências exatas." }
        ],
        tracos: { logica: 94, criatividade: 85, estrategia: 93, empatia: 97 },
        livros: [
            {
                titulo: "Vozes Negras na Ciência Brasileira",
                autor: "Vários Autores / SBPC",
                ano: "2020",
                descricao: "Destaque para a trajetória e as pesquisas da professora Sônia Guimarães na física de semicondutores.",
                corCapa: "#4F46E5",
                badgeCapa: "Pioneiras da Ciência"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "TEDx São Paulo: A Física da Coragem",
                tipo: "Palestra / Conferência",
                ano: "2018",
                plataforma_ou_descricao: "Relato emocionante e enérgico sobre determinação, tecnologia e o orgulho de ser pioneira no ITA.",
                trailerId: "O895Wv4Y1p8"
            }
        ],
        pop_culture: [
            {
                nome: "Ororo Munroe (Tempestade)",
                obra: "X-Men",
                papel: "Mestra e Guardiã do Instituto Xavier",
                motivo: "Poder elemental, dignidade régia inabalável e amor pedagógico por orientar as novas gerações rumo ao seu potencial.",
                frase: "O poder que existe em você só precisa de coragem e método para transformar tudo!",
                caricaturaTipo: "storm",
                corBadge: "#4F46E5"
            },
            {
                nome: "Dra. Miranda Bailey",
                obra: "Grey's Anatomy",
                papel: "Chefe de Cirurgia e Mestra Inquestionável",
                motivo: "Exige o mais alto padrão ético e técnico com um coração generoso que protege e forma os melhores.",
                frase: "Eu cobro rigor porque sei que vocês foram feitos para serem os melhores da ciência!",
                caricaturaTipo: "bailey",
                corBadge: "#9333EA"
            },
            {
                nome: "Okoye",
                obra: "Pantera Negra",
                papel: "Comandante das Forças de Wakanda",
                motivo: "Disciplina exemplar, lealdade à excelência e coragem feroz de liderar pelo exemplo.",
                frase: "Com método e bravura, nenhum obstáculo resiste ao nosso avanço!",
                caricaturaTipo: "okoye",
                corBadge: "#EA580C"
            }
        ]
    },

    // 21. Jane Goodall
    jgl: {
        id: "jgl",
        nome: "Jane Goodall",
        nomeCompleto: "Dra. Valerie Jane Morris-Goodall",
        titulo: "A Guardiã da Vida Selvagem",
        subtitulo: "A Cientista que Redefiniu a Relação entre Humanos e Animais",
        area: "Primatologia, Etologia & Conservação",
        categoria: "biologicas",
        epoca: "1934 – Presente",
        pais: "Reino Unido 🇬🇧 / Tanzânia 🇹🇿",
        imagem: "Jane_Goodall.jpg",
        citacao: "O que você faz faz a diferença, e você tem que decidir que tipo de diferença quer fazer no mundo.",
        resumo: "Sensibilidade aguçada, paciência infinita e empatia profunda pela natureza. Você acredita no poder da observação atenta e na proteção ativa de todas as formas de vida.",
        feitos: "Revolucionou o conceito de humanidade ao comprovar, na selva de Gombe, que os chimpanzés produzem e usam ferramentas (habilidade antes tida como exclusivamente humana), têm personalidades ricas, laços de afeto e compaixão. Fundou o Instituto Jane Goodall e atua como mensageira da paz da ONU em prol do equilíbrio ecológico da Terra.",
        caracteristicas: ["Empatia Interespécies", "Paciência e Observação", "Amor à Natureza", "Ativismo Planetário"],
        pontosFortes: [
            { titulo: "Escuta e Observação", desc: "Percebe nuances comportamentais sutis que passam despercebidas pela maioria." },
            { titulo: "Comunicação Inspiradora", desc: "Toca corações em todo o mundo para causas de conservação ambiental." },
            { titulo: "Humildade Intelectual", desc: "Aprende diretamente com a natureza sem preconceitos teóricos rígidos." }
        ],
        tracos: { logica: 80, criatividade: 88, estrategia: 82, empatia: 99 },
        livros: [
            {
                titulo: "Uma Janela Para a Vida: 30 Anos com os Chimpanzés de Gombe",
                autor: "Jane Goodall",
                ano: "1990",
                descricao: "Obra-prima da etologia moderna sobre as famílias de primatas e o comportamento animal.",
                corCapa: "#047857",
                badgeCapa: "Clássico Naturalista"
            },
            {
                titulo: "O Livro da Esperança: Um Guia de Sobrevivência para Tempos Difíceis",
                autor: "Jane Goodall e Douglas Abrams",
                ano: "2021",
                descricao: "Reflexão inspiradora sobre a resiliência ecológica e o poder da ação humana individual.",
                corCapa: "#0D9488",
                badgeCapa: "Filosofia & Ecologia"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Jane",
                tipo: "Documentário Premiado National Geographic",
                ano: "2017",
                plataforma_ou_descricao: "Filmagens originais inéditas em 16mm com trilha sonora de Philip Glass retratando suas expedições pioneiras.",
                trailerId: "FRlUJrEUn0Y"
            }
        ],
        pop_culture: [
            {
                nome: "Princesa Mononoke (San)",
                obra: "Studio Ghibli",
                papel: "Protetora da Floresta Sagrada",
                motivo: "Conexão simbiótica com os animais e coragem destemida em defender a natureza.",
                frase: "A floresta vive, respira e tem o direito sagrado de existir em paz!",
                caricaturaTipo: "san",
                corBadge: "#059669"
            },
            {
                nome: "Dra. Ellie Sattler",
                obra: "Jurassic Park",
                papel: "Paleobotânica de Campo",
                motivo: "Apaixonada pelos organismos vivos, sabe que a natureza sempre encontra um caminho.",
                frase: "Você não pode controlar a natureza com arrogância: a vida sempre encontra um caminho!",
                caricaturaTipo: "ellie_sattler",
                corBadge: "#10B981"
            },
            {
                nome: "Moana",
                obra: "Disney",
                papel: "Navegadora & Protetora da Ilha",
                motivo: "Compreensão intuitiva dos ciclos naturais e coragem para restaurar o coração da Terra.",
                frase: "O mar me chama porque há um equilíbrio no mundo que precisa ser curado!",
                caricaturaTipo: "moana",
                corBadge: "#06B6D4"
            }
        ]
    },

    // 22. Thaisa Storchi Bergmann
    tht: {
        id: "tht",
        nome: "Thaisa Storchi Bergmann",
        nomeCompleto: "Dra. Thaisa Storchi Bergmann",
        titulo: "A Exploradora dos Buracos Negros",
        subtitulo: "Líder Mundial no Estudo dos Núcleos Ativos de Galáxias",
        area: "Astrofísica & Cosmologia",
        categoria: "exatas",
        epoca: "1955 – Presente",
        pais: "Brasil 🇧🇷 (Porto Alegre, RS)",
        imagem: "Thaisa_Storchi.jpg",
        citacao: "Olhar para as estrelas é viajar no tempo. Compreender os buracos negros é desvendar o coração pulsante das próprias galáxias.",
        resumo: "Fascínio pelo cosmos, pensamento conceitual grandioso e paixão por desvendar os maiores mistérios do tempo e do espaço.",
        feitos: "Primeira cientista no mundo a comprovar observacionalmente que matéria cai continuamente em direção a buracos negros supermassivos no centro de galáxias ativas. Laureada com o Prêmio Internacional L'Oréal-UNESCO Para Mulheres na Ciência em Paris e membra da Academia Brasileira de Ciências.",
        caracteristicas: ["Visão Cosmológica", "Raciocínio Teórico Avançado", "Análise de Dados Espaciais", "Fascínio pelo Infinito"],
        pontosFortes: [
            { titulo: "Macroescala Cósmica", desc: "Habilidade de trabalhar com conceitos monumentais de relatividade e gravidade extrema." },
            { titulo: "Audácia Investigativa", desc: "Investiga o centro escuro das galáxias com telescópios espaciais internacionais." },
            { titulo: "Liderança na Astronomia", desc: "Comanda equipes de astrofísica conectadas com observatórios no Havaí e no Chile." }
        ],
        tracos: { logica: 96, criatividade: 90, estrategia: 85, empatia: 78 },
        livros: [
            {
                titulo: "Mulheres na Física: Panorama e Perspectivas",
                autor: "Sociedade Brasileira de Física (SBF)",
                ano: "2018",
                descricao: "Registra os feitos de Thaisa Storchi e o protagonismo das pesquisadoras brasileiras na astronomia mundial.",
                corCapa: "#3730A3",
                badgeCapa: "Astrofísica Nacional"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Mulheres das Estrelas",
                tipo: "Documentário Nacional",
                ano: "2019",
                plataforma_ou_descricao: "Retrata as astrônomas e astrofísicas brasileiras desvendando o universo através dos maiores telescópios do mundo.",
                trailerId: "e7q8W2yY1nE"
            }
        ],
        pop_culture: [
            {
                nome: "Murph Cooper",
                obra: "Interestelar",
                papel: "Astrofísica da NASA",
                motivo: "Persistência em desvendar a equação gravitacional de um buraco negro para salvar a espécie humana.",
                frase: "Eu sabia que a gravidade nos daria a resposta se olhássemos com atenção suficiente!",
                caricaturaTipo: "murph",
                corBadge: "#6366F1"
            },
            {
                nome: "Dra. Ellie Arroway",
                obra: "Contato",
                papel: "Astrônoma do Projeto SETI",
                motivo: "Devota aos sinais cósmicos, segue firme em busca da verdade além do nosso planeta.",
                frase: "O universo é imenso demais para não explorarmos cada frequência dele!",
                caricaturaTipo: "arroway",
                corBadge: "#8B5CF6"
            },
            {
                nome: "Dra. Samantha Carter",
                obra: "Stargate SG-1",
                papel: "Astrofísica Teórica",
                motivo: "Calcula dobras espaciais, singularidades quânticas e física moderna sorrindo.",
                frase: "A física teórica é só o mapa de um território que ainda vamos pisar!",
                caricaturaTipo: "carter",
                corBadge: "#3B82F6"
            }
        ]
    },

    // 23. Marie Tharp
    mtp: {
        id: "mtp",
        nome: "Marie Tharp",
        nomeCompleto: "Marie Tharp",
        titulo: "A Cartógrafa dos Abismos",
        subtitulo: "A Cientista que Desenhou o Primeiro Mapa do Assoalho Oceânico da Terra",
        area: "Geologia & Oceanografia Cartográfica",
        categoria: "exatas",
        epoca: "1920 – 2006",
        pais: "Estados Unidos 🇺🇸",
        imagem: "Marie_Tharp.jpg",
        citacao: "Havia uma história inteira do planeta esperando para ser revelada nas profundezas do mar. Eu tive a sorte de desenhá-la.",
        resumo: "Paciência minuciosa, atenção aos detalhes que ninguém repara e talento para transformar dados brutos e caóticos em mapas de beleza monumental.",
        feitos: "Impedida de embarcar em navios de pesquisa por superstição de gênero, processou montanhas de dados de sonar no laboratório da Columbia University. Desenhou à mão o primeiro mapa científico tridimensional do fundo do Oceano Atlântico, descobrindo a Dorsal Mesoatlântica e comprovando a Teoria da Tectônica de Placas e da Deriva Continental.",
        caracteristicas: ["Meticulosidade Cartográfica", "Visão Tridimensional", "Resistência Serena ao Ceticismo", "Amor pelos Mapas"],
        pontosFortes: [
            { titulo: "Visão Padrão-Visual", desc: "Habilidade de ver a estrutura geográfica escondida atrás de colunas de números." },
            { titulo: "Persistência Silenciosa", desc: "Trabalhou anos pacientemente até que suas provas geológicas se tornassem incontestáveis." },
            { titulo: "Revolução nas Geociências", desc: "Criou técnicas cartográficas inovadoras adotadas até hoje na oceanografia mundial." }
        ],
        tracos: { logica: 92, criatividade: 94, estrategia: 86, empatia: 79 },
        livros: [
            {
                titulo: "Soundings: The Story of the Woman Who Mapped the Ocean Floor",
                autor: "Hali Felt",
                ano: "2012",
                descricao: "A premiada biografia de Marie Tharp, detalhando sua luta para desenhar os segredos do fundo do mar.",
                corCapa: "#0369A1",
                badgeCapa: "Biografia Premiada"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Cosmos: The Lost Worlds of Planet Earth",
                tipo: "Série Documental (Episódio 9)",
                ano: "2014",
                plataforma_ou_descricao: "Neil deGrasse Tyson dedica grande parte do episódio para narrar como os traços de Marie Tharp provaram a deriva continental.",
                trailerId: "Bff2X-y1xVU"
            }
        ],
        pop_culture: [
            {
                nome: "Audrey Ramirez",
                obra: "Atlantis: O Reino Perdido",
                papel: "Mecânica e Exploradora Submarina",
                motivo: "Pragmática e corajosa: desce às profundezas mais arriscadas para decifrar a engrenagem do mundo.",
                frase: "Para onde os outros veem um abismo sem volta, eu vejo um caminho a ser mapeado!",
                caricaturaTipo: "audrey",
                corBadge: "#0284C7"
            },
            {
                nome: "Milo Thatch",
                obra: "Atlantis",
                papel: "Cartógrafo & Linguista",
                motivo: "Fascinado por dados antigos, junta evidências silenciosas que ninguém levava a sério até provar que estava certo.",
                frase: "Os dados não mentem: as placas tectônicas revelam exatamente o que estamos procurando!",
                caricaturaTipo: "milo",
                corBadge: "#D97706"
            },
            {
                nome: "Tiana",
                obra: "A Princesa e o Sapo",
                papel: "Obstinada e Metódica",
                motivo: "Disciplina diária incansável, sabe exatamente onde quer chegar e não aceita que diminuam seu trabalho.",
                frase: "Com trabalho detalhado e medições certas, a mágica acontece de verdade!",
                caricaturaTipo: "tiana",
                corBadge: "#16A34A"
            }
        ]
    },

    // 24. Djamila Ribeiro
    dj: {
        id: "dj",
        nome: "Djamila Ribeiro",
        nomeCompleto: "Djamila Taís Ribeiro dos Santos",
        titulo: "A Filósofa da Mudança",
        subtitulo: "Vencedora do Prêmio Jabuti e Acadêmica da APL",
        area: "Filosofia Política & Epistemologia Crítica",
        categoria: "humanas",
        epoca: "1980 – Presente",
        pais: "Brasil 🇧🇷 (Santos, SP)",
        imagem: "Djamila_Ribeiro.jpg",
        citacao: "Não basta não ser racista, é preciso ser antirracista. O conhecimento só cumpre seu papel quando democratizado.",
        resumo: "Pensamento crítico aguçado, eloquência transformadora e compromisso inarredável com a justiça social e a igualdade humana.",
        feitos: "Mestra em Filosofia Política pela UNIFESP e membra da Academia Paulista de Letras. Autora de best-sellers laureados com o Prêmio Jabuti como 'Pequeno Manual Antirracista' e 'Lugar de Fala', traduzidos para diversos idiomas. Criadora do selo editorial Sueli Carneiro, aproximando a filosofia da realidade do povo.",
        caracteristicas: ["Eloquência Argumentativa", "Pensamento Crítico", "Equidade e Justiça", "Democratização do Saber"],
        pontosFortes: [
            { titulo: "Clareza Conceitual", desc: "Habilidade de traduzir debates filosóficos densos em reflexões práticas e acessíveis." },
            { titulo: "Coragem no Debate", desc: "Coloca o dedo nas feridas históricas para propor soluções de equidade concretas." },
            { titulo: "Mobilização Cultural", desc: "Cria pontes entre a literatura, a academia e a sociedade civil com elegância ímpar." }
        ],
        tracos: { logica: 92, criatividade: 90, estrategia: 94, empatia: 98 },
        livros: [
            {
                titulo: "Pequeno Manual Antirracista",
                autor: "Djamila Ribeiro",
                ano: "2019",
                descricao: "Vencedor do Prêmio Jabuti, guia prático com 10 lições para combater o racismo estrutural na sociedade.",
                corCapa: "#7C2D12",
                badgeCapa: "Prêmio Jabuti"
            },
            {
                titulo: "Lugar de Fala",
                autor: "Djamila Ribeiro",
                ano: "2017",
                descricao: "Obra de referência sobre epistemologia e o resgate da voz de populações historicamente silenciadas.",
                corCapa: "#831843",
                badgeCapa: "Teoria Crítica"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Roda Viva: Djamila Ribeiro",
                tipo: "Programa Histórico de Entrevistas",
                ano: "2020",
                plataforma_ou_descricao: "Sabatina histórica na TV Cultura com recorde de audiência sobre educação, filosofia e democracia.",
                trailerId: "Q2oK-x7P89M"
            }
        ],
        pop_culture: [
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "Mente Intelectual & Crítica",
                motivo: "Leitora voraz de ensaios filosóficos, rápida nas palavras e intransigente contra preconceitos.",
                frase: "Eu não preciso de permissão para expor a verdade com todas as letras!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "O Tordo da Resistência",
                motivo: "Símbolo inquebrável contra sistemas desiguais, leal àqueles que não têm quem os defenda.",
                frase: "Se nós queimarmos, vocês queimarão conosco: a dignidade não pode ser calada!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Voz da Ética e dos Livros",
                motivo: "Consciência crítica e defensora incansável de causas justas e da ciência com argumentos sólidos.",
                frase: "Defender a verdade nem sempre é a opção mais fácil, mas é a única que vale a pena!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            }
        ]
    },

    // 25. Tatiana Sampaio
    tts: {
        id: "tts",
        nome: "Tatiana Sampaio",
        nomeCompleto: "Dra. Tatiana Coelho de Sampaio",
        titulo: "A Arquiteta da Regeneração Neural",
        subtitulo: "Pioneira nos Estudos da Polilaminina para Lesões Medulares",
        area: "Neurobiologia Celular & Medicina Regenerativa",
        categoria: "saude",
        epoca: "Pesquisadora Contemporânea",
        pais: "Brasil 🇧🇷 (Rio de Janeiro, RJ)",
        imagem: "Tatiana_Sampaio.jpg",
        citacao: "A biologia celular nos ensina que a cura está inscrita nos próprios tecidos; nossa missão é dar às células a chave para se reconstruírem.",
        resumo: "Vocação curativa profunda, persistência laboratorial exemplar e compromisso com o alívio do sofrimento humano através da bioquímica de ponta.",
        feitos: "Professora do Instituto de Ciências Biomédicas da UFRJ, liderou o desenvolvimento da polilaminina, um polímero baseado em proteínas da matriz extracelular que atua como 'ponte' para regenerar axônios e conexões neurais rompidas em lesões da medula espinhal, abrindo novas fronteiras para tratamentos de paralisia.",
        caracteristicas: ["Inovação Biomédica", "Paciência Laboratorial", "Visão Compassiva da Medicina", "Rigor Bioquímico"],
        pontosFortes: [
            { titulo: "Engenharia de Tecidos", desc: "Desenvolveu soluções moleculares para reconstruir conexões nervosas rompidas." },
            { titulo: "Esperança Fundamentada", desc: "Conduz estudos com responsabilidade ética e evidências biológicas robustas." },
            { titulo: "Formação de Novos Cientistas", desc: "Forma mestres e doutores na UFRJ dedicados a terapias celulares avançadas." }
        ],
        tracos: { logica: 91, criatividade: 93, estrategia: 87, empatia: 96 },
        livros: [
            {
                titulo: "Fronteiras da Medicina Regenerativa no Brasil",
                autor: "Publicações FAPERJ / UFRJ",
                ano: "2020",
                descricao: "Registra os protocolos e avanços dos testes de polilaminina em modelos de lesão medular.",
                corCapa: "#0D9488",
                badgeCapa: "Neurociência"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Caminhos da Cura: A Biologia Regenerativa",
                tipo: "Documentário Fiocruz",
                ano: "2022",
                plataforma_ou_descricao: "Apresenta os avanços das cientistas cariocas no cultivo de tecidos para reconstrução neural.",
                trailerId: "w_i8JbK7G8M"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Helen Cho",
                obra: "Vingadores: Era de Ultron",
                papel: "Geneticista & Criadora da Regeneração Tecidual",
                motivo: "Pioneira em bioengenharia celular avançada, cria estruturas biológicas capazes de reconstruir tecidos vivos feridos.",
                frase: "O organismo humano é capaz de reconstruir a si mesmo com a chave molecular correta!",
                caricaturaTipo: "helen_cho",
                corBadge: "#0284C7"
            },
            {
                nome: "Katara",
                obra: "Avatar: A Lenda de Aang",
                papel: "Mestra Curadora das Águas",
                motivo: "Dedicação visceral em regenerar ferimentos, restaurar o equilíbrio do corpo e nunca desistir de quem precisa de esperança.",
                frase: "Não vou permitir que a dor vença quando podemos curar e restaurar a vida!",
                caricaturaTipo: "katara",
                corBadge: "#2563EB"
            },
            {
                nome: "Gemma Simmons",
                obra: "Agents of S.H.I.E.L.D.",
                papel: "Bioquímica & Médica Investigativa",
                motivo: "Brilhantismo molecular em sintetizar antídotos celulares e restaurar a saúde de seus parceiros nos instantes mais críticos.",
                frase: "A bioquímica não é mágica: é a engrenagem mais linda da vida funcionando a nosso favor!",
                caricaturaTipo: "simmons",
                corBadge: "#10B981"
            }
        ]
    },

    // 26. Gabrielle Weber
    glw: {
        id: "glw",
        nome: "Gabrielle Weber",
        nomeCompleto: "Dra. Gabrielle Weber",
        titulo: "A Teórica Criativa da Inclusão",
        subtitulo: "Física Teórica e Campeã da Diversidade na USP",
        area: "Física Teórica, Matemática Aplicada & Divulgação Científica",
        categoria: "exatas",
        epoca: "Pesquisadora Contemporânea",
        pais: "Brasil 🇧🇷 (São Carlos, SP)",
        imagem: "Gabrielle_Weber.jpg",
        citacao: "A física teórica é pura poesia matemática; e essa poesia só é completa quando todos os corpos e mentes têm o direito de recitá-la.",
        resumo: "Criatividade descontraída, amor por quebra-cabeças teóricos e vocação para conectar pessoas diversas através da paixão pela ciência.",
        feitos: "Doutora em Física Teórica e professora no Instituto de Física de São Carlos (IFSC/USP) e na EEL/USP. Pesquisa física quântica e partículas elementares, além de ser líder destacada em projetos de acolhimento e diversidade de gênero e sexualidade no meio acadêmico científico brasileiro.",
        caracteristicas: ["Criatividade Teórica", "Comunicação Acolhedora", "Defesa da Diversidade", "Interdisciplinaridade"],
        pontosFortes: [
            { titulo: "Desmistificação da Ciência", desc: "Explica conceitos de física quântica de forma apaixonante e descomplicada." },
            { titulo: "Construção de Comunidade", desc: "Transforma a sala de aula em espaço seguro onde todos podem errar e criar." },
            { titulo: "Pensamento Fora da Caixa", desc: "Combina linguagem artística, poesia e rigor matemático." }
        ],
        tracos: { logica: 93, criatividade: 96, estrategia: 86, empatia: 95 },
        livros: [
            {
                titulo: "Cadernos de Diversidade na Física",
                autor: "Comissão de Inclusão IFSC/USP",
                ano: "2021",
                descricao: "Ensaios e propostas pedagógicas para acolher diferentes identidades nas exatas.",
                corCapa: "#8B5CF6",
                badgeCapa: "Inclusão & Exatas"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Ciência Para Todes: Vozes da Diversidade",
                tipo: "Documentário USP",
                ano: "2022",
                plataforma_ou_descricao: "Registra projetos de extensão que aproximam a física de estudantes de todas as origens sociais.",
                trailerId: "I739w2fV7eI"
            }
        ],
        pop_culture: [
            {
                nome: "Robin Buckley",
                obra: "Stranger Things",
                papel: "Mente Descontraída & Criptógrafa",
                motivo: "Inteligente, rápida no raciocínio, decifra códigos secretos como quem monta um quebra-cabeça e orgulhosamente autêntica.",
                frase: "Eu decifrei o código! Só precisamos de curiosidade e boa vontade!",
                caricaturaTipo: "robin",
                corBadge: "#8B5CF6"
            },
            {
                nome: "Entrapta",
                obra: "She-Ra e as Princesas do Poder",
                papel: "Engenheira & Cientista Teórica",
                motivo: "Fascinada por robôs e equações, ama a ciência com uma empolgação contagiante que aproxima todo mundo.",
                frase: "Errar faz parte do método: as anomalias são onde as maiores descobertas se escondem!",
                caricaturaTipo: "entrapta",
                corBadge: "#EC4899"
            },
            {
                nome: "Kamala Khan (Ms. Marvel)",
                obra: "Marvel Studios",
                papel: "Jovem Criativa & Protetora",
                motivo: "Espírito criativo, fã de cultura pop e tecnologia, cria pontes entre comunidades diversas com brilho e coração puro.",
                frase: "Quando a gente acredita nas nossas ideias e nos nossos amigos, nenhum desafio é grande demais!",
                caricaturaTipo: "kamala",
                corBadge: "#06B6D4"
            }
        ]
    },

    // 27. Mary Jackson
    mja: {
        id: "mja",
        nome: "Mary Jackson",
        nomeCompleto: "Mary Winston Jackson",
        titulo: "A Primeira Engenheira Aeroespacial Negra da NASA",
        subtitulo: "Pioneira na Aerodinâmica Supersônica e Túneis de Vento",
        area: "Engenharia Aeroespacial & Aerodinâmica",
        categoria: "tecnologia",
        epoca: "1921 – 2005",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Temos que fazer algo assim para que eles tenham interesse pela ciência. Às vezes, eles não sabem que há tantas cientistas parecidas com eles.",
        resumo: "Audácia pioneira, rigor em túneis de vento e coragem judicial. Foi ao tribunal para ter o direito de estudar na escola exclusiva para brancos e tornou-se a primeira engenheira negra da história aeroespacial.",
        feitos: "Formada em Matemática e Ciências Físicas, entrou na NACA em 1951 na Seção de Computação da Área Oeste. Para se tornar engenheira, precisava de cursos noturnos ministrados em uma escola segregada exclusiva para brancos; ela peticionou à Justiça de Hampton, obteve autorização especial e concluiu o programa, tornando-se em 1958 a primeira mulher negra engenheira aeroespacial da NASA. Dedicou décadas ao túnel de vento de pressão supersônica e depois liderou o Programa Federal de Mulheres da NASA para promover a contratação e ascensão de cientistas de minorias.",
        caracteristicas: ["Aerodinâmica Supersônica", "Coragem Jurídica e Histórica", "Pioneirismo nas Engenharias", "Mentoria Ativa"],
        pontosFortes: [
            { titulo: "Túneis de Vento Supersônicos", desc: "Especialista na análise do fluxo de ar e forças de arrasto sobre naves espaciais." },
            { titulo: "Petições pela Igualdade", desc: "Abriu precedentes legais históricos para permitir a formação de engenheiras negras." },
            { titulo: "Apoio a Novas Carreiras", desc: "Trocou o topo da engenharia para chefiar programas de inclusão e igualdade de oportunidades na NASA." }
        ],
        tracos: { logica: 96, criatividade: 89, estrategia: 97, empatia: 95 },
        livros: [
            {
                titulo: "Estrelas Além do Tempo",
                autor: "Margot Lee Shetterly",
                ano: "2016",
                descricao: "Livro aclamado que narra detalhadamente a determinação de Mary Jackson para cursar engenharia e quebrar barreiras na NASA.",
                corCapa: "#B45309",
                badgeCapa: "Best-Seller Histórico"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Estrelas Além do Tempo (Hidden Figures)",
                tipo: "Filme Indicado a 3 Oscars",
                ano: "2016",
                plataforma_ou_descricao: "Janelle Monáe brilha como Mary Jackson, enfrentando o juiz no tribunal para conseguir o diploma de engenharia.",
                trailerId: "5wfrDhgUMGI"
            }
        ],
        pop_culture: [
            {
                nome: "Audrey Ramirez",
                obra: "Atlantis: O Reino Perdido",
                papel: "Engenheira & Especialista Mecânica",
                motivo: "Pragmática, direta, mestre em estruturas metálicas e não aceita que duvidem de suas capacidades técnicas.",
                frase: "Eu projeto, eu construo e eu faço voar!",
                caricaturaTipo: "audrey",
                corBadge: "#0284C7"
            },
            {
                nome: "Tenente Uhura",
                obra: "Star Trek",
                papel: "Pioneira Estelar",
                motivo: "Primeira oficial negra em posto de comando tecnológico numa nave, inspirando respeito internacional.",
                frase: "Comunicação e engenharia abrem qualquer fronteira!",
                caricaturaTipo: "uhura",
                corBadge: "#D97706"
            },
            {
                nome: "Shuri",
                obra: "Pantera Negra",
                papel: "Engenheira de Naves e Voo",
                motivo: "Desenha fuselagens e propulsores aeronáuticos com genialidade e audácia.",
                frase: "Se podemos sonhar com a velocidade do som, podemos construir a asa certa!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            }
        ]
    },

    // 28. Poppy Northcutt
    pno: {
        id: "pno",
        nome: "Poppy Northcutt",
        nomeCompleto: "Frances Brenda Northcutt",
        titulo: "A Primeira Engenheira no Controle de Missão da NASA",
        subtitulo: "A Mente que Calculou o Retorno Seguro da Apollo 8 e Apollo 13",
        area: "Matemática Computacional & Engenharia de Trajetórias",
        categoria: "tecnologia",
        epoca: "1943 – Presente",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Eu olhava ao redor e era a única mulher naquela sala cheia de homens. Sabia que se errasse, diriam que mulheres não servem para isso. Então eu não errei.",
        resumo: "Pioneira solitária sob holofotes mundiais, concentração cirúrgica e coragem para garantir o retorno de astronautas sãos e salvos à Terra.",
        feitos: "Aos 25 anos, tornou-se a primeira mulher a trabalhar na Sala de Controle de Missões da NASA em Houston. Especialista em trajetórias de aborto e retorno translunar, seu software e cálculos garantiram que a histórica missão Apollo 8 (primeira viagem tripulada a orbitar a Lua no Natal de 1968) retornasse com sucesso à atmosfera terrestre. Atuou também no resgate dramático da missão Apollo 13, recebendo a Medalha Presidencial da Liberdade por sua equipe.",
        caracteristicas: ["Cálculo de Retorno Espacial", "Pioneirismo no Controle de Missão", "Foco Extremo Sob Holofotes", "Direito das Mulheres"],
        pontosFortes: [
            { titulo: "Trajetórias de Retorno Translunar", desc: "Criou manobras orbitais que garantiam a reentrada de naves com combustível mínimo." },
            { titulo: "Resgate da Apollo 13", desc: "Trabalhou ininterruptamente nos cálculos de propulsão para trazer os três astronautas com vida após a explosão do tanque de oxigênio." },
            { titulo: "Ativismo Jurídico Feminista", desc: "Após a NASA, formou-se em Direito e tornou-se a primeira promotora de direitos da mulher em Houston." }
        ],
        tracos: { logica: 98, criatividade: 88, estrategia: 96, empatia: 92 },
        livros: [
            {
                titulo: "Apollo's Women: The Engineers Who Sent Man to the Moon",
                autor: "Smithsonian History",
                ano: "2019",
                descricao: "Registra a atuação solitária e magistral de Poppy Northcutt nas salas de comando da NASA nos anos 60.",
                corCapa: "#0369A1",
                badgeCapa: "História Aeroespacial"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Apollo's Moon Shot: Poppy Northcutt",
                tipo: "Documentário Smithsonian Channel",
                ano: "2019",
                plataforma_ou_descricao: "Imagens restauradas e relatos em primeira pessoa de Poppy na sala de controle da missão Apollo 8.",
                trailerId: "O895Wv4Y1p8"
            }
        ],
        pop_culture: [
            {
                nome: "Murph Cooper",
                obra: "Interestelar",
                papel: "A Cientista na Sala de Comando",
                motivo: "Comanda o destino das missões espaciais de volta para casa com pura matemática e nervos de aço.",
                frase: "Eu calculo a rota de volta para que ninguém fique para trás no vácuo!",
                caricaturaTipo: "murph",
                corBadge: "#6366F1"
            },
            {
                nome: "Dra. Samantha Carter",
                obra: "Stargate SG-1",
                papel: "Oficial Técnica de Missões",
                motivo: "Calcula coordenadas de teletransporte e manobras espaciais no limite do tempo.",
                frase: "Calculei a trajetória exata da janela de reentrada!",
                caricaturaTipo: "carter",
                corBadge: "#3B82F6"
            },
            {
                nome: "Robin Buckley",
                obra: "Stranger Things",
                papel: "Mente Fria Sob Pressão",
                motivo: "Não perde a calma no epicentro do perigo e encontra a saída lógica enquanto todos entram em pânico.",
                frase: "Se mantermos a calma, os números nos tiram dessa com vida!",
                caricaturaTipo: "robin",
                corBadge: "#8B5CF6"
            }
        ]
    },

    // 29. As Programadoras do ENIAC (Betty Snyder, Kay McNulty, Marlyn Wescoff, Fran Bilas, Ruth Lichterman, Adele Goldstine)
    eni: {
        id: "eni",
        nome: "As Programadoras do ENIAC",
        nomeCompleto: "Betty Snyder, Kay McNulty, Marlyn Wescoff, Fran Bilas, Ruth Lichterman & Adele Goldstine",
        titulo: "As Pioneiras da Programação Eletrônica",
        subtitulo: "As Seis Mulheres que Programaram o Primeiro Computador Digital do Mundo",
        area: "Ciência da Computação & Engenharia de Sistemas",
        categoria: "tecnologia",
        epoca: "1945 – 1955",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Nós tínhamos que descobrir como a máquina funcionava olhando para diagramas lógicos em folhas de papel.",
        resumo: "Pioneirismo coletivo genial. Sem manuais, sem linguagens de programação e sem sistemas operacionais, vocês criaram a arte de programar cabos, relés e tubos de vácuo.",
        feitos: "Em 1945, o exército americano construiu o ENIAC (Electronic Numerical Integrator and Computer), uma máquina de 30 toneladas com 18.000 válvulas. Seis matemáticas brilhantes — Betty Snyder Holberton, Kay McNulty Mauchly, Marlyn Wescoff Meltzer, Fran Bilas Spence, Ruth Lichterman Teitelbaum e a técnica Adele Goldstine — foram encarregadas de fazê-la funcionar. Elas programaram o ENIAC manipulando manualmente centenas de cabos e interruptores, inventaram os primeiros pontos de depuração (breakpoints) e escreveram o primeiro manual de computação do mundo.",
        caracteristicas: ["Primeira Programação Digital", "Invenção dos Breakpoints", "Pioneirismo Sem Manuais", "Engenharia de Sistemas Físicos"],
        pontosFortes: [
            { titulo: "A Invenção do Código", desc: "Criaram diagramas de fluxo de dados e circuitos de chaveamento antes de existir qualquer software." },
            { titulo: "Depuração Eletrônica", desc: "Betty Snyder inventou o conceito de 'breakpoint' para pausar a execução e encontrar falhas elétricas." },
            { titulo: "O Manual do ENIAC", desc: "Adele Goldstine escreveu o primeiro manual técnico de programação da história da humanidade." }
        ],
        tracos: { logica: 98, criatividade: 94, estrategia: 95, empatia: 88 },
        livros: [
            {
                titulo: "Proving Ground: The Untold Story of the Six Women Who Programmed the World's First Modern Computer",
                autor: "Kathy Kleiman",
                ano: "2022",
                descricao: "A obra definitiva e comovente de Kathy Kleiman resgatando a voz e a história das seis programadoras do ENIAC.",
                corCapa: "#4338CA",
                badgeCapa: "História da Computação"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "The Computers: The Remarkable Untold Story of the ENIAC Programmers",
                tipo: "Documentário Premiado",
                ano: "2014",
                plataforma_ou_descricao: "Dirigido por Kathy Kleiman, reúne entrevistas raras das programadoras originais contando como ligaram o ENIAC.",
                trailerId: "C2_q4hF8N1U"
            }
        ],
        pop_culture: [
            {
                nome: "Penelope Garcia",
                obra: "Criminal Minds",
                papel: "Mestra dos Circuitos",
                motivo: "Comanda centenas de telas, cabos e servidores ao mesmo tempo como uma verdadeira maestrina digital.",
                frase: "Dê-me alguns interruptores e cabos que eu reprogramo a realidade!",
                caricaturaTipo: "penelope",
                corBadge: "#EC4899"
            },
            {
                nome: "Shuri",
                obra: "Pantera Negra",
                papel: "Arquiteta de Hardware e Software",
                motivo: "Constrói a máquina física e escreve o código no mesmo instante, sem precisar de manual prévio.",
                frase: "O melhor manual é aquele que a gente escreve enquanto inventa o futuro!",
                caricaturaTipo: "shuri",
                corBadge: "#7C3AED"
            },
            {
                nome: "Audrey Ramirez",
                obra: "Atlantis",
                papel: "Mecânica de Grandes Máquinas",
                motivo: "Conecta os fios certos, gira as chaves e faz os motores gigantes funcionarem em segundos.",
                frase: "Se tem válvulas e eletricidade, eu faço cantar como um violino!",
                caricaturaTipo: "audrey",
                corBadge: "#0284C7"
            }
        ]
    },

    // 30. Irmã Mary Kenneth Keller
    mke: {
        id: "mke",
        nome: "Irmã Mary Kenneth Keller",
        nomeCompleto: "Irmã Mary Kenneth Keller, B.V.M.",
        titulo: "A Doutora da Linguagem BASIC",
        subtitulo: "Primeira Pessoa nos EUA a Obter Doutorado em Ciência da Computação",
        area: "Ciência da Computação & Educação Tecnológica",
        categoria: "tecnologia",
        epoca: "1913 – 1985",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Pela primeira vez estamos passando por uma explosão cognitiva. No futuro, os computadores serão o principal mecanismo de aprendizado da sociedade.",
        resumo: "Religiosa e cientista visionária, pioneira no ensino da computação e na popularização das linguagens de programação para estudantes.",
        feitos: "Em 7 de junho de 1965, tornou-se a primeira pessoa nos Estados Unidos a receber o título de Doutora (PhD) em Ciência da Computação (pela Universidade de Wisconsin-Madison). No Dartmouth College, ajudou a desenvolver a icônica linguagem de programação BASIC (Beginner's All-purpose Symbolic Instruction Code), criada especificamente para que estudantes de qualquer área pudessem aprender a programar computadores. Fundou o departamento de computação da Clarke University, que liderou por duas décadas.",
        caracteristicas: ["Primeiro Doutorado em Computação", "Cocriação da Linguagem BASIC", "Democratização do Código", "Visão Precoce da IA"],
        pontosFortes: [
            { titulo: "A Linguagem BASIC", desc: "Ajudou a criar a linguagem que democratizou o computador pessoal e formou as primeiras gerações de programadores." },
            { titulo: "Educação em Computação", desc: "Defendia que o ensino de computadores deveria ser universal e multidisciplinar." },
            { titulo: "Inclusão Feminina em TI", desc: "Incentivava ativamente mulheres a ingressarem nos cursos de ciência da computação nos anos 60 e 70." }
        ],
        tracos: { logica: 96, criatividade: 91, estrategia: 93, empatia: 96 },
        livros: [
            {
                titulo: "Pioneering Women in American Mathematics & Computing",
                autor: "Judy Green e Jeanne LaDuke",
                ano: "2009",
                descricao: "Registra os feitos históricos da Irmã Keller e a fundação dos primeiros departamentos de computação acadêmica nos EUA.",
                corCapa: "#1E3A8A",
                badgeCapa: "História Acadêmica"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Pioneering Women in Computing: Mary Kenneth Keller",
                tipo: "Documentário / ACM History",
                ano: "2018",
                plataforma_ou_descricao: "Apresenta depoimentos de ex-alunos e historiadores sobre o papel da Irmã Keller na criação do BASIC.",
                trailerId: "1f_35VqN1jQ"
            }
        ],
        pop_culture: [
            {
                nome: "Hermione Granger",
                obra: "Harry Potter",
                papel: "A Mestra dos Livros e da Lógica",
                motivo: "Disciplina acadêmica impecável, vocação pedagógica e crença no poder do estudo metódico.",
                frase: "Qualquer pessoa pode aprender a programar se o método for generoso e claro!",
                caricaturaTipo: "hermione",
                corBadge: "#DC2626"
            },
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Estudante Pioneira",
                motivo: "Une valores humanistas e amor pelo saber tecnológico para educar a comunidade ao seu redor.",
                frase: "O conhecimento foi feito para ser compartilhado com todos!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            },
            {
                nome: "Velma Dinkley",
                obra: "Scooby-Doo",
                papel: "A Educadora dos Enigmas",
                motivo: "Ensina passo a passo como desmontar códigos e problemas aparentemente insolúveis.",
                frase: "Com o código certo, qualquer mente se torna capaz de criar soluções!",
                caricaturaTipo: "velma",
                corBadge: "#F59E0B"
            }
        ]
    },

    // 31. Gertrude Elion
    gel: {
        id: "gel",
        nome: "Gertrude Elion",
        nomeCompleto: "Gertrude Belle Elion",
        titulo: "A Arquiteta dos Medicamentos Modernos",
        subtitulo: "Prêmio Nobel de Medicina e Desenvolvedora de Terapias Contra o Câncer",
        area: "Bioquímica, Farmacologia & Imunologia",
        categoria: "saude",
        epoca: "1918 – 1999",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "Não deixe ninguém te dizer que você não pode fazer isso. A única pessoa que pode decidir seus limites é você mesma.",
        resumo: "Método farmacológico revolucionário, perseverança inabalável e dedicação de uma vida inteira a curar doenças humanas fatais.",
        feitos: "Revolucionou a medicina mundial ao abandonar o método clássico de tentativa e erro na farmacologia, passando a desenhar moléculas sintéticas direcionadas especificamente às falhas metabólicas de células doentes sem destruir as saudáveis. Desenvolveu medicamentos pioneiros que curaram a leucemia infantil (6-mercaptopurina), o primeiro antiviral eficaz da história (Aciclovir), o primeiro imunossupressor para transplantes de órgãos (Azatioprina) e tratamentos para gota e malária. Laureada com o Prêmio Nobel de Fisiologia ou Medicina em 1988.",
        caracteristicas: ["Desenho Racional de Fármacos", "Invenção do Aciclovir", "Cura da Leucemia Infantil", "Prêmio Nobel de Medicina"],
        pontosFortes: [
            { titulo: "Cura da Leucemia", desc: "Criou terapias que transformaram a leucemia linfoide aguda de uma sentença fatal para uma doença tratável com 80%+ de cura." },
            { titulo: "A Era dos Antivirais", desc: "Criou o Aciclovir, provando contra a comunidade médica da época que vírus podiam ser combatidos farmacologicamente." },
            { titulo: "Transplantes de Órgãos", desc: "Sua azatioprina tornou viáveis os primeiros transplantes bem-sucedidos de rins e corações na história." }
        ],
        tracos: { logica: 98, criatividade: 94, estrategia: 93, empatia: 99 },
        livros: [
            {
                titulo: "Gertrude Elion: Nobel Prize-Winning Chemist",
                autor: "Rachel Kranz",
                ano: "2004",
                descricao: "Biografia inspiradora sobre como Elion superou o machismo da época da Grande Depressão para salvar milhões de vidas.",
                corCapa: "#047857",
                badgeCapa: "Prêmio Nobel"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Gertrude Elion: Nobel Laureate in Medicine",
                tipo: "Documentário Science History Institute",
                ano: "2018",
                plataforma_ou_descricao: "Registros e depoimentos de Gertrude sobre a criação dos medicamentos antivirais e a química curativa.",
                trailerId: "nI75T9aE_mY"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Cristina Yang",
                obra: "Grey's Anatomy",
                papel: "Médica de Precisão Incomparável",
                motivo: "Dedicação obsessiva pelo alívio da dor do paciente e busca incessante por protocolos que salvam vidas.",
                frase: "A medicina é o compromisso inegociável de encontrar a cura onde ninguém viu antes!",
                caricaturaTipo: "yang",
                corBadge: "#0284C7"
            },
            {
                nome: "Gemma Simmons",
                obra: "Agents of S.H.I.E.L.D.",
                papel: "Farmacologista & Bioquímica",
                motivo: "Sintetiza compostos moleculares sob medida para neutralizar qualquer toxina ou patógeno celular.",
                frase: "Cada molécula que eu desenho é uma vitória contra o sofrimento!",
                caricaturaTipo: "simmons",
                corBadge: "#10B981"
            },
            {
                nome: "Dra. Beverly Crusher",
                obra: "Star Trek",
                papel: "Chefe Médica",
                motivo: "Pesquisa remédios avançados que curam doenças epidêmicas com método rigoroso e coração humano.",
                frase: "A ciência dos medicamentos existe para proteger cada vida da galáxia!",
                caricaturaTipo: "crusher",
                corBadge: "#0D9488"
            }
        ]
    },

    // 32. Nettie Stevens
    nst: {
        id: "nst",
        nome: "Nettie Stevens",
        nomeCompleto: "Nettie Maria Stevens",
        titulo: "A Decifradora dos Cromossomos Sexuais",
        subtitulo: "A Geneticista que Descobriu a Base Cromossômica do Sexo (X e Y)",
        area: "Genética, Citologia & Embriologia",
        categoria: "biologicas",
        epoca: "1861 – 1912",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "A observação atenta sob o microscópio revela a verdade da hereditariedade muito antes das teorias preconcebidas.",
        resumo: "Paciência microscópica de elite, rigor citológico e capacidade de resolver dilemas biológicos que intrigavam cientistas há séculos.",
        feitos: "Em 1905, no Bryn Mawr College, desvendou o enigma biológico fundamental de como o sexo biológico é determinado nos seres vivos. Investigando células germinativas do besouro Tenebrio molitor, provou empiricamente que o sexo não é determinado pela temperatura ambiental ou nutrição (como se acreditava), mas pela presença de cromossomos sexuais distintos: um par igual (XX) nas fêmeas e um cromossomo menor (XY) nos machos, estabelecendo as bases da citogenética mundial.",
        caracteristicas: ["Descoberta dos Cromossomos X e Y", "Microscopia de Alta Precisão", "Pioneirismo em Citologia", "Genética Mendeliana"],
        pontosFortes: [
            { titulo: "A Descoberta dos Cromossomos X e Y", desc: "Forneceu a primeira prova física visível de que as características mendelianas residem nos cromossomos celulares." },
            { titulo: "Microscopia Primorosa", desc: "Especialista no preparo e tingimento de lâminas citológicas extremamente delicadas." },
            { titulo: "Superação Tardia", desc: "Trabalhou como bibliotecária até os 35 anos para juntar dinheiro e ingressar no doutorado na universidade." }
        ],
        tracos: { logica: 97, criatividade: 89, estrategia: 88, empatia: 86 },
        livros: [
            {
                titulo: "Studies in Spermatogenesis: The Discovery of Sex Determination",
                autor: "Nettie M. Stevens",
                ano: "1905",
                descricao: "Publicação histórica original do Carnegie Institution de Washington que mudou para sempre a história da genética.",
                corCapa: "#0F766E",
                badgeCapa: "Marco da Genética"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Nettie Stevens and the Discovery of Sex Chromosomes",
                tipo: "Documentário PBS Origins",
                ano: "2020",
                plataforma_ou_descricao: "Explica didaticamente como as observações ao microscópio de Nettie Stevens fundaram a citogenética moderna.",
                trailerId: "Fw7hH6W_9V0"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Dana Scully",
                obra: "Arquivo X",
                papel: "Geneticista Forense",
                motivo: "Olhar aguçado no microscópio: identifica marcadores biológicos e cromossômicos que outros ignoram.",
                frase: "O microscópio nos mostra a evidência irrefutável da natureza!",
                caricaturaTipo: "scully",
                corBadge: "#2563EB"
            },
            {
                nome: "Velma Dinkley",
                obra: "Scooby-Doo",
                papel: "Investigadora Minuciosa",
                motivo: "Compara pistas milimétricas e revela o detalhe microscópico que desvenda o enigma.",
                frase: "As evidências nas lâminas microscópicas contam toda a verdade!",
                caricaturaTipo: "velma",
                corBadge: "#F59E0B"
            },
            {
                nome: "Gemma Simmons",
                obra: "Agents of S.H.I.E.L.D.",
                papel: "Citologista de Bancada",
                motivo: "Analisa a estrutura cromossômica e celular de novos organismos com precisão infalível.",
                frase: "A genética básica é a chave mestra de toda a vida orgânica!",
                caricaturaTipo: "simmons",
                corBadge: "#10B981"
            }
        ]
    },

    // 33. Maria José Deane
    mde: {
        id: "mde",
        nome: "Maria José Deane",
        nomeCompleto: "Dra. Maria José von Paumgartten Deane",
        titulo: "A Desbravadora da Parasitologia na Amazônia",
        subtitulo: "Médica e Cientista Brasileira Pioneira no Combate à Malária e Doença de Chagas",
        area: "Parasitologia Médica, Entomologia & Saúde Pública",
        categoria: "saude",
        epoca: "1916 – 1995",
        pais: "Brasil 🇧🇷 (Belém, Pará / Rio de Janeiro, RJ)",
        imagem: "sem_foto.png",
        citacao: "A ciência de campo na Amazônia exige coragem nas matas e rigor no microscópio. Salvar populações esquecidas é o dever sagrado da medicina.",
        resumo: "Coragem sertaneja e amazônica, amor pelas pesquisas de campo e dedicação absoluta ao controle de endemias tropicais brasileiras.",
        feitos: "Formada em Medicina pela Faculdade de Medicina do Pará em 1937, embrenhou-se nas florestas do Norte e Nordeste brasileiro para combater epidemias de malária, leishmaniose visceral e Doença de Chagas. Ao lado de seu marido Leônidas Deane, descreveu novas espécies de mosquitos vetores, descobriu o ciclo extrauterino do Trypanosoma cruzi em gambás e mamíferos silvestres e chefiou o Departamento de Protozoologia do Instituto Oswaldo Cruz (Fiocruz), onde um dos pavilhões principais leva seu nome.",
        caracteristicas: ["Pesquisa de Campo Amazônica", "Controle de Endemias Tropicais", "Parasitologia da Fiocruz", "Coragem em Expedições"],
        pontosFortes: [
            { titulo: "Erradicação da Malária", desc: "Atuou na histórica campanha do Serviço de Malária do Nordeste que erradicou o mosquito transmissor invasor Anopheles gambiae." },
            { titulo: "Doença de Chagas na Amazônia", desc: "Descobriu que o parasita da Doença de Chagas se multiplicava no lúmen das glândulas de cheiro dos gambás." },
            { titulo: "Legado na Fiocruz", desc: "Formou centenas de pesquisadores em protozoologia médica que lideram laboratórios em todo o Brasil." }
        ],
        tracos: { logica: 96, criatividade: 90, estrategia: 94, empatia: 98 },
        livros: [
            {
                titulo: "História da Parasitologia no Brasil: Maria e Leônidas Deane",
                autor: "Instituto Oswaldo Cruz (Fiocruz)",
                ano: "2001",
                descricao: "Registros históricos das expedições fluviais e das descobertas biológicas do casal Deane no coração da floresta amazônica.",
                corCapa: "#047857",
                badgeCapa: "Memória da Fiocruz"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Maria José Deane: A Pioneira da Parasitologia na Amazônia",
                tipo: "Documentário Fiocruz",
                ano: "2016",
                plataforma_ou_descricao: "Retrata a rotina de Dra. Maria José nas matas brasileiras, coletando amostras e salvando comunidades ribeirinhas.",
                trailerId: "q_QyQ2sO8F0"
            }
        ],
        pop_culture: [
            {
                nome: "Dra. Ellie Sattler",
                obra: "Jurassic Park",
                papel: "Cientista de Campo Destemida",
                motivo: "Não tem medo de andar nas matas úmidas, sujar as botas e enfrentar os elementos para proteger a vida.",
                frase: "A pesquisa na selva exige respeito pela natureza e olhos bem atentos!",
                caricaturaTipo: "ellie_sattler",
                corBadge: "#10B981"
            },
            {
                nome: "Moana",
                obra: "Disney",
                papel: "Desbravadora dos Rios e Terras",
                motivo: "Cruza florestas e rios com bravura para curar sua comunidade de pragas e doenças.",
                frase: "Nenhum rio ou floresta é perigoso demais quando estamos salvando nosso povo!",
                caricaturaTipo: "moana",
                corBadge: "#06B6D4"
            },
            {
                nome: "Princesa Mononoke (San)",
                obra: "Studio Ghibli",
                papel: "Protetora dos Seres Silvestres",
                motivo: "Conhece cada bicho, cada parasita e cada planta da floresta como a palma da sua mão.",
                frase: "Compreender os seres da mata é o único caminho para vivermos em paz e saúde!",
                caricaturaTipo: "san",
                corBadge: "#059669"
            }
        ]
    },

    // 34. Patricia Hill Collins
    pco: {
        id: "pco",
        nome: "Patricia Hill Collins",
        nomeCompleto: "Dra. Patricia Hill Collins",
        titulo: "A Teórica da Interseccionalidade e da Matriz de Dominação",
        subtitulo: "Primeira Mulher Negra Presidente da Associação Americana de Sociologia",
        area: "Sociologia, Epistemologia Crítica & Estudos de Raça e Gênero",
        categoria: "humanas",
        epoca: "1948 – Presente",
        pais: "Estados Unidos 🇺🇸",
        imagem: "sem_foto.png",
        citacao: "A opressão de raça, classe e gênero não atua em linhas isoladas; elas se cruzam e criam uma matriz que só o pensamento crítico pode desmontar.",
        resumo: "Arquitetura sociológica impecável, visão integradora e clareza para mapear como as estruturas de poder se interconectam na sociedade.",
        feitos: "Professora emérita da Universidade de Maryland e da Universidade de Cincinnati, publicou em 1990 sua obra monumental 'Pensamento Feminista Negro: Conhecimento, Consciência e a Política do Empoderamento'. Formulou o influente conceito sociológico da 'Matriz de Dominação', demonstrando como raça, classe social, gênero e nacionalidade se sobrepõem e se reforçam mutuamente. Em 2008, tornou-se a primeira mulher negra a presidir a American Sociological Association (ASA) e recebeu o cobiçado Prêmio Berggruen de Filosofia.",
        caracteristicas: ["Matriz de Dominação", "Pensamento Feminista Negro", "Sociologia Interseccional", "Epistemologia dos Oprimidos"],
        pontosFortes: [
            { titulo: "Pensamento Feminista Negro", desc: "Obra de referência global que elevou a sabedoria das mulheres negras ao estatuto de teoria sociológica formal." },
            { titulo: "A Matriz de Dominação", desc: "Criou o mapa conceitual que orienta os estudos sociológicos, jurídicos e políticos contemporâneos no mundo todo." },
            { titulo: "Prêmio Berggruen de Filosofia", desc: "Laureada com o maior prêmio mundial de filosofia por suas contribuições ao entendimento da justiça humana." }
        ],
        tracos: { logica: 95, criatividade: 93, estrategia: 96, empatia: 97 },
        livros: [
            {
                titulo: "Pensamento Feminista Negro",
                autor: "Patricia Hill Collins",
                ano: "1990",
                descricao: "Clássico mundial da sociologia que analisa a literatura, o blues e a resistência das mulheres negras como teoria crítica.",
                corCapa: "#7C2D12",
                badgeCapa: "Clássico da Sociologia"
            },
            {
                titulo: "Interseccionalidade",
                autor: "Patricia Hill Collins e Sirma Bilge",
                ano: "2016",
                descricao: "Guia analítico indispensável sobre como a interseccionalidade funciona como ferramenta prática de direitos humanos.",
                corCapa: "#4C1D95",
                badgeCapa: "Teoria Interseccional"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Patricia Hill Collins: Intersecting Oppressions",
                tipo: "Documentário / Harvard Education",
                ano: "2017",
                plataforma_ou_descricao: "Conferência e depoimento sobre a importância de articular raça, gênero e justiça na educação pública.",
                trailerId: "kX_d2bV1O9Q"
            }
        ],
        pop_culture: [
            {
                nome: "Annalise Keating",
                obra: "How to Get Away with Murder",
                papel: "Mestra das Estruturas Sociais",
                motivo: "Compreende como o sistema penal e as elites operam e usa esse mapa para defender os oprimidos.",
                frase: "Se você entender como o poder opera em conjunto, ninguém jamais te derrotará!",
                caricaturaTipo: "annalise",
                corBadge: "#7C3AED"
            },
            {
                nome: "Djamila Ribeiro",
                obra: "Voz Intelectual",
                papel: "A Filósofa da Consciência",
                motivo: "Companheira teórica de reflexão: traduz a matriz de dominação em livros populares que conscientizam a sociedade.",
                frase: "O saber sociológico só é pleno quando liberta as pessoas!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            },
            {
                nome: "Ororo Munroe (Tempestade)",
                obra: "X-Men",
                papel: "A Guardiã dos Direitos",
                motivo: "Enxerga a rede de preconceitos que afetam diferentes minorias e une todas as vozes em uma frente nobre.",
                frase: "Quando todas as forças de justiça se unem, o mundo floresce!",
                caricaturaTipo: "storm",
                corBadge: "#4F46E5"
            }
        ]
    },

    // 35. Rosa Luxemburgo
    rlu: {
        id: "rlu",
        nome: "Rosa Luxemburgo",
        nomeCompleto: "Rozalia Luxenburg",
        titulo: "A Economista da Rosa Vermelha",
        subtitulo: "Doutora em Economia Política, Filósofa e Pacifista Histórica",
        area: "Economia Política, Teoria Crítica & Filosofia da História",
        categoria: "humanas",
        epoca: "1871 – 1919",
        pais: "Polônia 🇵🇱 / Alemanha 🇩🇪",
        imagem: "sem_foto.png",
        citacao: "A liberdade é sempre a liberdade daquele que pensa de modo diferente.",
        resumo: "Pensamento econômico afiado, paixão inegociável pela liberdade democrática e coragem inabalável contra a guerra e o imperialismo.",
        feitos: "Uma das poucas mulheres de sua época a obter o título de Doutora em Direito e Economia Política (pela Universidade de Zurique em 1897). Em sua obra-prima 'A Acumulação do Capital' (1913), formulou uma teoria econômica pioneira demonstrando como o imperialismo depende da exploração contínua de economias não capitalistas do Sul global. Foi uma das mais ferrenhas opositoras da Primeira Guerra Mundial, pagando com prisões e o martírio por defender a paz e a democracia das massas trabalhadoras.",
        caracteristicas: ["Doutorado em Economia Política", "A Acumulação do Capital", "Pacifismo Revolucionário", "Defesa da Liberdade de Opinião"],
        pontosFortes: [
            { titulo: "Teoria Econômica do Imperialismo", desc: "Antecipou as crises de expansão do capital global com rigor matemático e sociológico." },
            { titulo: "Liberdade Democrática Inegociável", desc: "Criticava tanto a opressão autoritária burguesa quanto os desvios burocráticos do poder centralizado." },
            { titulo: "Oratória e Paixão", desc: "Mobilizava multidões nas ruas e redações de jornais com argumentos brilhantes." }
        ],
        tracos: { logica: 95, criatividade: 93, estrategia: 97, empatia: 98 },
        livros: [
            {
                titulo: "A Acumulação do Capital: Contribuição para a Explicação Econômica do Imperialismo",
                autor: "Rosa Luxemburgo",
                ano: "1913",
                descricao: "Obra monumental de teoria macroeconômica sobre o comércio internacional, armamentos e expansão de mercados.",
                corCapa: "#991B1B",
                badgeCapa: "Clássico da Economia"
            },
            {
                titulo: "Reforma ou Revolução?",
                autor: "Rosa Luxemburgo",
                ano: "1899",
                descricao: "Ensaio clássico indispensável sobre as transformações históricas da sociedade e a democracia popular.",
                corCapa: "#B91C1C",
                badgeCapa: "Teoria Política"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Rosa Luxemburgo",
                tipo: "Filme / Palma de Ouro em Cannes",
                ano: "1986",
                plataforma_ou_descricao: "Dirigido por Margarethe von Trotta e estrelado por Barbara Sukowa (melhor atriz em Cannes), retrata sua vida corajosa e suas cartas íntimas.",
                trailerId: "J8n-oM27y5E"
            }
        ],
        pop_culture: [
            {
                nome: "Katniss Everdeen",
                obra: "Jogos Vorazes",
                papel: "A Chama Rebelde da Liberdade",
                motivo: "Não tolera tiranos de nenhum lado e defende os trabalhadores com coragem que inflama as multidões.",
                frase: "A liberdade só tem valor quando pertence a todos os que pensam diferente!",
                caricaturaTipo: "katniss",
                corBadge: "#B91C1C"
            },
            {
                nome: "Maeve Wiley",
                obra: "Sex Education",
                papel: "A Pensadora Insubmissa",
                motivo: "Lê teoria política densa, desafia o sistema e protege os vulneráveis com honestidade crua.",
                frase: "A liberdade é pensar por si mesma sem dever satisfações a quem quer nos controlar!",
                caricaturaTipo: "maeve",
                corBadge: "#DB2777"
            },
            {
                nome: "General Leia Organa",
                obra: "Star Wars",
                papel: "A Comandante contra o Império",
                motivo: "Luta pela paz genuína e pela democracia popular arriscando a própria vida na linha de frente.",
                frase: "A paz sem justiça é só tirania disfarçada!",
                caricaturaTipo: "leia",
                corBadge: "#2563EB"
            }
        ]
    },

    // 36. Harriet Martineau
    hma: {
        id: "hma",
        nome: "Harriet Martineau",
        nomeCompleto: "Harriet Martineau",
        titulo: "A Primeira Mulher Socióloga da História",
        subtitulo: "Pioneira na Metodologia da Sociologia e Tradutora de Auguste Comte",
        area: "Sociologia, Economia Política & Jornalismo Investigativo",
        categoria: "humanas",
        epoca: "1802 – 1876",
        pais: "Reino Unido 🇬🇧",
        imagem: "sem_foto.png",
        citacao: "Ao estudar uma sociedade, é preciso prestar atenção em todas as suas instituições: a religião, o casamento, os presídios e, acima de tudo, o tratamento dado às mulheres.",
        resumo: "Pioneirismo sociológico empírico, escrita acessível para as massas e coragem abolicionista e feminista na Era Vitoriana.",
        feitos: "Considerada a primeira socióloga mulher do mundo. Escreveu em 1838 'How to Observe Morals and Manners', o primeiro tratado metodológico da história da sociologia sobre como conduzir pesquisas sociais empíricas e entrevistas de campo sem viés. Traduziu e condensou a obra 'Curso de Filosofia Positiva' de Auguste Comte do francês para o inglês com tanta clareza que o próprio Comte recomendava a versão de Harriet aos seus alunos. Foi ativista ferrenha pela abolição da escravidão nos EUA e pelos direitos trabalhistas das mulheres.",
        caracteristicas: ["Primeiro Manual de Sociologia", "Metodologia Empírica", "Abolicionismo Histórico", "Didática Econômica"],
        pontosFortes: [
            { titulo: "O Primeiro Manual de Pesquisa Social", desc: "Criou métodos de coleta de dados estatísticos e observação participante antes dos sociólogos homens." },
            { titulo: "Ilustrações de Economia Política", desc: "Publicou contos didáticos que ensinaram economia para mais de 500.000 leitores da classe trabalhadora." },
            { titulo: "Crítica à Escravidão", desc: "Viajou pelo sul dos Estados Unidos documentando a crueldade do cativeiro e denunciando a hipocrisia das elites." }
        ],
        tracos: { logica: 94, criatividade: 91, estrategia: 93, empatia: 96 },
        livros: [
            {
                titulo: "How to Observe Morals and Manners",
                autor: "Harriet Martineau",
                ano: "1838",
                descricao: "O primeiro livro-texto sobre metodologia de pesquisa sociológica do mundo, analisando costumes, religião e poder.",
                corCapa: "#1E3A8A",
                badgeCapa: "Pioneirismo Sociológico"
            },
            {
                titulo: "Society in America",
                autor: "Harriet Martineau",
                ano: "1837",
                descricao: "Investigação sociológica contundente sobre a democracia americana e sua contradição com a escravidão e o machismo.",
                corCapa: "#4C1D95",
                badgeCapa: "Sociologia Crítica"
            }
        ],
        filmes_documentarios: [
            {
                titulo: "Harriet Martineau: The First Woman Sociologist",
                tipo: "Documentário BBC / Open University",
                ano: "2019",
                plataforma_ou_descricao: "Explora a jornada da mulher surda que desafiou a aristocracia vitoriana para fundar as ciências sociais modernas.",
                trailerId: "d6y7R_8xH2g"
            }
        ],
        pop_culture: [
            {
                nome: "Lisa Simpson",
                obra: "Os Simpsons",
                papel: "A Socióloga Investigativa",
                motivo: "Observa a comunidade com seu bloquinho de notas e aponta as contradições sociais com inteligência.",
                frase: "Para entender uma cidade, é preciso observar quem está sofrendo em silêncio!",
                caricaturaTipo: "lisa",
                corBadge: "#F59E0B"
            },
            {
                nome: "Velma Dinkley",
                obra: "Scooby-Doo",
                papel: "A Observadora Metódica",
                motivo: "Anota cada detalhe sociológico e comportamento humano antes de tirar qualquer conclusão precipitada.",
                frase: "A observação atenta desmonta qualquer preconceito ou mistério!",
                caricaturaTipo: "velma",
                corBadge: "#EA580C"
            },
            {
                nome: "Hermione Granger",
                obra: "Harry Potter",
                papel: "Fundadora do F.A.L.E. (Direitos dos Oprimidos)",
                motivo: "Pesquisa a fundo a história das instituições para proteger os seres vulneráveis e desamparados.",
                frase: "Uma sociedade só é justa quando todos os seus membros têm dignidade e voz!",
                caricaturaTipo: "hermione",
                corBadge: "#DC2626"
            }
        ]
    }
};

module.exports = { personalidades };

