/**
 * Perguntas do Quiz de Personalidade e Aptidão: Cientistas e Protagonistas na Tecnologia
 * 10 perguntas profundas, envolventes e equilibradas.
 * Cada opção distribui pesos para os arquétipos científicos correspondentes.
 */

const questoes = [
    {
        id: 1,
        categoria: "Método e Pensamento",
        pergunta: "Quando surge um problema complexo que ninguém ao redor sabe como resolver, qual é seu impulso natural?",
        respostas: [
            {
                texto: "Decompor o enigma em lógica pura, identificando padrões abstratos e regras algorítmicas.",
                pesos: { adl: 3, tht: 1, drv: 1 }
            },
            {
                texto: "Ir direto à bancada do laboratório ou campo: testar hipóteses com evidências empíricas e experimentos rigorosos.",
                pesos: { mcr: 3, mtp: 1, jge: 1 }
            },
            {
                texto: "Pensar no impacto humano urgente: agir com agilidade e mobilizar soluções práticas para quem precisa.",
                pesos: { jge: 3, tts: 1, dj: 1 }
            },
            {
                texto: "Questionar as próprias premissas do problema: por que ele existe e quem são as vozes esquecidas?",
                pesos: { dj: 3, glw: 1, sgu: 1 }
            }
        ]
    },
    {
        id: 2,
        categoria: "Ambiente dos Sonhos",
        pergunta: "Em qual destes cenários você se sentiria mais plenamente realizada e energizada?",
        respostas: [
            {
                texto: "Em um laboratório celular de ponta, manipulando substâncias e buscando a regeneração de tecidos vivos.",
                pesos: { tts: 3, mcr: 1, jge: 1 }
            },
            {
                texto: "Sob a cúpula de um observatório astronômico, decifrando dados cósmicos de galáxias e buracos negros.",
                pesos: { tht: 3, adl: 1, glw: 1 }
            },
            {
                texto: "Em uma floresta exuberante, observando silenciosamente a vida selvagem e seus laços de convivência.",
                pesos: { jgl: 3, mtp: 1, tts: 1 }
            },
            {
                texto: "Em uma sala de tecnologia e comando, coordenando equipes brilhantes para um grande salto coletivo.",
                pesos: { drv: 3, sgu: 2, jge: 1 }
            }
        ]
    },
    {
        id: 3,
        categoria: "Talento Natural",
        pergunta: "Se você pudesse escolher um 'superpoder' intelectual para transformar o mundo, qual seria?",
        respostas: [
            {
                texto: "Enxergar a geografia secreta do planeta e desenhar mapas de territórios que todos julgam invisíveis.",
                pesos: { mtp: 3, tht: 1, jgl: 1 }
            },
            {
                texto: "Ensinar exatas e tecnologia com tanta paixão que qualquer pessoa se sinta capaz de superar seus limites.",
                pesos: { sgu: 3, glw: 2, dj: 1 }
            },
            {
                texto: "Projetar uma nova arquitetura computacional capaz de antecipar o futuro da inteligência artificial.",
                pesos: { adl: 3, drv: 1, glw: 1 }
            },
            {
                texto: "Mobilizar a sociedade com argumentos irrefutáveis, desmantelando preconceitos históricos com filosofia e dados.",
                pesos: { dj: 3, sgu: 1, jgl: 1 }
            }
        ]
    },
    {
        id: 4,
        categoria: "Resiliência & Incerteza",
        pergunta: "Você passou semanas trabalhando em uma hipótese e os primeiros resultados foram inesperados ou deram 'errado'. O que você faz?",
        respostas: [
            {
                texto: "Recalibro os dados com rigor inabalável: na ciência, o erro é só a bússola que aponta para a verdadeira descoberta.",
                pesos: { mcr: 3, tht: 1, mtp: 1 }
            },
            {
                texto: "Comemoro a anomalia! As maiores quebras de paradigmas vêm das respostas estranhas e da criatividade teórica.",
                pesos: { glw: 3, adl: 1, tts: 1 }
            },
            {
                texto: "Reorganizo a rota estrategicamente: se a ferramenta falhou, estudo uma nova tecnologia e capacito meu time.",
                pesos: { drv: 3, jge: 2, sgu: 1 }
            },
            {
                texto: "Respiro fundo e mantenho a paciência: os processos da natureza têm seu próprio tempo para serem decifrados.",
                pesos: { jgl: 3, mtp: 1, tts: 1 }
            }
        ]
    },
    {
        id: 5,
        categoria: "Instrumentos de Exploração",
        pergunta: "Qual objeto seria absolutamente indispensável na sua mesa ou mochila de trabalho?",
        respostas: [
            {
                texto: "Canetas de precisão milimétrica, réguas de cálculo e papéis milimetrados para gráficos e cartas.",
                pesos: { mtp: 3, adl: 1, mcr: 1 }
            },
            {
                texto: "Binóculos resistentes, um caderno de anotações de campo e um respeito sincero por cada ser vivo.",
                pesos: { jgl: 3, tts: 1, glw: 1 }
            },
            {
                texto: "Kits de reagentes biomédicos, centrífuga e sequenciador para diagnósticos rápidos de urgência.",
                pesos: { jge: 3, tts: 2, mcr: 1 }
            },
            {
                texto: "Livros de reflexão crítica, clássicos do pensamento humanista e cadernos cheios de ensaios transformadores.",
                pesos: { dj: 3, sgu: 1, glw: 1 }
            }
        ]
    },
    {
        id: 6,
        categoria: "Paixão Intelectual",
        pergunta: "Qual das seguintes conquistas científicas faria você pular de emoção no laboratório?",
        respostas: [
            {
                texto: "Comprovar que matéria de galáxias inteiras é absorvida por buracos negros em espirais perfeitas.",
                pesos: { tht: 3, mcr: 1, mtp: 1 }
            },
            {
                texto: "Desenvolver um polímero que regenera fibras nervosas e devolve a esperança de mobilidade a pacientes.",
                pesos: { tts: 3, jge: 1, mcr: 1 }
            },
            {
                texto: "Tornar-se a primeira mulher a conquistar o mais alto posto acadêmico e inspirar gerações de estudantes.",
                pesos: { sgu: 3, drv: 2, dj: 1 }
            },
            {
                texto: "Criar o primeiro código lógico para uma máquina que o mundo inteiro achava que era apenas ficção.",
                pesos: { adl: 3, drv: 1, tht: 1 }
            }
        ]
    },
    {
        id: 7,
        categoria: "Dinâmica de Equipe",
        pergunta: "Quando você trabalha em um projeto coletivo, qual papel as pessoas naturalmente esperam de você?",
        respostas: [
            {
                texto: "A estrategista firme e protetora, que enxerga o futuro e garante que ninguém fique para trás.",
                pesos: { drv: 3, sgu: 1, jge: 1 }
            },
            {
                texto: "A comunicadora entusiasmada, que cria pontes de afeto, valoriza a diversidade e quebra o gelo com leveza.",
                pesos: { glw: 3, jgl: 1, adl: 1 }
            },
            {
                texto: "A investigadora minuciosa, que confere cada detalhe com rigor para garantir que o resultado seja irrefutável.",
                pesos: { mcr: 2, mtp: 2, tht: 1 }
            },
            {
                texto: "A guardiã dos valores éticos, que assegura que o projeto tenha justiça social e representatividade genuína.",
                pesos: { dj: 3, sgu: 1, jge: 1 }
            }
        ]
    },
    {
        id: 8,
        categoria: "Impacto Prático",
        pergunta: "Se você tivesse recursos ilimitados para financiar um único grande projeto hoje, qual você priorizaria?",
        respostas: [
            {
                texto: "Laboratórios biomédicos públicos para resposta ultra-rápida contra pandemias e vigilância genômica.",
                pesos: { jge: 3, tts: 1, mcr: 1 }
            },
            {
                texto: "Mapeamento das profundezas dos oceanos e proteção do equilíbrio geofísico e climático da Terra.",
                pesos: { mtp: 3, jgl: 1, tht: 1 }
            },
            {
                texto: "Bolsas de pesquisa e centros de excelência em exatas para meninas negras e periféricas no ensino superior.",
                pesos: { sgu: 3, dj: 2, drv: 1 }
            },
            {
                texto: "Estudos de ponta em neurobiologia para regenerar axônios e reconstruir o sistema nervoso humano.",
                pesos: { tts: 3, jge: 1, mcr: 1 }
            }
        ]
    },
    {
        id: 9,
        categoria: "Concepção do Mundo",
        pergunta: "Quando você contempla a complexidade do universo e da natureza, qual pensamento mais ressoa em você?",
        respostas: [
            {
                texto: "É uma grande teia viva e empática, onde cada animal e planta tem sua dignidade e sentimento que merecem respeito.",
                pesos: { jgl: 3, tts: 1, dj: 1 }
            },
            {
                texto: "É uma coreografia majestosa de gravidade, relatividade e partículas dançando segundo equações sublimes.",
                pesos: { tht: 3, glw: 1, adl: 1 }
            },
            {
                texto: "É uma tapeçaria lógica e poética esperando por mentes visionárias para traduzi-la em algoritmos e ideias.",
                pesos: { adl: 2, glw: 2, mcr: 1 }
            },
            {
                texto: "É um imenso campo de elementos químicos e mistérios atômicos que a persistência humana é capaz de dominar para o bem.",
                pesos: { mcr: 3, tts: 1, sgu: 1 }
            }
        ]
    },
    {
        id: 10,
        categoria: "Legado Histórico",
        pergunta: "No final de sua trajetória, qual é a frase que você mais gostaria que definisse seu impacto na história?",
        respostas: [
            {
                texto: "'Desbravou caminhos onde disseram que não era o lugar de mulheres e abriu as portas para as próximas gerações.'",
                pesos: { sgu: 3, drv: 2, dj: 1 }
            },
            {
                texto: "'Projetou algoritmos e inovações quando ninguém acreditava, plantando as sementes do futuro digital.'",
                pesos: { adl: 3, glw: 1, tht: 1 }
            },
            {
                texto: "'Colocou sua inteligência a serviço da vida, salvando e curando pessoas com rigor e velocidade inigualáveis.'",
                pesos: { jge: 2, tts: 2, mcr: 1 }
            },
            {
                texto: "'Despertou a consciência ética do mundo e deu voz àqueles que o sistema sempre tentou silenciar.'",
                pesos: { dj: 3, jgl: 1, sgu: 1 }
            }
        ]
    }
];

module.exports = { questoes };
