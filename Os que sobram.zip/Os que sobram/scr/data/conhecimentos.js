/**
 * Perguntas para o Quiz de Conhecimentos Gerais: Mulheres na Ciência e Tecnologia
 */

const perguntasConhecimento = [
    {
        id: 1,
        pergunta: "Quem foi a única pessoa na história a ser laureada com dois Prêmios Nobel em duas áreas científicas diferentes (Física e Química)?",
        opcoes: [
            "Rosalind Franklin",
            "Marie Curie",
            "Lise Meitner",
            "Chien-Shiung Wu"
        ],
        correta: 1,
        explicacao: "Marie Curie ganhou o Nobel de Física em 1903 (junto com Pierre Curie e Henri Becquerel) pelas pesquisas sobre radiação, e o Nobel de Química em 1911 pela descoberta dos elementos Rádio e Polônio."
    },
    {
        id: 2,
        pergunta: "Em março de 2020, quem liderou a equipe multidisciplinar de cientistas que sequenciou o genoma do coronavírus (SARS-CoV-2) em apenas 48 horas no Brasil?",
        opcoes: [
            "Dra. Jaqueline Góes de Jesus",
            "Dra. Tatiana Sampaio",
            "Dra. Nísia Trindade",
            "Dra. Mayana Zatz"
        ],
        correta: 0,
        explicacao: "A biomédica baiana Jaqueline Góes de Jesus liderou, ao lado de Ester Sabino, o sequenciamento recorde em apenas 48 horas no Instituto Adolfo Lutz e na USP, enquanto outros países levavam em média 15 dias."
    },
    {
        id: 3,
        pergunta: "Quem é reconhecida historicamente como a primeira pessoa programadora do mundo, tendo criado o primeiro algoritmo para a Máquina Analítica no século XIX?",
        opcoes: [
            "Grace Hopper",
            "Katherine Johnson",
            "Ada Lovelace",
            "Margaret Hamilton"
        ],
        correta: 2,
        explicacao: "Ada Lovelace publicou em 1843 as notas sobre a Máquina Analítica de Charles Babbage, incluindo o primeiro algoritmo para ser computado por uma máquina mecânica."
    },
    {
        id: 4,
        pergunta: "Qual cientista e matemática pioneira aprendeu a linguagem FORTRAN de forma autodidata na NASA e treinou toda a sua equipe para a era da computação digital?",
        opcoes: [
            "Dorothy Vaughan",
            "Mary Jackson",
            "Gladys West",
            "Joan Clarke"
        ],
        correta: 0,
        explicacao: "Dorothy Vaughan antecipou que as máquinas IBM substituiriam o cálculo manual, aprendeu FORTRAN e ensinou suas colegas na NASA, garantindo suas carreiras e liderando o setor de computação."
    },
    {
        id: 5,
        pergunta: "Quem desenhou à mão o primeiro mapa científico tridimensional do fundo do Oceano Atlântico, provando a teoria da tectônica de placas?",
        opcoes: [
            "Sylvia Earle",
            "Marie Tharp",
            "Rachel Carson",
            "Inge Lehmann"
        ],
        correta: 1,
        explicacao: "Marie Tharp analisou milhares de dados de sonar e descobriu a Fenda da Dorsal Mesoatlântica em seus mapas, comprovando de maneira irrefutável a teoria da deriva continental."
    },
    {
        id: 6,
        pergunta: "Quem foi a primeira mulher negra brasileira com doutorado em Física (pela Universidade de Manchester) e a primeira professora mulher da história do Instituto Tecnológico de Aeronáutica (ITA)?",
        opcoes: [
            "Dra. Sônia Guimarães",
            "Dra. Katemari Rosa",
            "Dra. Zélia Ludwig",
            "Dra. Marcelle Soares-Santos"
        ],
        correta: 0,
        explicacao: "Dra. Sônia Guimarães obteve seu PhD em 1989 e ingressou como professora do ITA em 1993, tornando-se uma lenda na pesquisa de semicondutores e uma das maiores referências do país."
    }
];

module.exports = { perguntasConhecimento };
