@echo off
chcp 65001 > nul
title "Mulheres na Ciência & Tecnologia - Servidor"

echo ============================================================
echo   🔬 INICIANDO O PROJETO: MULHERES NA CIÊNCIA ^& TECNOLOGIA
echo ============================================================
echo.

:: Verifica se node já está no PATH
where node >nul 2>nul
if %errorlevel% neq 0 (
    :: Se não estiver no PATH, verifica diretórios padrão do instalador
    if exist "C:\Program Files\nodejs\node.exe" (
        set "PATH=C:\Program Files\nodejs;%PATH%"
    ) else if exist "C:\Program Files (x86)\nodejs\node.exe" (
        set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
    ) else if exist "%LOCALAPPDATA%\Programs\node\node.exe" (
        set "PATH=%LOCALAPPDATA%\Programs\node;%PATH%"
    )
)

:: Nova checagem após tentar os caminhos padrão
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [AVISO] O Node.js não foi encontrado no seu computador!
    echo.
    echo Para executar este projeto, você precisa instalar o Node.js.
    echo É gratuito, seguro e muito rápido:
    echo.
    echo 1. Acesse o site oficial: https://nodejs.org/
    echo 2. Baixe a versão LTS (Recomendada para a maioria)
    echo 3. Instale clicando em 'Avançar' até concluir
    echo 4. Depois volte aqui e clique duas vezes neste arquivo novamente!
    echo.
    echo Pressione qualquer tecla para abrir o site do Node.js agora...
    pause > nul
    start https://nodejs.org/
    exit /b
)

echo [OK] Node.js detectado!
echo [INFO] Abrindo o navegador em http://localhost:3000...
echo [INFO] Servidor rodando. Para parar, feche esta janela ou pressione Ctrl + C.
echo.

start "" "http://localhost:3000"

node server.js

pause
