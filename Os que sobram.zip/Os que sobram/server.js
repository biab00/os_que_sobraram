// Configurações do servidor - Mulheres na Ciência & Tecnologia
const app = require("./scr/app");

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(` 🔬 Mulheres na Ciência & Tecnologia - Servidor Ativo`);
    console.log(` 🚀 Acesse em seu navegador: http://localhost:${PORT}`);
    console.log(` ✨ Quiz de Personalidade:   http://localhost:${PORT}/quiz_personalidade`);
    console.log(` 📖 Galeria & Obras:         http://localhost:${PORT}/historias`);
    console.log(` 🧠 Desafio de Conhecimento: http://localhost:${PORT}/quiz_conhecimentos`);
    console.log(`====================================================`);
});
